import * as ts from "typescript";
import * as solidityParser from "@solidity-parser/parser";
import path from "path";
import { ASTNode, Symbol } from "./Types";

let ParserClass: any = null;
let LanguageClass: any = null;
let parserInitPromise: Promise<void> | null = null;

export class SemanticParser {
  private astIndex: Map<string, ASTNode> = new Map();
  private treeSitterParser: any = null;

  async parseSourceToAST(code: string, language: string = "typescript"): Promise<ASTNode> {
    if (language === "typescript" || language === "javascript") {
      return this.parseTypeScript(code);
    }
    if (language === "solidity" || language.toLowerCase().includes("sol")) {
      return this.parseSolidity(code);
    }
    
    // Attempt tree-sitter parse
    const tsAst = await this.parseTreeSitter(code, language);
    if (tsAst) return tsAst;

    return this.parseGeneric(code, language);
  }

  private async initTreeSitter() {
    if (!ParserClass) {
      const tsWasm = (await import("@vscode/tree-sitter-wasm/wasm/tree-sitter.js")).default;
      ParserClass = tsWasm.Parser;
      LanguageClass = tsWasm.Language;
    }
    if (!parserInitPromise) {
      parserInitPromise = ParserClass.init({
        locateFile() {
          return path.resolve("node_modules/@vscode/tree-sitter-wasm/wasm/tree-sitter.wasm");
        }
      });
    }
    await parserInitPromise;
    if (!this.treeSitterParser) {
      this.treeSitterParser = new ParserClass();
    }
  }

  private async getTreeSitterLanguage(lang: string) {
    let wasmName = "";
    if (lang === "python") wasmName = "tree-sitter-python.wasm";
    if (lang === "go") wasmName = "tree-sitter-go.wasm";
    if (lang === "java") wasmName = "tree-sitter-java.wasm";
    if (lang === "rust") wasmName = "tree-sitter-rust.wasm";
    if (lang === "c" || lang === "cpp") wasmName = "tree-sitter-cpp.wasm";
    if (lang === "ruby") wasmName = "tree-sitter-ruby.wasm";
    if (lang === "php") wasmName = "tree-sitter-php.wasm";
    if (lang === "bash") wasmName = "tree-sitter-bash.wasm";
    if (lang === "csharp" || lang === "cs") wasmName = "tree-sitter-c-sharp.wasm";
    if (lang === "css") wasmName = "tree-sitter-css.wasm";

    if (!wasmName) return null;

    try {
      const wasmPath = path.resolve(`node_modules/@vscode/tree-sitter-wasm/wasm/${wasmName}`);
      return await LanguageClass.load(wasmPath);
    } catch (e) {
      console.warn(`[Parser] Failed to load tree-sitter grammar for ${lang}`);
    }
    return null;
  }

  private async parseTreeSitter(code: string, language: string): Promise<ASTNode | null> {
    await this.initTreeSitter();
    const grammar = await this.getTreeSitterLanguage(language);
    if (!grammar) return null;

    try {
      this.treeSitterParser.setLanguage(grammar);
      const tree = this.treeSitterParser.parse(code);

      const walk = (node: any): ASTNode => {
        const children: ASTNode[] = [];
        for (let i = 0; i < node.namedChildCount; i++) {
          const child = node.namedChild(i);
          if (child) children.push(walk(child));
        }

        return {
          type: node.type,
          start: node.startIndex,
          end: node.endIndex,
          children,
          raw: node.text
        };
      };

      const unifiedAST = walk(tree.rootNode);
      this.buildASTIndex(unifiedAST);
      return unifiedAST;
    } catch (error) {
      console.warn(`[Parser] Tree-Sitter parse failed for ${language}`, error);
      return null;
    }
  }

  private async parseSolidity(code: string): Promise<ASTNode> {
    try {
      const ast = solidityParser.parse(code, { loc: true, range: true });
      
      const walk = (node: any): ASTNode => {
        const children: ASTNode[] = [];
        // Extract children based on common solidity-parser properties
        const keys = ["body", "statements", "expression", "left", "right", "trueBody", "falseBody", "subNodes"];
        keys.forEach(key => {
          if (node[key]) {
            if (Array.isArray(node[key])) {
              node[key].forEach((child: any) => children.push(walk(child)));
            } else {
              children.push(walk(node[key]));
            }
          }
        });

        return {
          type: node.type,
          start: node.range[0],
          end: node.range[1],
          children,
          raw: code.slice(node.range[0], node.range[1])
        };
      };

      const unifiedAST = walk(ast);
      this.buildASTIndex(unifiedAST);
      return unifiedAST;
    } catch (error) {
      console.warn("[Parser] Solidity parse failed, falling back to generic", error);
      return this.parseGeneric(code, "solidity");
    }
  }

  private async parseTypeScript(code: string): Promise<ASTNode> {
    const sourceFile = ts.createSourceFile(
      "neural_input.ts",
      code,
      ts.ScriptTarget.Latest,
      true
    );

    const walk = (node: ts.Node): ASTNode => {
      const children: ASTNode[] = [];
      node.forEachChild(child => {
        children.push(walk(child));
      });

      let metadata: any = undefined;
      if (ts.isIfStatement(node)) {
        metadata = {
          expressionStart: node.expression.getStart(),
          thenStart: node.thenStatement.getStart(),
          elseStart: node.elseStatement?.getStart()
        };
      }

      return {
        type: ts.SyntaxKind[node.kind],
        start: node.getStart(),
        end: node.getEnd(),
        children,
        raw: node.getText(sourceFile),
        metadata
      };
    };

    const ast = walk(sourceFile);
    this.buildASTIndex(ast);
    return ast;
  }

  buildASTIndex(ast: ASTNode) {
    this.walkAST(ast, (node) => {
      const key = `${node.type}:${node.start}-${node.end}`;
      this.astIndex.set(key, node);
    });
  }

  walkAST(node: ASTNode, callback: (node: ASTNode) => void) {
    callback(node);
    node.children.forEach(child => this.walkAST(child, callback));
  }

  queryASTNodes(type: string): ASTNode[] {
    const results: ASTNode[] = [];
    this.astIndex.forEach(node => {
      if (node.type === type) results.push(node);
    });
    return results;
  }

  async resolveImports(code: string): Promise<string[]> {
    const imports: string[] = [];
    // Native TS resolver
    const sourceFile = ts.createSourceFile("temp.ts", code, ts.ScriptTarget.Latest, true);
    ts.forEachChild(sourceFile, node => {
      if (ts.isImportDeclaration(node)) {
        imports.push(node.moduleSpecifier.getText());
      }
    });
    return imports;
  }

  private async parseGeneric(code: string, language: string): Promise<ASTNode> {
    // In a production environment, this would call specialized binary parsers.
    // Here we return a high-level representation.
    return { type: "PolyglotRoot", start: 0, end: code.length, children: [], raw: code };
  }
}
