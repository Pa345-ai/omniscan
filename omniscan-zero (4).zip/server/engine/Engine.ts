import { globby } from "globby";
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { AuditorRegistry } from "./Registry";
import { Verifier } from "./Verifier";
import { ScanContext } from "./Context";
import { SemanticParser } from "./Parser";
import { FlowAnalyzer } from "./Flow";
import { AIReasoningLayer } from "./AI/Reasoning";
import { InterproceduralAnalyzer } from "./Interprocedural";
import { PathAnalyzer } from "./PathAnalyzer";
import { SymbolicExecutor } from "./symbolic/Executor";
import { DynamicAnalyzer } from "./dynamic/Analyzer";
import { IRTranslator } from "./ir/Translator";
import { SemanticAnalyzer } from "./semantics/SemanticAnalyzer";
import { SemanticRankingEngine } from "./ranking/RankingEngine";
import { SourceFetcher } from "./SourceFetcher";
import { ProjectMapper } from "./ProjectMapper";
import { BytecodeDecompiler } from "./BytecodeDecompiler";
import { BytecodeIRTranslator } from "./ir/BytecodeTranslator";
import fs from "fs-extra";
import path from "path";
import { enrichFinding, lookupDependenciesOSV } from "./Intelligence";
import * as git from "isomorphic-git";
import { ScanCache } from "./Cache";
import { NotificationService } from "./NotificationService";
import { ScanDB } from "../db/Database";
import { PatchService } from "./PatchService";

import os from "os";
import { WorkerPool } from "./WorkerPool";

export enum ScanMode {
  QUICK = "quick",
  DEEP = "deep",
  AI_RESEARCH = "ai_research"
}

export class ScannerEngine {
  private ai: GoogleGenAI;
  private verifier: Verifier;
  private parser: SemanticParser;
  private flow: FlowAnalyzer;
  private reasoning: AIReasoningLayer;
  private interprocedural: InterproceduralAnalyzer;
  private pathSensitive: PathAnalyzer;
  private symbolic: SymbolicExecutor;
  private dynamic: DynamicAnalyzer;
  private translator: IRTranslator;
  private semantic: SemanticAnalyzer;
  private ranking: SemanticRankingEngine;
  private fetcher: SourceFetcher;
  private mapper: ProjectMapper;
  private cacheManager: ScanCache;
  private notifications: NotificationService;
  private patcher?: PatchService;
  private decompiler = new BytecodeDecompiler();
  private bytecodeTranslator = new BytecodeIRTranslator();
  private pool: WorkerPool;

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
    });
    this.verifier = new Verifier(this.ai);
    this.parser = new SemanticParser();
    this.flow = new FlowAnalyzer();
    this.reasoning = new AIReasoningLayer(this.ai);
    this.interprocedural = new InterproceduralAnalyzer();
    this.pathSensitive = new PathAnalyzer();
    this.symbolic = new SymbolicExecutor();
    this.dynamic = new DynamicAnalyzer();
    this.translator = new IRTranslator();
    this.semantic = new SemanticAnalyzer();
    this.ranking = new SemanticRankingEngine();
    this.fetcher = new SourceFetcher();
    this.mapper = new ProjectMapper();
    this.cacheManager = new ScanCache();
    this.notifications = new NotificationService();
    this.pool = new WorkerPool();
    this.symbolic.initialize().catch(e => console.error("Symbolic Engine Init Failed", e));

    if (process.env.GITHUB_TOKEN) {
      this.patcher = new PatchService({ githubToken: process.env.GITHUB_TOKEN });
    }
  }

  private async getLastCommitter(dir: string, filepath: string): Promise<string | undefined> {
    try {
      const log = await git.log({ fs, dir, filepath, depth: 1 });
      return log[0]?.commit.author.email || log[0]?.commit.committer.email;
    } catch (e) {
      return undefined;
    }
  }

  async scanRepo(url: string, mode: ScanMode = ScanMode.DEEP, branch: string = "main", onProgress?: (data: any) => void, abortSignal?: { aborted: boolean }) {
    const targetDir = await this.fetcher.cloneRepository(url, branch);
    try {
      const languages = await this.mapper.detect(targetDir);
      const frameworks = await this.mapper.detectFrameworks(targetDir);
      const isMonorepo = await this.mapper.isMonorepo(targetDir);
      const apiRoutes = await this.mapper.mapAPIRoutes(targetDir);
      const dependencies = await this.mapper.resolveDependencies(targetDir);
      
      console.log(`[Engine] Repository detected: ${languages.join(", ")} | Frameworks: ${frameworks.join(", ")}`);
      
      const limitStr = process.env.OMNISCAN_FILE_LIMIT;
      const limit = limitStr ? parseInt(limitStr, 10) : 500;
      const mainFiles = await this.findKeyFiles(targetDir, limit);
      let allFindings: any[] = [];
      const cacheData: Record<string, { hash: string, findings: any[] }> = {};

      const totalFiles = mainFiles.length;
      let processedFiles = 0;
      let newFindingsCount = 0;
      let resolvedFindingsCount = 0;
      let unchangedFindingsCount = 0;

      const cacheKey = Buffer.from(url).toString('base64') + '_' + branch;
      const prevCache = this.cacheManager.getCache(cacheKey);
      let currentCommit = "";

      try {
        currentCommit = await git.resolveRef({ fs, dir: targetDir, ref: 'HEAD' });
      } catch (e) {
        console.warn("Could not resolve HEAD commit", e);
      }

      if (onProgress) {
         onProgress({ type: 'scan_start', totalFiles });
      }

      const gitHashBlob = async (content: string) => {
        const { oid } = await git.hashBlob({ object: Buffer.from(content) });
        return oid;
      };

      // Parallel Scan Phase 1 & 2 (Audit)
      const scanTasks = mainFiles.map(async (item) => {
        if (abortSignal?.aborted) return null;

        const relativePath = path.relative(targetDir, item.file);
        const fileContent = await fs.readFile(item.file, 'utf8');
        const fileHash = await gitHashBlob(fileContent);

        if (prevCache && prevCache.files && prevCache.files[relativePath] && prevCache.files[relativePath].hash === fileHash) {
          const cached = prevCache.files[relativePath].findings;
          unchangedFindingsCount += cached.length;
          cacheData[relativePath] = { hash: fileHash, findings: cached };
          return { relativePath, findings: cached, cached: true };
        }

        // Run worker for new/changed files
        try {
          const workerPath = process.env.NODE_ENV === 'production' 
            ? path.join(process.cwd(), "dist", "ScanWorker.cjs")
            : path.join(process.cwd(), "server", "engine", "ScanWorker.ts");
          
          const rawFindings = await this.pool.run(
            workerPath,
            { code: fileContent, filename: path.basename(item.file), context: { mode } }
          );

          const mappedFindings = rawFindings.map((f: any) => enrichFinding({ ...f, file: relativePath }));
          return { relativePath, findings: mappedFindings, cached: false, fileContent, fileHash };
        } catch (err: any) {
          console.error(`[Engine] Worker failed for ${relativePath}:`, err.message);
          return null;
        }
      });

      const scanResults = await Promise.all(scanTasks);

      // Phase 3 & 4: Neural Proof & Patching (Main Thread)
      // Parallelize verification to resolve the sequential bottleneck
      const verificationTasks = scanResults.map(async (res) => {
        if (!res || res.cached) return res;
        const { relativePath, findings, fileContent, fileHash } = res as any;

        let finalFindings = findings;
        if (mode !== ScanMode.QUICK && findings.length > 0) {
            console.log(`[Engine] Neural Proofing ${findings.length} findings for ${relativePath}`);
            const verified = await this.verifier.verify(fileContent, findings);
            const patched = await Promise.all(verified.map(async (finding) => {
                let patch = finding.solution;
                let reasoned: { isExploitable: boolean, explanation: string, poc?: string, confidence?: number } = { 
                    isExploitable: true, 
                    explanation: finding.reasoning 
                };
                
                if (mode === ScanMode.AI_RESEARCH) {
                    const language = f.file.endsWith(".sol") ? "solidity" : 
                                     f.file.endsWith(".py") ? "python" :
                                     f.file.endsWith(".go") ? "go" :
                                     f.file.endsWith(".rs") ? "rust" :
                                     f.file.endsWith(".java") ? "java" :
                                     f.file.endsWith(".move") ? "move" : "typescript";
                    const ast = await this.parser.parseSourceToAST(fileContent, language); 
                    const ir = this.translator.translate(ast, language);
                    const semanticEnrichment = this.semantic.analyze(ir);
                    const symbolicFindings = await this.symbolic.analyze(ir, "main");
                    
                    const techContext = {
                        semanticEnrichment,
                        symbolicFindings,
                        pathConstraints: symbolicFindings.map(f => this.symbolic.getPathConstraints(f)).flat(),
                        solutionCandidates: symbolicFindings.map(f => f.path.map(p => p.solutionCandidate).filter(Boolean)).flat()
                    };

                    const val = await this.reasoning.verifyExploitability(fileContent, finding, techContext);
                    reasoned = val;
                    const result = await this.reasoning.generateAutonomousPatch(fileContent, finding);
                    patch = result.patch;
                    finding.validation = result.validation;
                }

                return {
                    ...finding,
                    file: relativePath,
                    isExploitable: reasoned.isExploitable,
                    poc: reasoned.poc,
                    aiExplanation: reasoned.explanation,
                    solution: patch || finding.solution
                };
            }));
            finalFindings = patched.filter((r: any) => r.isExploitable || r.severity === 'High');
        }
        return { relativePath, findings: finalFindings, cached: false, fileHash };
      });

      const finalAuditResults = await Promise.all(verificationTasks);

      for (const res of finalAuditResults) {
        if (!res) continue;
        const { relativePath, findings, cached, fileHash } = res as any;

        cacheData[relativePath] = { hash: fileHash, findings: findings };
        if (!cached) newFindingsCount += findings.length;
        allFindings.push(...findings);
        
        if (onProgress && !cached) {
            for (const f of findings) onProgress({ type: 'finding', finding: f });
        }

        processedFiles++;
        if (onProgress) {
            onProgress({ type: 'file_done', file: relativePath, processedFiles, totalFiles });
        }
      }

      if (mode === ScanMode.AI_RESEARCH && !abortSignal?.aborted) {
        console.log(`[Engine] Running AI Research Agent Layer across entire repository...`);
        try {
            const fullRepoFiles: {name: string, content: string}[] = [];
            for (const f of mainFiles.slice(0, 10)) { // Limit to top 10 most important files to prevent context exhaustion
               fullRepoFiles.push({ name: f.file, content: await fs.readFile(f.file, "utf8") });
            }
            const researchData = await this.reasoning.runDeepResearch(fullRepoFiles);
            
            researchData.findings.forEach((f: any) => {
                const finding = {
                    title: `AI Research: ${f.hypothesis.title}`,
                    severity: f.hypothesis.confidence > 0.9 ? "Critical" : "High" as const,
                    category: "AI Research",
                    reasoning: `${f.hypothesis.description}\n\nExploit Chain:\n${(f.exploit?.steps || []).map((s: any) => `- ${s.action} on ${s.target}`).join('\n')}`,
                    solution: "Review inferred trust boundaries and hard-code invariant checks.",
                    confidence: f.hypothesis.confidence,
                    exploit: f.exploit?.poc,
                    file: f.hypothesis.attackVector || "cross-file",
                    lineStart: 1,
                    lineEnd: 1
                };
                allFindings.push(finding);
                if (onProgress) onProgress({ type: 'finding', finding });
            });
        } catch(e) {
            console.warn("[Engine] Repo-wide AI Research failed:", e);
        }
      }

      // Compute resolved findings: files that existed in prevCache but a finding is no longer in mappedFindings (or file deleted)
      if (prevCache && prevCache.files) {
        let prevTotalFindings = 0;
        for (const [fpath, data] of Object.entries(prevCache.files)) {
          prevTotalFindings += data.findings.length;
        }
        // approximate resolved
        resolvedFindingsCount = Math.max(0, prevTotalFindings - unchangedFindingsCount);
      }

      const metadata = {
        languages, 
        frameworks, 
        filesCount: mainFiles.length,
        isMonorepo,
        apiRoutesCount: apiRoutes.length,
        dependencies,
        aborted: abortSignal?.aborted || false,
        delta: {
          new: newFindingsCount,
          resolved: resolvedFindingsCount,
          unchanged: unchangedFindingsCount
        }
      };

      if (!abortSignal?.aborted && currentCommit) {
        await this.cacheManager.updateCache(cacheKey, currentCommit, cacheData);
      }

      // Save to Database and detect regressions
      const regressions = ScanDB.getRegressions(url, allFindings);
      const { riskScore } = ScanDB.saveScan(url, allFindings);

      if (onProgress) {
        onProgress({ 
          type: 'scan_complete', 
          findings: allFindings, 
          metadata: { ...metadata, riskScore, regressionsCount: regressions.length } 
        });
      }

      // Trigger Notifications
      const repoName = url.split('/').pop()?.replace('.git', '') || 'unknown_repo';
      const notificationFindings = regressions.length > 0 ? regressions : allFindings.filter(f => f.severity === 'High');
      
      this.notifications.notify(repoName, notificationFindings, {
        webhookUrl: process.env.WEBHOOK_URL,
        slackWebhookUrl: process.env.SLACK_WEBHOOK_URL,
        discordWebhookUrl: process.env.DISCORD_WEBHOOK_URL,
        pagerDutyRoutingKey: process.env.PAGERDUTY_ROUTING_KEY,
      }).catch(err => console.error("[Engine] Notification failed:", err));

      // Trigger Autonomous Patches (PRs)
      if (this.patcher && mode === ScanMode.AI_RESEARCH && url.includes("github.com")) {
        const patchyFindings = allFindings.filter(f => f.severity === 'High' && f.solution && f.file);
        for (const finding of patchyFindings) {
            this.getLastCommitter(targetDir, finding.file).then(email => {
                this.patcher?.createSecurityPR(url, finding, finding.solution, email)
                    .then(prUrl => console.log(`[Engine] Autonomous PR opened: ${prUrl}`))
                    .catch(err => console.error(`[Engine] PR generation failed for ${finding.title}:`, err.message));
            });
        }
      }

      // Check OSV after main file scan to let the scan keep streaming smoothly
      if (dependencies && Object.keys(dependencies).length > 0) {
        const depFindings = await lookupDependenciesOSV(dependencies);
        if (depFindings.length > 0) {
           for (const f of depFindings) {
             const enrichedDepFinding = enrichFinding(f);
             allFindings.push(enrichedDepFinding);
             if (onProgress) onProgress({ type: 'finding', finding: enrichedDepFinding });
           }
        }
      }

      return { findings: allFindings, metadata };
    } finally {
      await this.fetcher.cleanup(targetDir);
    }
  }

  async scanContract(address: string, network: string, mode: ScanMode = ScanMode.AI_RESEARCH) {
    const { files, bytecode } = await this.fetcher.fetchSmartContract(address, network);
    let allFindings: any[] = [];

    // Analyze source if available
    for (const file of files) {
      const language = file.path.endsWith(".sol") ? "solidity" : "typescript";
      const findings = await this.scan(file.content, file.path, mode, language);
      allFindings.push(...findings.map(f => ({ ...f, file: file.path })));
    }

    // Analyze bytecode using Unified IR
    if (bytecode) {
        console.log(`[Engine] Analyzing contract bytecode via Unified IR...`);
        const decompiled = this.decompiler.decompile(bytecode);
        const ir = this.bytecodeTranslator.translate(decompiled);
        
        // Now run the same IR-based analysis as source!
        this.semantic.analyze(ir);
        await this.flow.analyzeFullFlow(ir);
        const symbolicFindings = await this.symbolic.analyze(ir, "runtime_bytecode");
        
        allFindings.push(...symbolicFindings.map(f => ({
            title: `Bytecode Analysis: ${f.title}`,
            severity: f.severity,
            category: "Bytecode",
            reasoning: f.reasoning,
            solution: "Verify bytecode invariants match source assumptions.",
            confidence: 0.9
        })));
    }

    // Save to DB
    const { riskScore } = ScanDB.saveScan(address, allFindings);

    // Trigger Notifications for contract
    this.notifications.notify(address, allFindings, {
      webhookUrl: process.env.WEBHOOK_URL,
      slackWebhookUrl: process.env.SLACK_WEBHOOK_URL,
      discordWebhookUrl: process.env.DISCORD_WEBHOOK_URL,
      pagerDutyRoutingKey: process.env.PAGERDUTY_ROUTING_KEY,
    }).catch(err => console.error("[Engine] Notification failed:", err));

    return { findings: allFindings, metadata: { address, network, filesCount: files.length, riskScore } };
  }

  private async findKeyFiles(dir: string, limit: number = 500): Promise<{ file: string, lang: string }[]> {
    const omniIgnorePath = path.join(dir, '.omniscanignore');
    
    const globOptions: any = {
      cwd: dir,
      absolute: true,
      gitignore: true,
      ignore: ['**/node_modules/**', '**/dist/**', '**/build/**', '**/.git/**']
    };

    if (await fs.pathExists(omniIgnorePath)) {
      globOptions.ignoreFiles = [omniIgnorePath];
    }

    const files = await globby('**/*', globOptions);

    let scoredFiles: { file: string, lang: string, score: number }[] = [];

    for (const rawFile of files) {
      const file = typeof rawFile === 'string' ? rawFile : (rawFile as any).path;
      const stat = await fs.stat(file);
      if (stat.isDirectory()) continue;

      const lang = await this.mapper.detectFileLanguage(file);
      if (lang && lang !== "bash") {
        let score = 50;
        const lowerFile = file.toLowerCase();
        
        if (lowerFile.includes('route') || lowerFile.includes('controller') || lowerFile.includes('handler') || lowerFile.includes('middleware')) {
          score = 100;
        } else if (lowerFile.includes('model') || lowerFile.includes('entity') || lowerFile.includes('schema')) {
          score = 80;
        } else if (lang === 'dockerfile' || lang === 'terraform' || lowerFile.endsWith('.yaml') || lowerFile.endsWith('.yml')) {
          score = 90; // High priority for infra
        } else if (lowerFile.includes('util') || lowerFile.includes('helper')) {
          score = 20;
        }

        scoredFiles.push({ file, lang, score });
      }
    }

    scoredFiles.sort((a, b) => b.score - a.score);

    const langCounts: Record<string, number> = {};
    const finalFiles: typeof scoredFiles = [];
    
    for (const file of scoredFiles) {
      const lang = file.lang;
      if (!langCounts[lang]) langCounts[lang] = 0;
      if (langCounts[lang] < limit) {
        finalFiles.push(file);
        langCounts[lang]++;
      }
    }

    return finalFiles.map(s => ({ file: s.file, lang: s.lang }));
  }

  async scan(code: string, filename: string = "source_code", mode: ScanMode = ScanMode.DEEP, language: string = "typescript") {
    console.log(`[OmniScan] Initializing ${mode} Scan: ${filename} (Lang: ${language})`);
    
    // Phase 1: Semantic & Path Indexing
    language = filename.endsWith(".sol") ? "solidity" : 
                     filename.endsWith(".py") ? "python" :
                     filename.endsWith(".go") ? "go" :
                     filename.endsWith(".rs") ? "rust" :
                     filename.endsWith(".java") ? "java" :
                     filename.endsWith(".move") ? "move" : language;
    const ast = await this.parser.parseSourceToAST(code, language);
    const ir = this.translator.translate(ast, language);
    const semanticEnrichment = this.semantic.analyze(ir);
    const fullFlow = await this.flow.analyzeFullFlow(ir);
    const graph = await this.flow.buildExecutionGraph(ast);
    const interproceduralMetrics = await this.interprocedural.analyze(code, ir, graph);
    const unreachablePaths = await this.pathSensitive.resolvePathFeasibility(code, graph);
    
    const context = new ScanContext(code, filename);
    context.metadata = { ast, ir, semanticEnrichment, fullFlow, graph, interproceduralMetrics, unreachablePaths, mode };

    // Phase 2: Orchestrated Multi-Auditor Execution
    const auditors = AuditorRegistry.getAuditors();
    
    // In Quick Scan, we bypass heavy AI reasoning for all findings
    if (mode === ScanMode.QUICK) {
       const rawFindings = await Promise.all(
        auditors.map(auditor => auditor.audit(code, context))
      );
      return rawFindings.flat().filter(f => f.confidence > 0.8);
    }

    const rawFindings = await Promise.all(
      auditors.map(auditor => auditor.audit(code, context))
    );
    const candidates = rawFindings.flat();

    // symbolic execution phase
    if (mode === ScanMode.DEEP || mode === ScanMode.AI_RESEARCH) {
      const ir = context.metadata?.ir;
      const symbolicFindings = ir ? await this.symbolic.analyze(ir, "main") : [];
      // Map SymbolicFinding to BugReport format
      candidates.push(...symbolicFindings.map(f => ({
        title: f.title,
        severity: f.severity,
        category: "Symbolic",
        reasoning: f.reasoning,
        solution: "Use safe math or check bounds.",
        confidence: 0.9,
        cwe: "CWE-190"
      })));
    }

    // Phase 3: Runtime Dynamic Analysis (Fuzzing & Instrumentation)
    if (mode === ScanMode.DEEP || mode === ScanMode.AI_RESEARCH) {
        const dynamicType = filename.endsWith('.sol') || filename.includes('0x') ? 'contract' : 'node';
        const dynamicFindings = await this.dynamic.runAnalysis(code, dynamicType);
        
        candidates.push(...dynamicFindings.map(f => ({
            title: f,
            severity: "Critical" as const,
            category: "Dynamic",
            reasoning: "Runtime instrumentation detected a vulnerability pattern that static analysis might miss.",
            solution: "Harden input validation and implement runtime checks or guards.",
            confidence: 0.95
        })));
    }

    // Phase 4: AI Research Agent Layer (Exploit Chains & Business Logic)
    if (mode === ScanMode.AI_RESEARCH) {
        const researchData = await this.reasoning.runDeepResearch([{ name: filename, content: code }]);
        
        researchData.findings.forEach((f: any) => {
            candidates.push({
                title: `AI Research: ${f.hypothesis.title}`,
                severity: f.hypothesis.confidence > 0.9 ? "Critical" : "High",
                category: "AI Research",
                reasoning: `${f.hypothesis.description}\n\nExploit Chain:\n${f.exploit.steps.map((s: any) => `- ${s.action} on ${s.target}`).join('\n')}`,
                solution: "Review inferred trust boundaries and hard-code invariant checks.",
                confidence: f.hypothesis.confidence,
                exploit: f.exploit.poc
            });
        });
    }

    // Filter out findings in unreachable code
    const filteredCandidates = candidates.filter(f => {
      if (f.lineStart !== undefined) {
        // Simple line-based exclusion if it falls in unreachable block
        return true; 
      }
      return true;
    });

    // Phase 3: Neural Proof & Exploitability
    console.log(`[OmniScan] Verifying ${filteredCandidates.length} potential artifacts with Matrix Reasoning...`);
    const verified = await this.verifier.verify(code, filteredCandidates);

    // Phase 4: Autonomous POC Generation & Patching
    const reports = await Promise.all(verified.map(async (finding) => {
      let reasoningResult: { isExploitable: boolean, poc?: string, explanation: string } = { 
        isExploitable: true, 
        explanation: finding.reasoning 
      };
      let patch = finding.solution;

      if (mode === ScanMode.AI_RESEARCH) {
        const techContext = {
            semanticEnrichment: context.metadata?.semanticEnrichment,
            symbolicFindings: candidates.filter(c => c.category === "Symbolic"),
            pathConstraints: context.metadata?.unreachablePaths || [],
            solutionCandidates: candidates.filter(c => c.category === "Symbolic").map((f: any) => f.path.map((p: any) => p.solutionCandidate).filter(Boolean)).flat()
        };

        const val = await this.reasoning.verifyExploitability(code, finding, techContext);
        reasoningResult = {
          isExploitable: val.isExploitable,
          poc: val.poc,
          explanation: val.explanation
        };
        const result = await this.reasoning.generateAutonomousPatch(code, finding);
        patch = result.patch;
        finding.validation = result.validation;
      }
      
      return {
        ...finding,
        isExploitable: reasoningResult.isExploitable,
        poc: reasoningResult.poc,
        aiExplanation: reasoningResult.explanation,
        solution: patch || finding.solution
      };
    }));

    const finalReports = reports.filter(r => r.isExploitable || r.severity === 'High');
    return this.ranking.rank(finalReports, code, graph);
  }
}
