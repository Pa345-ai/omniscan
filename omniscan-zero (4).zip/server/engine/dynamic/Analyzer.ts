
import { EliteFuzzer } from "./Fuzzer";
import { EVMSandbox, NodeSandbox, PythonSandbox, JVMSandbox, BinarySandbox } from "./Sandboxes";
import { RuntimeMonitor, Sandbox } from "./Monitor";
import { FuzzStrategy } from "./Types";

export class DynamicAnalyzer {
  private fuzzer = new EliteFuzzer();
  private monitor = new RuntimeMonitor();
  private sandboxes: Map<string, Sandbox> = new Map<string, Sandbox>([
      ['contract', new EVMSandbox()],
      ['node', new NodeSandbox()],
      ['python', new PythonSandbox()],
      ['jvm', new JVMSandbox()],
      ['binary', new BinarySandbox()]
  ]);

  async runAnalysis(target: string, type: 'contract' | 'node' | 'python' | 'jvm' | 'binary'): Promise<string[]> {
    const findings: string[] = [];
    const iterations = 50;

    const sandbox = this.sandboxes.get(type) || this.sandboxes.get('node')!;
    
    // Choose optimal strategy based on target type
    let strategy = FuzzStrategy.MUTATION_AFL;
    if (type === 'contract') strategy = FuzzStrategy.ABI_FUZZING;
    if (type === 'binary') strategy = FuzzStrategy.MUTATION_AFL;
    if (type === 'jvm') strategy = FuzzStrategy.PROPERTY_BASED;

    console.log(`[Dynamic] Starting ${strategy} fuzzing loop on ${type}...`);

    for (let i = 0; i < iterations; i++) {
      // Concolic Feedback: In a real system, we'd use symbolic solver values to seed the fuzzer
      // Here we simulate it by adding 'interesting' inputs to fuzzer corpus
      if (i % 10 === 0) {
          this.fuzzer.addSeed(Buffer.from("concolic_derived_path_constraint_0x" + i.toString(16)));
      }

      const input = this.fuzzer.generateInput(strategy);
      const events = await sandbox.execute(input);
      
      events.forEach(e => this.monitor.log(e));
      
      // Early exit if critical crash found
      if (events.some(e => e.severity === "Critical" && e.type === "CRASH")) {
          console.warn(`[Dynamic] Critical CRASH detected in ${type} sandbox. Halting fuzzing.`);
          break;
      }
    }

    findings.push(...this.monitor.detectPatterns());
    return findings;
  }
}
