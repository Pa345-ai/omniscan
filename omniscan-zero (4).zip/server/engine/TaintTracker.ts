export const TaintSources = [
  // HTTP
  "req.body", "req.query", "req.params", "req.headers", "req.cookies",
  "$_POST", "$_GET", "$_REQUEST", "$_COOKIE", "$HTTP_USER_AGENT",
  "request.POST", "request.GET", // Python/Django
  // Env
  "process.env", "os.environ", "getenv",
  // Input
  "prompt", "readline", "window.location", "document.cookie",
  // Database reads might be considered sources in some contexts, but usually they are trusted. We'll add some generic ones:
  "db.collection", "Model.find", "SELECT "
];

export const TaintSinks = [
  // SQL
  "query(", "execute(", "exec(", "db.raw(", "mysqli_query(", "PDO::query(",
  // Shell
  "exec(", "spawn(", "system(", "popen(", "os.system(", "subprocess.Popen(",
  // File
  "fs.readFile(", "open(", "file_get_contents(", "fs.writeFile(",
  // HTML Output
  "innerHTML", "dangerouslySetInnerHTML", "echo ", "document.write(", "send(",
  // Deserializers
  "eval(", "JSON.parse(", "pickle.loads(", "yaml.load(", "unserialize(",
  // Network calls
  "fetch(", "axios(", "requests.get("
];

export const Sanitizers = [
  "escape(", "sanitize(", "encodeURIComponent(", "DOMPurify.sanitize(",
  "mysql.escape(", "htmlentities(", "htmlspecialchars(", "prepare(", "allowlist"
];

export interface TaintFlow {
  source: string;
  sink: string;
  path: string[];
  sanitizerGap: boolean;
}

export class GlobalTaintState {
  // map from "filename:funcName" -> list of argument indices that are passed to a sink
  public sinkFunctions: Map<string, Set<number>> = new Map();
  // map from "filename:funcName" -> returns tainted data
  public sourceFunctions: Map<string, boolean> = new Map();
  // map from "filename:funcName" -> object detailing internal taint flows
  public functionFlows: Map<string, any> = new Map();
}

export const globalTaintState = new GlobalTaintState();
