import { BugReport } from "./Auditor";

export interface Symbol {
  name: string;
  type: string;
  scope: string;
  definitionPos: number;
}

export interface ASTNode {
  type: string;
  start: number;
  end: number;
  children: ASTNode[];
  raw?: string;
  metadata?: any;
}

export interface FlowEdge {
  from: number;
  to: number;
  type: 'control' | 'data';
  label?: string;
}

export interface TaintFlow {
  source: string;
  sink: string;
  path: number[]; // Array of line numbers or node IDs
  sanitizers: string[];
}

export interface SecurityGraph {
  nodes: Map<number, ASTNode>;
  edges: FlowEdge[];
  symbols: Symbol[];
}
