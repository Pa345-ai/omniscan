import * as vscode from 'vscode';

let diagnosticCollection: vscode.DiagnosticCollection;
let scanTimeout: NodeJS.Timeout | undefined;
let statusBarItem: vscode.StatusBarItem;

export function activate(context: vscode.ExtensionContext) {
    console.log('OmniScan extension activated');
    diagnosticCollection = vscode.languages.createDiagnosticCollection('omniscan');
    context.subscriptions.push(diagnosticCollection);

    statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
    statusBarItem.text = "$(shield) OmniScan: Active";
    statusBarItem.command = 'omniscan.scanFile';
    statusBarItem.show();
    context.subscriptions.push(statusBarItem);

    // Command to manually trigger scan
    let scanCommand = vscode.commands.registerCommand('omniscan.scanFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (editor) {
            runScan(editor.document);
        }
    });
    context.subscriptions.push(scanCommand);

    // Scan on save
    context.subscriptions.push(
        vscode.workspace.onDidSaveTextDocument((document) => {
            const config = vscode.workspace.getConfiguration('omniscan');
            if (config.get('scanOnSave')) {
                debounceScan(document);
            }
        })
    );

    // Quick Fix Provider
    context.subscriptions.push(
        vscode.languages.registerCodeActionsProvider(
            { scheme: 'file', language: '*' },
            new OmniScanActionProvider(),
            { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] }
        )
    );
}

function debounceScan(document: vscode.TextDocument) {
    if (scanTimeout) {
        clearTimeout(scanTimeout);
    }
    scanTimeout = setTimeout(() => {
        runScan(document);
    }, 2000); // 2s debounce as requested
}

async function runScan(document: vscode.TextDocument) {
    const config = vscode.workspace.getConfiguration('omniscan');
    const endpoint = config.get('endpoint') as string;
    const mode = config.get('scanMode') as string;
    const apiKey = config.get('apiKey') as string;

    statusBarItem.text = "$(sync~spin) OmniScan: Scanning...";
    try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (apiKey) headers['X-OmniScan-Key'] = apiKey;

        const response = await fetch(endpoint, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({
                code: document.getText(),
                filename: document.fileName,
                mode: mode
            })
        });

        if (!response.ok) throw new Error('API failed');

        const data = await response.json();
        const findings: any[] = data.bugs || [];
        updateDiagnostics(document, findings);
        statusBarItem.text = `$(shield) OmniScan: ${findings.length} findings`;
    } catch (err: any) {
        vscode.window.showErrorMessage(`OmniScan Error: ${err.message}`);
        statusBarItem.text = "$(alert) OmniScan: Error";
    }
}

function updateDiagnostics(document: vscode.TextDocument, findings: any[]) {
    const diagnostics: vscode.Diagnostic[] = [];
    const text = document.getText();

    findings.forEach(finding => {
        // Simple heuristic: find line number from reasoning or code context 
        // Real implementation would use line/column from auditor
        let line = 0;
        if (finding.lineStart) {
            line = finding.lineStart - 1;
        } else {
            // Find first occurrence of finding title or keywords in text (naive fallback)
            const index = text.indexOf(finding.title.split(' ')[0]);
            if (index !== -1) {
                line = document.positionAt(index).line;
            }
        }

        const range = new vscode.Range(line, 0, line, 100);
        const diagnostic = new vscode.Diagnostic(
            range,
            `[${finding.severity}] ${finding.title}: ${finding.reasoning}`,
            getSeverity(finding.severity)
        );
        diagnostic.source = 'OmniScan';
        diagnostic.code = finding.cwe;
        
        // Store technical details in diagnostic
        (diagnostic as any).finding = finding;
        
        diagnostics.push(diagnostic);
    });

    diagnosticCollection.set(document.uri, diagnostics);
}

function getSeverity(sev: string): vscode.DiagnosticSeverity {
    switch (sev.toLowerCase()) {
        case 'critical':
        case 'high': return vscode.DiagnosticSeverity.Error;
        case 'medium': return vscode.DiagnosticSeverity.Warning;
        default: return vscode.DiagnosticSeverity.Information;
    }
}

class OmniScanActionProvider implements vscode.CodeActionProvider {
    provideCodeActions(document: vscode.TextDocument, range: vscode.Range | vscode.Selection, context: vscode.CodeActionContext): vscode.ProviderResult<vscode.CodeAction[]> {
        const actions: vscode.CodeAction[] = [];
        
        context.diagnostics.filter(d => d.source === 'OmniScan').forEach(diagnostic => {
            const finding = (diagnostic as any).finding;
            if (finding && finding.solution) {
                const action = new vscode.CodeAction(`🛡️ Apply OmniScan Fix: ${finding.title}`, vscode.CodeActionKind.QuickFix);
                action.edit = new vscode.WorkspaceEdit();
                
                // For simplicity, we replace the whole file with the "solution" if it's a patch, 
                // or just provide the comment.
                // Modern OmniScan returns a full patch in AI_RESEARCH mode.
                if (finding.solution.startsWith('//') || finding.solution.length < 500) {
                     // If solution is short or just a comment, maybe it's not a full patch
                     // Real implementation would use diffing or line replacement
                    action.edit.insert(document.uri, new vscode.Position(diagnostic.range.start.line, 0), `// FIX: ${finding.solution}\n`);
                } else {
                    // Replace whole file if it looks like a full patch
                    const fullRange = new vscode.Range(0, 0, document.lineCount, 0);
                    action.edit.replace(document.uri, fullRange, finding.solution);
                }
                
                action.diagnostics = [diagnostic];
                actions.push(action);
            }
        });

        return actions;
    }
}

export function deactivate() {}
