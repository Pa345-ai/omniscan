import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.join(process.cwd(), 'scans.db');
const db = new Database(dbPath);

// Initialize schema
db.exec(`
  CREATE TABLE IF NOT EXISTS repos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT UNIQUE,
    name TEXT,
    last_scan_at DATETIME,
    risk_score REAL DEFAULT 100
  );

  CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    repo_url TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    findings_count INTEGER,
    high_count INTEGER,
    medium_count INTEGER,
    low_count INTEGER,
    risk_score REAL,
    fingerprint TEXT
  );

  CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER,
    title TEXT,
    severity TEXT,
    category TEXT,
    file TEXT,
    line_start INTEGER,
    fingerprint TEXT,
    reasoning TEXT,
    solution TEXT,
    mitigation_status TEXT,
    mitigation_reason TEXT,
    resolved_at DATETIME,
    FOREIGN KEY(scan_id) REFERENCES scans(id)
  );
`);

export interface ScanResult {
  url: string;
  findings: any[];
  timestamp: string;
  riskScore: number;
}

export class ScanDB {
  static saveScan(url: string, findings: any[]) {
    const repoName = url.split('/').pop()?.replace('.git', '') || 'unknown';
    
    // Upsert repo
    db.prepare('INSERT OR IGNORE INTO repos (url, name) VALUES (?, ?)').run(url, repoName);
    
    const high = findings.filter(f => f.severity === 'High').length;
    const medium = findings.filter(f => f.severity === 'Medium').length;
    const low = findings.filter(f => f.severity === 'Low').length;
    
    // Simple risk score calculation
    const riskScore = Math.max(0, 100 - (high * 10 + medium * 5 + low * 2));

    const scanInsert = db.prepare(`
      INSERT INTO scans (repo_url, findings_count, high_count, medium_count, low_count, risk_score)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(url, findings.length, high, medium, low, riskScore);

    const scanId = scanInsert.lastInsertRowid;

    // Detect resolved findings and update resolved_at
    const lastScan = db.prepare('SELECT id FROM scans WHERE repo_url = ? AND id < ? ORDER BY timestamp DESC LIMIT 1')
      .get(url, scanId) as any;
    
    if (lastScan) {
      const currentFingerprints = new Set(findings.map(f => `${f.title}-${f.file}-${f.lineStart}`));
      const previousFindings = db.prepare('SELECT id, fingerprint FROM findings WHERE scan_id = ? AND resolved_at IS NULL')
        .all(lastScan.id) as any[];
      
      const updateResolved = db.prepare('UPDATE findings SET resolved_at = CURRENT_TIMESTAMP WHERE id = ?');
      previousFindings.forEach(pf => {
        if (!currentFingerprints.has(pf.fingerprint)) {
          updateResolved.run(pf.id);
        }
      });
    }

    const findInsert = db.prepare(`
      INSERT INTO findings (scan_id, title, severity, category, file, line_start, fingerprint, reasoning, solution)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    findings.forEach(f => {
      const fingerprint = `${f.title}-${f.file}-${f.lineStart}`;
      findInsert.run(scanId, f.title, f.severity, f.category || 'General', f.file, f.lineStart, fingerprint, f.reasoning, f.solution);
    });

    db.prepare('UPDATE repos SET last_scan_at = CURRENT_TIMESTAMP, risk_score = ? WHERE url = ?')
      .run(riskScore, url);

    return { scanId, riskScore };
  }

  static getFindingsByScan(scanId: number) {
    return db.prepare('SELECT * FROM findings WHERE scan_id = ?').all(scanId);
  }

  static mitigateFinding(findingId: number, status: string, reason: string) {
    return db.prepare('UPDATE findings SET mitigation_status = ?, mitigation_reason = ? WHERE id = ?')
      .run(status, reason, findingId);
  }

  static getLatestScanFindings(url: string) {
    const lastScan = db.prepare('SELECT id FROM scans WHERE repo_url = ? ORDER BY timestamp DESC LIMIT 1').get(url) as any;
    if (!lastScan) return [];
    return this.getFindingsByScan(lastScan.id);
  }

  static getHistory(url: string) {
    return db.prepare('SELECT * FROM scans WHERE repo_url = ? ORDER BY timestamp DESC LIMIT 20').all(url);
  }

  static getRepoStats() {
    return db.prepare('SELECT url, name, last_scan_at, risk_score FROM repos ORDER BY risk_score ASC').all();
  }

  static getGlobalTrends() {
    return db.prepare(`
      SELECT date(timestamp) as day, AVG(risk_score) as avg_score, SUM(findings_count) as total_findings
      FROM scans
      GROUP BY day
      ORDER BY day ASC
      LIMIT 30
    `).all();
  }

  static getMTTR() {
     // findings with resolved_at. timestamp is in scans table.
     // joining findings with scans to get start time.
     const rows = db.prepare(`
        SELECT 
          f.resolved_at,
          s.timestamp as created_at
        FROM findings f
        JOIN scans s ON f.scan_id = s.id
        WHERE f.resolved_at IS NOT NULL
     `).all() as any[];

     if (rows.length === 0) return 0;

     const totalDiff = rows.reduce((acc, row) => {
        const start = new Date(row.created_at).getTime();
        const end = new Date(row.resolved_at).getTime();
        return acc + (end - start);
     }, 0);

     return totalDiff / rows.length / (1000 * 60 * 60); // Return in hours
  }

  static getRegressions(url: string, currentFindings: any[]) {
    const lastScan = db.prepare('SELECT id FROM scans WHERE repo_url = ? ORDER BY timestamp DESC LIMIT 1 OFFSET 1').get(url) as any;
    if (!lastScan) return [];

    const previousFindings = db.prepare('SELECT fingerprint FROM findings WHERE scan_id = ?').all(lastScan.id) as any[];
    const prevFingerprints = new Set(previousFindings.map(f => f.fingerprint));

    return currentFindings.filter(f => !prevFingerprints.has(`${f.title}-${f.file}-${f.lineStart}`));
  }
}
