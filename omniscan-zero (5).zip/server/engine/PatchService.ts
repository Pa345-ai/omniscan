import { Octokit } from "@octokit/rest";
import { BugReport } from "./Auditor";

interface PRConfig {
  githubToken: string;
}

export class PatchService {
  private octokit: Octokit;

  constructor(config: PRConfig) {
    this.octokit = new Octokit({ auth: config.githubToken });
  }

  async createSecurityPR(repoUrl: string, finding: BugReport, patch: string, committerEmail?: string) {
    const parts = repoUrl.replace('https://github.com/', '').replace('.git', '').split('/');
    if (parts.length < 2) throw new Error("Invalid GitHub URL for PR generation");
    
    const [owner, repo] = parts;
    const branchName = `security-fix-${Date.now()}`;
    const filePath = finding.file || 'patched_file';
    
    try {
      // 1. Get default branch
      const { data: repoData } = await this.octokit.repos.get({ owner, repo });
      const defaultBranch = repoData.default_branch;

      // 2. Get latest commit SHA from default branch
      const { data: refData } = await this.octokit.git.getRef({
        owner,
        repo,
        ref: `heads/${defaultBranch}`,
      });
      const baseSha = refData.object.sha;

      // 3. Create new branch
      await this.octokit.git.createRef({
        owner,
        repo,
        ref: `refs/heads/${branchName}`,
        sha: baseSha,
      });

      // 4. Get file info (for blob SHA)
      const { data: fileData } = await this.octokit.repos.getContent({
        owner,
        repo,
        path: filePath,
        ref: defaultBranch,
      });

      const sha = Array.isArray(fileData) ? undefined : fileData.sha;

      // 5. Commit patched content
      await this.octokit.repos.createOrUpdateFileContents({
        owner,
        repo,
        path: filePath,
        message: `Security Fix: ${finding.title}`,
        content: Buffer.from(patch).toString('base64'),
        branch: branchName,
        sha,
      });

      // 6. Create PR
      const { data: pr } = await this.octokit.pulls.create({
        owner,
        repo,
        title: `🛡️ Security Fix: ${finding.title}`,
        head: branchName,
        base: defaultBranch,
        body: `
### Security Vulnerability Patched
**Title:** ${finding.title}
**Severity:** ${finding.severity}
**CWE:** ${finding.cwe || 'N/A'}

**AI Explanation:**
${finding.aiExplanation || finding.reasoning}

**Recommended Action:**
Review the proposed changes and merge to resolve the vulnerability. This PR was generated autonomously by OmniScan.
        `,
      });

      // 7. Add Labels
      await this.octokit.issues.addLabels({
        owner,
        repo,
        issue_number: pr.number,
        labels: ['security-fix'],
      });

      // 8. Assign (Heuristic: search user by email if provided)
      if (committerEmail) {
        try {
            const { data: userData } = await this.octokit.search.users({ q: `${committerEmail} in:email` });
            if (userData.items.length > 0) {
                await this.octokit.issues.addAssignees({
                    owner,
                    repo,
                    issue_number: pr.number,
                    assignees: [userData.items[0].login],
                });
            }
        } catch (e) {
            console.warn(`[PatchService] Could not assign PR to ${committerEmail}`);
        }
      }

      return pr.html_url;
    } catch (err: any) {
      console.error("[PatchService] PR creation failed:", err.message);
      throw err;
    }
  }
}
