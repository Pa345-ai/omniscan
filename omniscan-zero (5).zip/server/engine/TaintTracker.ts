export const TaintSources = [
  // HTTP requests, Cookies, Headers, Forms
  "req.body", "req.query", "req.params", "req.headers", "req.cookies",
  "$_POST", "$_GET", "$_REQUEST", "$_COOKIE", "$HTTP_USER_AGENT",
  "request.POST", "request.GET", "request.form",
  // APIs
  "api.response", "graphql.resolve", // GraphQL input
  // Databases
  "db.collection", "Model.find", "SELECT ",
  // WebSockets
  "socket.on", "ws.on('message')",
  // CLI input, Env
  "process.env", "os.environ", "getenv", "prompt", "readline", "process.argv",
  // File input
  "fs.readFileSync", "file_get_contents", "open(",
  // Message queues
  "kafka.consume", "rabbitmq.consume", "sqs.receiveMessage",
  // Browser APIs
  "window.location", "document.cookie", "localStorage.getItem", "sessionStorage.getItem",
  // Blockchain calldata, Smart contract storage
  "msg.data", "msg.value", "msg.sender", "tx.origin", "block.timestamp",
  "sload", "storage["
];

export const TaintSinks = [
  // SQL execution
  "query(", "execute(", "exec(", "db.raw(", "mysqli_query(", "PDO::query(",
  // Shell execution
  "exec(", "spawn(", "system(", "popen(", "os.system(", "subprocess.Popen(",
  // DOM insertion
  "innerHTML", "dangerouslySetInnerHTML", "document.write(",
  // Template rendering
  "renderToString(", "ejs.render(", "twig.render(", "jinja2.Template(",
  // Eval execution
  "eval(", "setTimeout(", "setInterval(", "Function(",
  // Serialization, Deserialization
  "JSON.parse(", "pickle.loads(", "yaml.load(", "unserialize(", "ObjectInputStream.readObject(",
  // Reflection, Native bindings
  "Reflect.apply", "Method.invoke", "ffi.Library",
  // Filesystem writes
  "fs.writeFile", "fs.writeFileSync", "file_put_contents",
  // Network execution
  "fetch(", "axios(", "requests.get(", "http.request"
];

export const Sanitizers = [
  "escape(", "sanitize(", "encodeURIComponent(", "DOMPurify.sanitize(",
  "mysql.escape(", "htmlentities(", "htmlspecialchars(", "prepare(", "allowlist"
];

export interface TaintFlow {
  source: string;
  sink: string;
  path: string[];
  sanitizerGap: boolean;
}

export class GlobalTaintState {
  // map from "filename:funcName" -> list of argument indices that are passed to a sink
  public sinkFunctions: Map<string, Set<number>> = new Map();
  // map from "filename:funcName" -> returns tainted data
  public sourceFunctions: Map<string, boolean> = new Map();
  // map from "filename:funcName" -> object detailing internal taint flows
  public functionFlows: Map<string, any> = new Map();
}

export const globalTaintState = new GlobalTaintState();
