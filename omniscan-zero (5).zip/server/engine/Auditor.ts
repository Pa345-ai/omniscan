import { ScanContext } from "./Context";

export interface BugReportScores {
  exploitability: number;
  reachability: number;
  impact: number;
  chainability: number;
  privilegeEscalation: number;
  internetExposure: number;
  attackSurface: number;
  combinedRisk: number;
}

export interface BugReport {
  title: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  category: string;
  reasoning: string;
  solution: string;
  lineStart?: number;
  lineEnd?: number;
  columnStart?: number;
  columnEnd?: number;
  confidence: number; // 0 to 1
  cwe?: string;
  cvssScore?: number;
  cves?: string[];
  exploitDB?: boolean;
  exploit?: string;
  file?: string;
  aiExplanation?: string;
  isExploitable?: boolean;
  poc?: string;
  solutionPatch?: string;
  validation?: any;
  scores?: BugReportScores;
}

export abstract class BaseAuditor {
  abstract name: string;
  abstract category: string;

  abstract audit(code: string, context: ScanContext): Promise<BugReport[]>;

  protected createFinding(data: Partial<BugReport>): BugReport {
    return {
      title: data.title || "Unknown Issue",
      severity: data.severity || "Low",
      category: this.category,
      reasoning: data.reasoning || "No detailed proof provided.",
      solution: data.solution || "No solution provided.",
      confidence: data.confidence || 0.5,
      ...data
    };
  }
}
