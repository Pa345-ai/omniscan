import { ASTNode, Symbol, SecurityGraph, TaintFlow } from "./Types";

export interface RepoMetadata {
  languages: string[];
  frameworks: string[];
  entryPoints: string[];
  totalFiles: number;
}

export interface ContractMetadata {
  address: string;
  network: string;
  compiler: string;
  optimization: boolean;
  sourceFiles: { path: string; content: string }[];
}

export interface ScanResult {
  sourceType: 'code' | 'repo' | 'contract';
  findings: any[];
  metrics: {
    scanTime: number;
    filesProcessed: number;
    complexityScore: number;
  };
  reconstruction?: {
    monorepo?: boolean;
    apiMapping?: any;
    attackGraph?: any;
  };
}
