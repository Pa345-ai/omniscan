import puppeteer from 'puppeteer';
import ejs from 'ejs';
import path from 'path';
import { BugReport } from './Auditor';

interface ReportOptions {
    findings: BugReport[];
    reportType: 'executive' | 'technical';
    branding?: {
        companyName?: string;
        primaryColor?: string;
    };
}

export async function generatePdfReport(options: ReportOptions): Promise<Buffer> {
    const { findings, reportType, branding = {} } = options;

    const stats = {
        high: findings.filter(f => f.severity === 'High').length,
        medium: findings.filter(f => f.severity === 'Medium').length,
        low: findings.filter(f => f.severity === 'Low').length,
    };

    // Calculate overall risk score
    let totalRisk = 0;
    let count = 0;
    findings.forEach(f => {
        if (f.cvssScore) {
            totalRisk += f.cvssScore;
            count++;
        }
    });
    const riskScore = count > 0 ? (totalRisk / count) : 0;

    // Top Critical Issues
    const topIssues = findings
        .filter(f => f.severity === 'High')
        .sort((a, b) => (b.cvssScore || 0) - (a.cvssScore || 0))
        .slice(0, 3);

    // Remediation Roadmap sorted by CVSS sum/severity
    const sortedRoadmap = [...findings]
        .sort((a, b) => (b.cvssScore || 0) - (a.cvssScore || 0));

    const templatePath = path.join(process.cwd(), 'server', 'templates', 'report.ejs');
    
    const html = await ejs.renderFile(templatePath, {
        findings,
        reportType,
        branding,
        stats,
        riskScore,
        topIssues,
        sortedRoadmap
    });

    const browser = await puppeteer.launch({
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    try {
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'domcontentloaded' });
        
        const pdfBuffer = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: {
                top: '20mm',
                right: '20mm',
                bottom: '20mm',
                left: '20mm'
            }
        });
        
        return Buffer.from(pdfBuffer);
    } finally {
        await browser.close();
    }
}
