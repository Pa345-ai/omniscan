
export class AliasAnalyzer {
  private aliasMap: Map<string, Set<string>> = new Map();

  addAlias(name1: string, name2: string) {
    if (!this.aliasMap.has(name1)) this.aliasMap.set(name1, new Set());
    if (!this.aliasMap.has(name2)) this.aliasMap.set(name2, new Set());
    
    this.aliasMap.get(name1)?.add(name2);
    this.aliasMap.get(name2)?.add(name1);
    
    // Transitive closure (simple)
    const set1 = this.aliasMap.get(name1)!;
    const set2 = this.aliasMap.get(name2)!;
    set2.forEach(name => set1.add(name));
    set1.forEach(name => this.aliasMap.get(name)?.add(name2));
  }

  isAlias(name1: string, name2: string): boolean {
    if (name1 === name2) return true;
    return this.aliasMap.get(name1)?.has(name2) || false;
  }

  getAliases(name: string): string[] {
    return Array.from(this.aliasMap.get(name) || []);
  }

  analyze(instructions: any[]) {
    instructions.forEach(inst => {
      // Very basic alias detection: a = b
      if (inst.opcode === "STORE" || inst.opcode === "MOVE") {
        if (typeof inst.operands[0] === 'string' && typeof inst.operands[1] === 'string') {
          this.addAlias(inst.operands[0], inst.operands[1]);
        }
      }
    });
  }
}
