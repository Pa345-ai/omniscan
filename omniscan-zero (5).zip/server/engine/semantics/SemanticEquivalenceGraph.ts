import { ASTNode } from "../Types";

export class SemanticEquivalenceGraph {
    private equivalenceSets = new Map<string, any[]>();

    public buildGraph(ast: ASTNode, originalCode: string, normalizedIR: any): any {
        console.log("[SemanticEquivalenceGraph] Constructing Semantic Equivalence Graph...");
        
        // Match different AST shapes to the same normalized semantics
        this.walk(ast, (node) => {
            if (node.type.includes("Assignment") || node.type.includes("VariableSet")) {
                const semanticIdentity = "memory_write";
                if (!this.equivalenceSets.has(semanticIdentity)) {
                    this.equivalenceSets.set(semanticIdentity, []);
                }
                this.equivalenceSets.get(semanticIdentity)?.push({
                    nodeId: `node_${node.start}`,
                    raw: node.raw,
                    semanticIdentity
                });
            }
        });

        return {
            graphType: "SemanticEquivalence",
            nodesMapped: this.equivalenceSets.size,
            equivalenceSets: Array.from(this.equivalenceSets.entries())
        };
    }

    private walk(node: ASTNode, callback: (node: ASTNode) => void) {
        callback(node);
        node.children.forEach(c => this.walk(c, callback));
    }
}
