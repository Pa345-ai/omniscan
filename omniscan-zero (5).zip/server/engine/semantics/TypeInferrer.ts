
export class TypeInferrer {
  private types: Map<string, string> = new Map();

  infer(expr: any): string {
    if (typeof expr === 'number') return 'number';
    if (typeof expr === 'boolean') return 'boolean';
    if (typeof expr === 'string') {
        if (expr.startsWith('0x')) return 'address';
        return 'string';
    }
    
    // Complex expressions
    if (expr.op === "+" || expr.op === "-") return this.infer(expr.args[0]);
    if (expr.op === ">" || expr.op === "==") return 'boolean';

    return "unknown";
  }

  assignType(name: string, type: string) {
    this.types.set(name, type);
  }

  getType(name: string): string {
    return this.types.get(name) || "unknown";
  }
}
