
import { SymbolTable } from "./SymbolTable";
import { SSAGenerator } from "./SSAGenerator";
import { AliasAnalyzer } from "./AliasAnalyzer";
import { TypeInferrer } from "./TypeInferrer";
import { MemoryModel } from "./MemoryModel";
import { SymbolType } from "./Types";
import { UnifiedIR, OpCode } from "../ir/IRTypes";

export class SemanticAnalyzer {
  private symbols = new SymbolTable();
  private ssa = new SSAGenerator();
  private aliases = new AliasAnalyzer();
  private types = new TypeInferrer();
  private memory = new MemoryModel();

  analyze(ir: UnifiedIR): any {
    console.log(`[Semantic] Running semantic enrichment on ${ir.functions.size} functions...`);

    const allInstructions: any[] = [];
    ir.functions.forEach(func => {
      func.blocks.forEach(block => {
        allInstructions.push(...block.instructions);
      });
    });

    // 1. Symbol Resolution & Type Inference
    allInstructions.forEach((inst: any) => {
      // Mapping IR fields (opcode, operands) to semantic analyzer expectations
      if (inst.opcode === "STORE" || inst.opcode === "DECLARE") {
        const target = inst.operands[0];
        this.symbols.defineSymbol(target, SymbolType.VARIABLE, inst.metadata?.line || 0);
        
        if (inst.operands[1]) {
            const inferred = this.types.infer(inst.operands[1]);
            if (inferred !== "unknown") this.types.assignType(target, inferred);
        }
      }
    });

    // 2. Alias Analysis
    this.aliases.analyze(allInstructions);

    // 3. SSA Transformation (In-place on IR)
    ir.functions.forEach(func => this.ssa.analyze(func));

    // 4. Memory Modeling
    allInstructions.forEach((inst: any) => {
      if (inst.opcode === OpCode.NEW_OBJECT || inst.opcode === "MALLOC" || inst.opcode === OpCode.CALL) {
         if (inst.operands[0] === "new" || inst.opcode === OpCode.NEW_OBJECT) {
            this.memory.allocate("Object", inst.metadata?.line || 0);
         }
      }
    });

    return {
      ir, // Return enriched IR
      symbols: this.symbols.getAllSymbols(),
      leakedObjects: this.memory.getEscapingObjects()
    };
  }
}
