import { ASTNode } from "../Types";

export class ImportResolver {
    private importMap: Map<string, string[]> = new Map();

    async resolve(filename: string, ast: ASTNode): Promise<string[]> {
        const discovered = ast.metadata?.imports || [];
        console.log(`[ImportResolver] Found ${discovered.length} imports in ${filename}`);
        this.importMap.set(filename, discovered);
        return discovered;
    }

    getDependencies(filename: string): string[] {
        return this.importMap.get(filename) || [];
    }

    buildGlobalDependantGraph(): any {
        // Build project-wide dependency graph
        return Array.from(this.importMap.entries());
    }
}
