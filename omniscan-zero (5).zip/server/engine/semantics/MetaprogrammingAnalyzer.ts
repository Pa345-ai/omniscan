import { ASTNode } from "../Types";

export class MetaprogrammingAnalyzer {
  public analyze(ast: ASTNode, language: string): any {
    console.log(`[MetaprogrammingAnalyzer] Deep analyzing reflection and metaprogramming paradigms for ${language}`);
    const reflectionPoints: any[] = [];
    const proxyBehaviors: any[] = [];
    const dynamicInvokes: any[] = [];

    this.walk(ast, (node) => {
        const raw = node.raw || "";
        // Proxy and dynamic interceptors
        if (raw.includes("Proxy") || raw.includes("method_missing") || (/\\b__getattr__\\b/).test(raw) || (/\\bReflectionClass\\b/).test(raw)) {
            proxyBehaviors.push({ nodeType: node.type, start: node.start, raw: raw });
        }
        
        // Deep reflection modeling
        if (raw.includes("reflect") || raw.includes("Object.getOwnPropertyDescriptor") || raw.includes("getDeclaredMethod")) {
            reflectionPoints.push({ nodeType: node.type, start: node.start, raw: raw });
        }

        // Eval and dynamic invocations
        if (raw.includes("eval(") || raw.includes("setTimeout(") || raw.includes("Function(") || raw.includes("send(")) {
             dynamicInvokes.push({ nodeType: node.type, start: node.start, raw: raw });
        }
    });

    return {
        hasMetaprogramming: reflectionPoints.length > 0 || proxyBehaviors.length > 0,
        reflectionPoints,
        proxyBehaviors,
        dynamicInvokes
    };
  }

  private walk(node: ASTNode, callback: (node: ASTNode) => void) {
      callback(node);
      node.children.forEach(c => this.walk(c, callback));
  }
}
