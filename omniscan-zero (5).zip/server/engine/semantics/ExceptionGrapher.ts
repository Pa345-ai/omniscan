import { ASTNode } from "../Types";

export class ExceptionGrapher {
  public buildGraph(ast: ASTNode): any {
    console.log(`[ExceptionGrapher] Building global exception graph`);
    
    // Nodes: Functions, TryBlocks, CatchBlocks, FinallyBlocks
    // Edges: Throws -> Catches, Try -> Finally
    
    const tryBlocks: any[] = [];
    const catchEdges: any[] = [];
    const throwPoints: any[] = [];

    this.walk(ast, (node) => {
        const type = node.type.toLowerCase();
        if (type.includes("try")) {
            tryBlocks.push({ id: `try_${node.start}`, start: node.start, end: node.end });
        }
        if (type.includes("catch") || type.includes("except")) {
            catchEdges.push({ id: `catch_${node.start}`, start: node.start, captures: node.raw?.match(/catch\\s*\\((.*?)\\)/)?.[1] || "Any" });
        }
        if (type.includes("throw") || type.includes("raise")) {
            throwPoints.push({ id: `throw_${node.start}`, start: node.start, type: node.type });
        }
    });

    return {
        tryBlocks,
        catchEdges,
        throwPoints,
        // Mocked directed graph paths for unhandled paths
        unhandledExceptions: throwPoints.filter(t => !tryBlocks.some(tryb => t.start > tryb.start && t.start < tryb.end))
    };
  }

  private walk(node: ASTNode, callback: (node: ASTNode) => void) {
      callback(node);
      node.children.forEach(c => this.walk(c, callback));
  }
}
