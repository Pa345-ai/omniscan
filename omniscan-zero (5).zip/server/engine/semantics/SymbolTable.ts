
import { SemanticSymbol, Scope, SymbolType } from "./Types";

export class SymbolTable {
  private scopes: Map<string, Scope> = new Map();
  private currentScopeId: string = "root";

  constructor() {
    this.scopes.set("root", { id: "root", symbols: new Map(), children: [] });
  }

  enterScope(id: string) {
    const newScope: Scope = {
      id,
      parentId: this.currentScopeId,
      symbols: new Map(),
      children: []
    };
    this.scopes.get(this.currentScopeId)?.children.push(id);
    this.scopes.set(id, newScope);
    this.currentScopeId = id;
  }

  exitScope() {
    const current = this.scopes.get(this.currentScopeId);
    if (current?.parentId) {
      this.currentScopeId = current.parentId;
    }
  }

  defineSymbol(name: string, type: SymbolType, line: number, dataType?: string): SemanticSymbol {
    const symbol: SemanticSymbol = {
      id: `${this.currentScopeId}_${name}_${Date.now()}`,
      name,
      type,
      dataType,
      scopeId: this.currentScopeId,
      references: [],
      definitionLine: line,
      isConstant: false
    };
    this.scopes.get(this.currentScopeId)?.symbols.set(name, symbol);
    return symbol;
  }

  resolve(name: string): SemanticSymbol | undefined {
    let scopeId: string | undefined = this.currentScopeId;
    while (scopeId) {
      const scope = this.scopes.get(scopeId);
      const symbol = scope?.symbols.get(name);
      if (symbol) return symbol;
      scopeId = scope?.parentId;
    }
    return undefined;
  }

  getAllSymbols(): SemanticSymbol[] {
    const all: SemanticSymbol[] = [];
    this.scopes.forEach(s => {
      s.symbols.forEach(sym => all.push(sym));
    });
    return all;
  }
}
