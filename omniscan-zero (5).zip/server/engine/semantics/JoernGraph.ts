import { ASTNode } from "../Types";

export interface GraphNode {
    id: number;
    label: string;
    properties: Record<string, any>;
}

export interface GraphEdge {
    from: number;
    to: number;
    label: string;
}

export class CodePropertyGraph {
    private nodes: GraphNode[] = [];
    private edges: GraphEdge[] = [];
    private nextId = 0;

    build(ast: ASTNode, ir: any): any {
        console.log("[Joern] Building Code Property Graph (AST + CFG + DFG)");
        
        const astRoot = this.addNode("AST_NODE", { type: ast.type, raw: ast.raw });
        this.processAst(ast, astRoot);
        
        // Connect to IR (CFG/DFG)
        if (ir && ir.operations) {
            ir.operations.forEach((op: any, i: number) => {
                const opNode = this.addNode("IR_OP", { op: op.op, details: JSON.stringify(op) });
                this.addEdge(astRoot, opNode, "GENERATES");
            });
        }

        return { nodes: this.nodes, edges: this.edges };
    }

    private processAst(node: ASTNode, parentId: number) {
        node.children.forEach(child => {
            const childId = this.addNode("AST_NODE", { type: child.type, raw: child.raw });
            this.addEdge(parentId, childId, "CONTAINS");
            this.processAst(child, childId);
        });
    }

    private addNode(label: string, properties: any): number {
        const id = this.nextId++;
        this.nodes.push({ id, label, properties });
        return id;
    }

    private addEdge(from: number, to: number, label: string) {
        this.edges.push({ from, to, label });
    }
}
