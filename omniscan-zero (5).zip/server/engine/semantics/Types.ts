
export enum SymbolType {
  VARIABLE = "VARIABLE",
  FUNCTION = "FUNCTION",
  CLASS = "CLASS",
  MODULE = "MODULE",
  PARAMETER = "PARAMETER",
  STORAGE_SLOT = "STORAGE_SLOT"
}

export interface SemanticSymbol {
  id: string;
  name: string;
  type: SymbolType;
  dataType?: string;
  scopeId: string;
  references: number[]; // Line numbers or IR indices
  definitionLine: number;
  isConstant: boolean;
  metadata?: any;
}

export interface Scope {
  id: string;
  parentId?: string;
  symbols: Map<string, SemanticSymbol>;
  children: string[];
}

export interface MemoryRegion {
  id: string;
  type: "STACK" | "HEAP" | "STORAGE" | "CALLDATA";
  size?: number;
  isShared: boolean;
}

export interface SSAVariable {
  originalName: string;
  version: number;
  symbolId: string;
}
