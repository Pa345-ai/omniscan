import { ASTNode } from "../Types";

export class SemgrepEngine {
    match(ast: ASTNode, pattern: string): boolean {
        // Pattern like "eval(...)" or "$VAR = eval(...)"
        const isEllipsis = pattern.includes("...");
        const metavariables = pattern.match(/\$[A-Z0-9_]+/g) || [];

        console.log(`[Semgrep] Matching pattern: ${pattern} (Ellipsis: ${isEllipsis}, Metavars: ${metavariables.join(",")})`);

        let found = false;
        this.walk(ast, (node) => {
            if (this.nodeMatch(node, pattern)) {
                found = true;
            }
        });

        return found;
    }

    private nodeMatch(node: ASTNode, pattern: string): boolean {
        // Simple heuristic matching
        const cleanPattern = pattern.replace(/\.\.\./g, "").replace(/\$[A-Z0-9_]+/g, "");
        if (node.raw?.includes(cleanPattern.trim())) {
            return true;
        }
        return false;
    }

    private walk(node: ASTNode, callback: (node: ASTNode) => void) {
        callback(node);
        node.children.forEach(c => this.walk(c, callback));
    }
}
