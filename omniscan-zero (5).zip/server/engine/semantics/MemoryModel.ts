
import { MemoryRegion } from "./Types";

export interface HeapObject {
  id: string;
  type: string;
  fields: Map<string, string>; // field name -> object id or value
  allocationLine: number;
  regionId: string;
}

export class MemoryModel {
  private regions: Map<string, MemoryRegion> = new Map();
  private heap: Map<string, HeapObject> = new Map();

  constructor() {
    this.regions.set("STACK", { id: "STACK", type: "STACK", isShared: false });
    this.regions.set("HEAP", { id: "HEAP", type: "HEAP", isShared: true });
    this.regions.set("STORAGE", { id: "STORAGE", type: "STORAGE", isShared: true });
  }

  allocate(type: string, line: number, regionId: string = "HEAP"): HeapObject {
    const id = `obj_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const obj: HeapObject = {
      id,
      type,
      fields: new Map(),
      allocationLine: line,
      regionId
    };
    this.heap.set(id, obj);
    return obj;
  }

  writeField(objId: string, field: string, value: string) {
    const obj = this.heap.get(objId);
    if (obj) {
      obj.fields.set(field, value);
    }
  }

  getEscapingObjects(): HeapObject[] {
    // Objects allocated in a function that persist or are returned (simplified)
    return Array.from(this.heap.values()).filter(obj => obj.regionId === "HEAP" || obj.regionId === "STORAGE");
  }
}
