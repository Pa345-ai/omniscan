import { ASTNode } from "../Types";

export class AsyncCoroutineGrapher {
  public buildGraph(ast: ASTNode): any {
    console.log(`[AsyncCoroutineGrapher] Constructing Async/Await and Coroutine execution graphs`);
    
    // Async/await graphing & Coroutine analysis
    const asyncFunctions: any[] = [];
    const awaitPoints: any[] = [];
    const yieldPoints: any[] = [];
    const coroutines: any[] = [];

    this.walk(ast, (node) => {
        const raw = node.raw || "";
        const type = node.type.toLowerCase();

        if (type.includes("function") && raw.includes("async ")) {
            asyncFunctions.push({ id: `async_fn_${node.start}`, name: node.metadata?.symbolId || "anonymous" });
        }

        if (raw.includes("await ")) {
            awaitPoints.push({ id: `await_${node.start}`, inside: "unknown" });
        }

        if (raw.includes("yield ")) {
            yieldPoints.push({ id: `yield_${node.start}`, signature: raw.substring(0, 30) });
        }

        if (type.includes("generator") || type.includes("coroutine") || raw.includes("function*")) {
            coroutines.push({ id: `coroutine_${node.start}` });
        }
    });

    return {
        asyncFunctions,
        awaitPoints,
        yieldPoints,
        coroutines,
        asyncStateTransitions: awaitPoints.length + yieldPoints.length
    };
  }

  private walk(node: ASTNode, callback: (node: ASTNode) => void) {
      callback(node);
      node.children.forEach(c => this.walk(c, callback));
  }
}
