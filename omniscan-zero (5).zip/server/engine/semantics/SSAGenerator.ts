
import { UnifiedIR, IRFunction, BasicBlock, IRInstruction, OpCode } from "../ir/IRTypes";
import { SSAVariable } from "./Types";

export class SSAGenerator {
  private versions: Map<string, number> = new Map();
  private blockVersions: Map<string, Map<string, number>> = new Map();

  // Transforms an entire IRFunction into SSA form
  analyze(func: IRFunction) {
    console.log(`[SSA] Transforming function ${func.name} to SSA form...`);
    
    // Visit blocks in topological order or simple iteration for now
    func.blocks.forEach((block, id) => {
      this.transformBlock(block);
    });
  }

  private transformBlock(block: BasicBlock) {
    const currentBlockVersions = new Map<string, number>(this.versions);
    
    block.instructions = block.instructions.map(inst => {
      // 1. Inputs use the latest version before this point
      const operands = inst.operands.map((op, i) => {
        if (i > 0 && typeof op === 'string' && this.isVariable(op)) {
          return this.getLatestVersion(op);
        }
        return op;
      });

      // 2. Definition creates a new version
      let target = inst.operands[0];
      if (typeof target === 'string' && (inst.opcode === OpCode.STORE || inst.opcode === OpCode.DECLARE || inst.opcode === OpCode.UNTRUSTED)) {
        target = this.createNewVersion(target);
      }

      return {
        ...inst,
        operands: [target, ...operands.slice(1)]
      };
    });

    this.blockVersions.set(block.id, new Map(this.versions));
  }

  private isVariable(name: string): boolean {
    // Basic heuristic: not a number, not a special keyword, matches identifier pattern
    return !name.startsWith('0x') && isNaN(Number(name)) && !!name.match(/^[a-zA-Z_$][a-zA-Z0-9_$]*$/);
  }

  private createNewVersion(name: string): string {
    const version = (this.versions.get(name) || 0) + 1;
    this.versions.set(name, version);
    return `${name}_v${version}`;
  }

  private getLatestVersion(name: string): string {
    const version = this.versions.get(name) || 0;
    return `${name}_v${version}`;
  }
}
