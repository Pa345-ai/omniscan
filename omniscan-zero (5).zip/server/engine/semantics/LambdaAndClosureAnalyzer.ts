import { ASTNode } from "../Types";

export class LambdaAndClosureAnalyzer {
  public analyze(ast: ASTNode): any {
    console.log(`[LambdaAndClosureAnalyzer] Mapping lambdas and closures...`);
    
    const closures: any[] = [];
    const lambdas: any[] = [];

    this.walk(ast, (node) => {
        const isArrow = node.type === "ArrowFunctionExpression" || (node.raw?.includes("=>"));
        const isLambda = node.raw?.includes("lambda ") || node.type.includes("lambda");
        
        if (isArrow || isLambda) {
            lambdas.push({
                id: `lambda_${node.start}`,
                signature: node.raw?.substring(0, 30),
                isAnonymous: true
            });

            // Closure Capture Analysis: Identify variables used but not declared inside
            closures.push({
                nodeId: `lambda_${node.start}`,
                capturedVariables: this.inferCaptures(node)
            });
        }
    });

    return {
        lambdas,
        closures,
        captureGraph: closures.flatMap(c => c.capturedVariables)
    };
  }

  private inferCaptures(node: ASTNode): string[] {
      // Heuristically map capture
      const captures = [];
      const raw = node.raw || "";
      if (raw.includes("this.")) captures.push("this");
      if (raw.includes("process.")) captures.push("process");
      if (raw.includes("global")) captures.push("global");
      // Add typical outside scope dependencies found
      return captures;
  }

  private walk(node: ASTNode, callback: (node: ASTNode) => void) {
      callback(node);
      node.children.forEach(c => this.walk(c, callback));
  }
}
