import fs from "fs-extra";
import path from "path";

export class ProjectMapper {
  async detect(dirPath: string): Promise<string[]> {
    const files = await this.getAllFiles(dirPath);
    const extensions = new Set<string>();
    
    files.forEach(file => {
      const ext = path.extname(file).toLowerCase();
      if (ext) extensions.add(ext.slice(1));
    });

    const langMap: Record<string, string> = {
      ts: "TypeScript",
      tsx: "TypeScript React",
      js: "JavaScript",
      jsx: "JavaScript React",
      py: "Python",
      go: "Go",
      rs: "Rust",
      sol: "Solidity",
      php: "PHP",
      java: "Java",
      c: "C",
      cpp: "C++",
      cs: "C#",
      rb: "Ruby",
      evm: "EVM Bytecode"
    };

    return Array.from(extensions).map(ext => langMap[ext]).filter(Boolean);
  }

  async detectFileLanguage(filePath: string): Promise<string | null> {
    const ext = path.extname(filePath).toLowerCase();
    const extMap: Record<string, string> = {
      ".ts": "typescript", ".tsx": "typescript",
      ".js": "javascript", ".jsx": "javascript",
      ".py": "python", ".go": "go", ".java": "java",
      ".rs": "rust", ".c": "c", ".cpp": "cpp", ".cc": "cpp",
      ".rb": "ruby", ".php": "php", ".sol": "solidity",
      ".sh": "bash", ".bash": "bash", ".cs": "csharp",
      ".css": "css", ".yaml": "yaml", ".yml": "yaml", ".tf": "terraform",
      ".evm": "evm"
    };

    if (ext && extMap[ext]) {
      return extMap[ext];
    }

    const filename = path.basename(filePath).toLowerCase();
    if (filename === 'dockerfile') return 'dockerfile';
    if (filename === 'docker-compose.yaml' || filename === 'docker-compose.yml') return 'yaml';

    // Attempt shebang detection
    try {
      const buffer = Buffer.alloc(256);
      const fd = await fs.open(filePath, 'r');
      await fs.read(fd, buffer, 0, 256, 0);
      await fs.close(fd);
      
      const content = buffer.toString('utf8');
      if (content.startsWith("#!")) {
        const firstLine = content.split("\n")[0];
        if (firstLine.includes("python")) return "python";
        if (firstLine.includes("node")) return "javascript";
        if (firstLine.includes("ruby")) return "ruby";
        if (firstLine.includes("php")) return "php";
        if (firstLine.includes("bash") || firstLine.includes("sh")) return "bash";
      }
    } catch (e) {
      // Ignore read errors
    }

    return null;
  }

  async isMonorepo(dirPath: string): Promise<boolean> {
    const indicators = ["lerna.json", "pnpm-workspace.yaml", "nx.json"];
    for (const indicator of indicators) {
      if (await fs.pathExists(path.join(dirPath, indicator))) return true;
    }
    // Check for "packages" directory
    if (await fs.pathExists(path.join(dirPath, "packages"))) return true;
    return false;
  }

  async mapAPIRoutes(dirPath: string): Promise<string[]> {
    const routes: string[] = [];
    const files = await this.getAllFiles(dirPath);
    
    for (const file of files) {
      if (file.includes("route") || file.includes("controller") || file.includes("api/")) {
        const content = await fs.readFile(file, 'utf8');
        const matches = content.match(/@(?:Get|Post|Put|Delete)\(['"]([^'"]+)['"]\)/g);
        if (matches) {
          matches.forEach(m => routes.push(m));
        }
        // Express style
        const expressMatches = content.match(/\.(?:get|post|put|delete)\(['"]([^'"]+)['"]/g);
        if (expressMatches) {
          expressMatches.forEach(m => routes.push(m));
        }
      }
    }
    return routes;
  }

  async resolveDependencies(dirPath: string): Promise<Record<string, string[]>> {
    const deps: Record<string, string[]> = {};

    // 1. NPM/Yarn/PNPM
    const pkgPath = path.join(dirPath, "package.json");
    if (await fs.pathExists(pkgPath)) {
      const pkg = await fs.readJson(pkgPath);
      deps['npm'] = Object.keys({ ...pkg.dependencies, ...pkg.devDependencies });
    }

    // 2. Python (Pip)
    const reqPath = path.join(dirPath, "requirements.txt");
    if (await fs.pathExists(reqPath)) {
      const content = await fs.readFile(reqPath, 'utf8');
      deps['pip'] = content.split('\n').map(line => line.split('==')[0].split('>')[0].split('<')[0].trim()).filter(l => l && !l.startsWith('#'));
    }

    // 3. Rust (Cargo)
    const cargoPath = path.join(dirPath, "Cargo.toml");
    if (await fs.pathExists(cargoPath)) {
      const content = await fs.readFile(cargoPath, 'utf8');
      const depMatch = content.match(/\[dependencies\]([\s\S]*?)(\n\[|$)/);
      if (depMatch) {
        deps['cargo'] = depMatch[1].split('\n').map(l => l.split('=')[0].trim()).filter(l => l && !l.startsWith('#') && !l.startsWith('['));
      }
    }

    // 4. Solidity (Foundry/Remappings)
    const foundryPath = path.join(dirPath, "foundry.toml");
    const remappingsPath = path.join(dirPath, "remappings.txt");
    if (await fs.pathExists(remappingsPath)) {
      const content = await fs.readFile(remappingsPath, 'utf8');
      deps['foundry'] = content.split('\n').filter(l => l.trim()).map(l => l.split('=')[0].trim());
    } else if (await fs.pathExists(foundryPath)) {
      deps['foundry'] = ["Foundry Config Detected"];
    }

    return deps;
  }

  async detectFrameworks(dirPath: string): Promise<string[]> {
    const frameworks: string[] = [];
    const pkgPath = path.join(dirPath, "package.json");
    
    if (await fs.pathExists(pkgPath)) {
      const pkg = await fs.readJson(pkgPath);
      const deps = { ...pkg.dependencies, ...pkg.devDependencies };
      
      if (deps['express']) frameworks.push("Express");
      if (deps['next']) frameworks.push("Next.js");
      if (deps['@nestjs/core']) frameworks.push("NestJS");
      if (deps['react']) frameworks.push("React");
      if (deps['vue']) frameworks.push("Vue");
    }

    const reqPath = path.join(dirPath, "requirements.txt");
    if (await fs.pathExists(reqPath)) {
      const reqs = await fs.readFile(reqPath, 'utf8');
      if (reqs.includes("django")) frameworks.push("Django");
      if (reqs.includes("flask")) frameworks.push("Flask");
      if (reqs.includes("fastapi")) frameworks.push("FastAPI");
    }

    return frameworks;
  }

  private async getAllFiles(dirPath: string): Promise<string[]> {
    const results: string[] = [];
    const list = await fs.readdir(dirPath);
    
    for (const file of list) {
      if (file === "node_modules" || file === ".git") continue;
      
      const filePath = path.join(dirPath, file);
      const stat = await fs.stat(filePath);
      
      if (stat && stat.isDirectory()) {
        results.push(...(await this.getAllFiles(filePath)));
      } else {
        results.push(filePath);
      }
    }
    return results;
  }
}
