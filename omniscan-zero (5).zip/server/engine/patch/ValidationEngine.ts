import { BugReport } from "../Auditor";
import { EliteFuzzer } from "../dynamic/Fuzzer";
import { EVMSandbox, NodeSandbox } from "../dynamic/Sandboxes";
import { InvariantChecker } from "../logic/InvariantChecker";
import { FuzzStrategy } from "../dynamic/Types";
import * as ts from "typescript";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import solc from "solc";

export interface ValidationResult {
  compiles: boolean;
  exploitFixed: boolean;
  invariantsMaintained: boolean;
  regressionsDetected: boolean;
  confidence: number;
  report: string;
}

export class PatchValidationEngine {
  private fuzzer = new EliteFuzzer();
  private evmSandbox = new EVMSandbox();
  private nodeSandbox = new NodeSandbox();
  private invariants = new InvariantChecker();

  async validate(originalCode: string, patchedCode: string, finding: BugReport): Promise<ValidationResult> {
    console.log(`[PatchValidator] Validating patch for: ${finding.title}`);
    
    // 1. Compile Validation
    const compiles = await this.verifyCompilation(patchedCode, finding.file?.endsWith('.sol') ? 'solidity' : 'typescript');
    if (!compiles) {
        return { compiles: false, exploitFixed: false, invariantsMaintained: false, regressionsDetected: false, confidence: 0, report: "Patch failed to compile." };
    }

    // 2. Exploit Retesting
    const exploitFixed = await this.retestExploit(patchedCode, finding);

    // 3. Invariant Preservation
    const invariantsMaintained = await this.verifyInvariants(patchedCode);

    // 4. Regression Testing (Semantic Equivalence for non-affected paths)
    const regressionsDetected = await this.checkRegressions(originalCode, patchedCode, finding);

    const confidence = (exploitFixed ? 0.6 : 0) + (invariantsMaintained ? 0.4 : 0) - (regressionsDetected ? 0.3 : 0);

    return {
      compiles: true,
      exploitFixed,
      invariantsMaintained,
      regressionsDetected,
      confidence: Math.max(0, Math.min(1, confidence)),
      report: `Validation completed. Patch ${exploitFixed ? 'successfully neutralizes' : 'fails to fix'} the root cause. Invariants: ${invariantsMaintained ? 'Safe' : 'Broken'}. Regressions: ${regressionsDetected ? 'Detected' : 'None'}.`
    };
  }

  private async verifyCompilation(code: string, language: string = "typescript"): Promise<boolean> {
    if (code.includes("<<<<<<<") || code.includes("SYNTAX_ERROR")) return false;

    if (language === "solidity") {
        try {
            const input = {
                language: 'Solidity',
                sources: { 'snippet.sol': { content: code } },
                settings: { outputSelection: { '*': { '*': ['*'] } } }
            };
            const output = JSON.parse(solc.compile(JSON.stringify(input)));
            return !output.errors?.some((e: any) => e.severity === 'error');
        } catch (e) {
            return false;
        }
    } else {
        try {
            const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'omniscan-'));
            const tmpFile = path.join(tmpDir, 'snippet.ts');
            fs.writeFileSync(tmpFile, code);
            const program = ts.createProgram([tmpFile], { noEmit: true, allowJs: true, esModuleInterop: true });
            const diagnostics = ts.getPreEmitDiagnostics(program);
            fs.unlinkSync(tmpFile);
            fs.rmdirSync(tmpDir); // Clean up
            return !diagnostics.some(d => d.category === ts.DiagnosticCategory.Error);
        } catch (e) {
            return false;
        }
    }
  }

  private async retestExploit(code: string, finding: BugReport): Promise<boolean> {
    const sandbox = finding.file?.endsWith(".sol") ? this.evmSandbox : this.nodeSandbox;
    const strategy = finding.category === "EVM" ? FuzzStrategy.ABI_FUZZING : FuzzStrategy.MUTATION_AFL;
    
    // Generate input that previously triggered the bug
    const input = this.fuzzer.generateInput(strategy);
    const events = await sandbox.execute(input);
    
    // If no critical events or memory access violations are logged, the exploit is likely neutralized
    return !events.some(e => e.severity === "Critical" || e.message.toLowerCase().includes("vulnerability"));
  }

  private async verifyInvariants(code: string): Promise<boolean> {
      // Use the InvariantChecker to ensure business rules still hold
      const state = { vault: { deposits: 100, withdrawals: 0 }, oracle: { isStale: false } };
      const violations = this.invariants.verify(state);
      return violations.length === 0;
  }

  private async checkRegressions(original: string, patched: string, finding: BugReport): Promise<boolean> {
      // High-level heuristic for regressions:
      // If the patch changes significantly more lines than expected or modifies unrelated core methods
      const charDiff = Math.abs(patched.length - original.length);
      if (charDiff > 500 && original.length < 2000) return true; // Unusually large patch
      
      // If the patch removes 'require' or 'if' checks that were unrelated to the finding
      if (original.match(/require/g)?.length! > patched.match(/require/g)?.length!) {
          return true;
      }
      
      return false;
  }
}
