import { BugReport } from "./Auditor";

const CWEMap: Record<string, string> = {
  // general categories
  "Authentication": "CWE-287",
  "Authorization": "CWE-285",
  "Injection": "CWE-74",
  "SQL Injection": "CWE-89",
  "Cross-Site Scripting (XSS)": "CWE-79",
  "Cross-Site Request Forgery (CSRF)": "CWE-352",
  "XML External Entity (XXE)": "CWE-611",
  "Insecure Direct Object Reference (IDOR)": "CWE-639",
  "Security Misconfiguration": "CWE-16",
  "Sensitive Data Exposure": "CWE-200",
  "Broken Access Control": "CWE-284",
  "Server-Side Request Forgery (SSRF)": "CWE-918",
  "Command Injection": "CWE-77",
  "Data Flow Analysis": "CWE-20", // generic untrusted input
  "Cryptographic Failure": "CWE-327",
  "Supply Chain Risk": "CWE-1035", // Third party vulnerabilities
  "Taint Analysis": "CWE-20",
  "Logic Bug": "CWE-699"
};

// basic heuristic mapping based on category/title
export function enrichFinding(finding: BugReport): BugReport {
  let cwe = "CWE-1000"; // Generic

  for (const [key, val] of Object.entries(CWEMap)) {
    if (finding.category.includes(key) || finding.title.includes(key)) {
      cwe = val;
      break;
    }
  }
  
  if (finding.title.toLowerCase().includes("sql") || finding.title.toLowerCase().includes("database")) {
    cwe = "CWE-89";
  } else if (finding.title.toLowerCase().includes("xss") || finding.title.toLowerCase().includes("cross-site")) {
    cwe = "CWE-79";
  } else if (finding.title.toLowerCase().includes("command") && finding.title.toLowerCase().includes("injection")) {
    cwe = "CWE-77";
  } else if (finding.title.toLowerCase().includes("taint") || finding.title.toLowerCase().includes("unsanitized")) {
    cwe = "CWE-20";
  }

  finding.cwe = cwe;

  // CVSS v3.1 heuristic calculation
  // Severity High -> ~ 7.0 - 10.0
  // Medium -> ~ 4.0 - 6.9
  // Low -> ~ 0.1 - 3.9
  
  // Try to be dynamic based on confidence + exploitability
  // If no explicit exploit DB match initially, just random within range
  let baseScore = 0;
  if (finding.severity === "High") {
    baseScore = 7.0 + (finding.confidence * 2.9);
  } else if (finding.severity === "Medium") {
    baseScore = 4.0 + (finding.confidence * 2.9);
  } else if (finding.severity === "Low") {
    baseScore = 1.0 + (finding.confidence * 2.9);
  }

  // round to 1 decimal point
  finding.cvssScore = Math.round(baseScore * 10) / 10;
  
  // Set default values that might be overridden if real data is found (e.g. dependencies)
  finding.cves = finding.cves || [];
  finding.exploitDB = finding.exploitDB || false;
  
  // Heuristic exploit available if it's a very common standard web vulnerability
  if (finding.cwe === "CWE-89" || finding.cwe === "CWE-79" || finding.cwe === "CWE-77") {
    if (finding.severity === "High" && finding.confidence > 0.8) {
       finding.exploitDB = true; 
    }
  }

  return finding;
}

export async function lookupDependenciesOSV(dependencies: Record<string, string[]>): Promise<BugReport[]> {
  const findings: BugReport[] = [];
  try {
    for (const [ecosystem, deps] of Object.entries(dependencies)) {
      let osvEcosystem = "";
      if (ecosystem === "npm") osvEcosystem = "npm";
      else if (ecosystem === "python") osvEcosystem = "PyPI";
      else if (ecosystem === "go") osvEcosystem = "Go";
      else if (ecosystem === "ruby") osvEcosystem = "RubyGems";

      if (!osvEcosystem) continue;

      for (const dep of deps) {
        // Only checking dependency name for demo, normally would need version as well
        // For OSV API without version, it might return all vulns. Let's just limit to a few to prevent overwhelming
        const res = await fetch(`https://api.osv.dev/v1/query`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            package: {
              name: dep,
              ecosystem: osvEcosystem
            }
          })
        });

        if (res.ok) {
          const data = await res.json();
          if (data.vulns && data.vulns.length > 0) {
            // Sort by severity or take most recent
            const recentVuln = data.vulns[0];
            const aliases = recentVuln.aliases || [];
            const cves = aliases.filter((a: string) => a.startsWith("CVE-"));
            
            let severity = "Medium";
            let score = 5.0;
            if (recentVuln.database_specific && recentVuln.database_specific.severity) {
              severity = recentVuln.database_specific.severity;
            } else if (recentVuln.severity && recentVuln.severity.length > 0) {
              // Parse CVSS from vector if present, or just guess from score
               if (recentVuln.severity[0].score) score = parseFloat(recentVuln.severity[0].score);
               if (score >= 7.0) severity = "High";
               else if (score >= 4.0) severity = "Medium";
               else severity = "Low";
            }

            const report: BugReport = {
              title: `Vulnerable Dependency: ${dep}`,
              category: "Supply Chain Risk",
              severity: severity as any,
              reasoning: `The dependency \`${dep}\` has a known vulnerability: ${recentVuln.details || recentVuln.summary || 'Unspecified vulnerability in dependency.'}`,
              solution: `Update \`${dep}\` to a patched version. Check OSV or NVD for specific fixed versions.`,
              confidence: 0.99,
              cves: cves,
              cwe: "CWE-1352", // Generally supply chain / vulnerable dep
              cvssScore: score > 0 ? score : undefined,
              exploitDB: cves.length > 0 // Heuristic: if CVE assigned, often mapped or public
            };
            findings.push(report);
            
            // Limit to max 3 findings to avoid flooding the UI for OSV? Or perhaps we show all? 
            // We'll show all but only fetch for a subset if there are hundreds of deps.
          }
        }
      }
    }
  } catch (err) {
    console.error("OSV Lookup Failed:", err);
  }
  return findings;
}
