import axios from "axios";
import { BugReport } from "./Auditor";

export interface NotificationConfig {
  webhookUrl?: string;
  slackWebhookUrl?: string;
  discordWebhookUrl?: string;
  pagerDutyRoutingKey?: string;
}

export class NotificationService {
  private sentAlerts: Set<string> = new Set();

  async notify(repoName: string, findings: BugReport[], config: NotificationConfig) {
    const criticalFindings = findings.filter(f => f.severity === "High"); // High is our top severity
    
    if (criticalFindings.length === 0) return;

    for (const finding of criticalFindings) {
      const alertId = `${repoName}-${finding.title}-${finding.lineStart}`;
      
      if (this.sentAlerts.has(alertId)) continue;

      await this.sendToAll(repoName, finding, config);
      this.sentAlerts.add(alertId);
    }
  }

  private async sendToAll(repoName: string, finding: BugReport, config: NotificationConfig) {
    const promises: Promise<any>[] = [];

    if (config.slackWebhookUrl) {
      promises.push(this.sendToSlack(repoName, finding, config.slackWebhookUrl));
    }
    if (config.discordWebhookUrl) {
      promises.push(this.sendToDiscord(repoName, finding, config.discordWebhookUrl));
    }
    if (config.pagerDutyRoutingKey) {
      promises.push(this.sendToPagerDuty(repoName, finding, config.pagerDutyRoutingKey));
    }
    if (config.webhookUrl) {
      promises.push(this.sendGenericWebhook(repoName, finding, config.webhookUrl));
    }

    await Promise.allSettled(promises);
  }

  private async sendToSlack(repoName: string, finding: BugReport, url: string) {
    const message = {
      blocks: [
        {
          type: "header",
          text: { type: "plain_text", text: "🚨 Critical Security Finding Alert" }
        },
        {
          type: "section",
          fields: [
            { type: "mrkdwn", text: `*Repo:*\n${repoName}` },
            { type: "mrkdwn", text: `*Severity:*\n${finding.severity}` }
          ]
        },
        {
          type: "section",
          text: { type: "mrkdwn", text: `*Issue:*\n${finding.title}` }
        },
        {
          type: "section",
          text: { type: "mrkdwn", text: `*Reasoning:*\n${finding.reasoning}` }
        },
        {
          type: "actions",
          elements: [
            {
              type: "button",
              text: { type: "plain_text", text: "View Findings" },
              url: `https://your-app-url.com/scan-results` // Placeholder
            }
          ]
        }
      ]
    };
    return axios.post(url, message);
  }

  private async sendToDiscord(repoName: string, finding: BugReport, url: string) {
    const embed = {
      embeds: [{
        title: `🚨 Critical Finding: ${finding.title}`,
        color: 0xFF0000,
        fields: [
          { name: "Repository", value: repoName, inline: true },
          { name: "Severity", value: finding.severity, inline: true },
          { name: "Reasoning", value: finding.reasoning }
        ],
        timestamp: new Date().toISOString()
      }]
    };
    return axios.post(url, embed);
  }

  private async sendToPagerDuty(repoName: string, finding: BugReport, routingKey: string) {
    const event = {
      payload: {
        summary: `[CRITICAL] Smart Contract/Infra Vulnerability: ${finding.title} in ${repoName}`,
        severity: "critical",
        source: "AI Security Dashboard",
        component: "Code Scanner",
        group: "Security",
        custom_details: {
          reasoning: finding.reasoning,
          solution: finding.solution,
          cwe: finding.cwe
        }
      },
      routing_key: routingKey,
      event_action: "trigger"
    };
    return axios.post("https://events.pagerduty.com/v2/enqueue", event);
  }

  private async sendGenericWebhook(repoName: string, finding: BugReport, url: string) {
    return axios.post(url, {
      event: "security_finding",
      repo: repoName,
      finding
    });
  }
}
