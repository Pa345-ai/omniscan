
export enum FuzzStrategy {
  MUTATION_AFL = "AFL_MUTATION",
  GRAMMAR_BASED = "GRAMMAR_BASED",
  ABI_FUZZING = "ABI_FUZZING",
  HTTP_MUTATION = "HTTP_MUTATION",
  PROPERTY_BASED = "PROPERTY_BASED"
}

export interface FuzzInput {
  payload: Buffer | string | any;
  metadata: {
    source: string;
    strategy: FuzzStrategy;
    iteration: number;
    mutationType?: string;
  };
}

export interface RuntimeEvent {
  type: "CRASH" | "SYSCALL" | "MEMORY_ACCESS" | "STATE_CHANGE" | "LOG";
  severity: "Info" | "Warning" | "Critical";
  message: string;
  data?: any;
  timestamp: number;
}
