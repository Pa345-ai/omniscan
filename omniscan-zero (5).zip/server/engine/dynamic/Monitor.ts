
import { RuntimeEvent, FuzzInput } from "./Types";

export interface Sandbox {
  execute(input: FuzzInput): Promise<RuntimeEvent[]>;
  cleanup(): Promise<void>;
}

export class RuntimeMonitor {
  private events: RuntimeEvent[] = [];

  log(event: Omit<RuntimeEvent, 'timestamp'>) {
    this.events.push({ ...event, timestamp: Date.now() });
  }

  getEvents(): RuntimeEvent[] {
    return this.events;
  }

  clear() {
    this.events = [];
  }

  detectPatterns(): string[] {
    const issues: string[] = [];
    const memoryAccesses = this.events.filter(e => e.type === "MEMORY_ACCESS");
    
    // Simple Buffer Overflow detection heuristic
    if (memoryAccesses.some(e => e.message.includes("out of bounds"))) {
        issues.push("Dynamic Analysis: Buffer Overflow pattern detected during runtime execution.");
    }

    if (this.events.some(e => e.type === "CRASH")) {
        issues.push("Dynamic Analysis: Target process crashed during fuzzing (SIGSEGV/Access Violation).");
    }

    if (this.events.some(e => e.type === "SYSCALL" && e.severity === "Critical")) {
        issues.push("Dynamic Analysis: Dangerous syscall detected (execve / fork) in restricted context.");
    }

    // New pattern detection
    if (this.events.some(e => e.message.includes("deserialization"))) {
        issues.push("Dynamic Analysis: High-risk deserialization chain detected during object hydration.");
    }

    const stateChanges = this.events.filter(e => e.type === "STATE_CHANGE");
    if (this.detectRaceCondition(stateChanges)) {
        issues.push("Dynamic Analysis: Potential Race Condition detected (Dirty Read/TOCTOU) during concurrent state mutation.");
    }

    return issues;
  }

  private detectRaceCondition(states: RuntimeEvent[]): boolean {
      // Heuristic: same key written multiple times within very short timeframe without synchronization
      const writes = states.filter(s => s.message.includes("write"));
      for (let i = 0; i < writes.length - 1; i++) {
          if (writes[i+1].timestamp - writes[i].timestamp < 5) { // < 5ms
              return true;
          }
      }
      return false;
  }
}
