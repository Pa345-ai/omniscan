import { ASTNode } from "../Types";

export interface GraphNode {
    id: string;
    labels: string[];
    properties: Record<string, any>;
}

export interface GraphEdge {
    source: string;
    target: string;
    type: string;
    properties?: Record<string, any>;
}

export class SemanticDatabase {
    private nodes: Map<string, GraphNode> = new Map();
    private edges: GraphEdge[] = [];

    // Layer 3 - Semantic Database Capabilities
    public async buildDatabase(
        ast: ASTNode,
        ir: any,
        cpg: any,
        dependencies: string[],
        taintFlows: any[],
        callGraphData: any,
        objectGraphData: any,
        runtimeData: any,
        exploitData: any,
        orgData: any
    ) {
        console.log("[SemanticDatabase] Building Universal Code Graph Database...");

        // 1. AST Graph
        this.buildASTGraph(ast);

        // 2. CFG Graph (Control Flow)
        if (ir && ir.blocks) {
            this.buildCFGGraph(ir);
        }

        // 3. DFG Graph (Data Flow) - usually integrated in CPG or memory abstraction
        this.buildDFGGraph(ir);

        // 4. Call graph
        this.buildCallGraph(callGraphData);

        // 5. Taint graph
        this.buildTaintGraph(taintFlows);

        // 6. Dependency graph
        this.buildDependencyGraph(dependencies, ast);

        // 7. Object graph
        this.buildObjectGraph(objectGraphData);

        // 8. Runtime graph
        this.buildRuntimeGraph(runtimeData);

        // 9. Exploit graph
        this.buildExploitGraph(exploitData);

        // 10. Org-wide attack graph
        this.buildOrgAttackGraph(orgData);

        console.log(`[SemanticDatabase] Finished building. Nodes: ${this.nodes.size}, Edges: ${this.edges.length}`);
        return this.exportGraph();
    }

    private addNode(id: string, labels: string[], properties: Record<string, any> = {}) {
        if (!this.nodes.has(id)) {
            this.nodes.set(id, { id, labels, properties });
        }
    }

    private addEdge(source: string, target: string, type: string, properties: Record<string, any> = {}) {
        this.edges.push({ source, target, type, properties });
    }

    private buildASTGraph(ast: ASTNode, parentId?: string) {
        if (!ast) return;
        const nodeId = `ast_${ast.start}_${ast.type}`;
        this.addNode(nodeId, ["AST_NODE"], { type: ast.type, raw: ast.raw, start: ast.start, end: ast.end });
        
        if (parentId) {
            this.addEdge(parentId, nodeId, "AST_CHILD");
        }

        if (ast.children) {
            ast.children.forEach(child => this.buildASTGraph(child, nodeId));
        }
    }

    private buildCFGGraph(ir: any) {
        // Conceptually connect blocks in IR
        ir.blocks?.forEach((block: any) => {
            const blockId = `cfg_${block.id}`;
            this.addNode(blockId, ["CFG_BLOCK"], { operationsCount: block.operations?.length });
            block.successors?.forEach((succId: string) => {
                this.addEdge(blockId, `cfg_${succId}`, "CFG_FLOW");
            });
        });
    }

    private buildDFGGraph(ir: any) {
        // Extract DFG from IR memory abstraction & phi nodes
        ir.blocks?.forEach((block: any) => {
            block.phis?.forEach((phi: any) => {
                 this.addNode(`dfg_${phi.target}`, ["DFG_VAR"], { target: phi.target });
                 phi.sources?.forEach((src: string) => {
                     this.addEdge(`dfg_${src}`, `dfg_${phi.target}`, "DFG_FLOW");
                 });
            });
        });
    }

    private buildCallGraph(callGraphData: any) {
        // Standard Call Graph Structure
        if (!callGraphData) return;
        this.addNode("cg_root", ["CALL_GRAPH_ROOT"], {});
    }

    private buildTaintGraph(taintFlows: any[]) {
        taintFlows?.forEach((flow, idx) => {
            const taintId = `taint_${idx}`;
            this.addNode(taintId, ["TAINT_FLOW"], { description: flow.description });
        });
    }

    private buildDependencyGraph(dependencies: string[], ast: ASTNode) {
        const fileId = `file_${ast.start}`; // mock file ID
        this.addNode(fileId, ["FILE"], {});
        dependencies?.forEach(dep => {
            const depId = `dep_${dep}`;
            this.addNode(depId, ["DEPENDENCY"], { name: dep });
            this.addEdge(fileId, depId, "DEPENDS_ON");
        });
    }

    private buildObjectGraph(objectGraphData: any) {
        if (!objectGraphData) return;
        // From advanced IR objectGraph representation
        const ogRoot = "og_root";
        this.addNode(ogRoot, ["OBJECT_GRAPH_ROOT"]);
    }

    private buildRuntimeGraph(runtimeData: any) {
        if (!runtimeData) return;
        this.addNode("runtime_root", ["RUNTIME_GRAPH_ROOT"]);
    }

    private buildExploitGraph(exploitData: any) {
        if (!exploitData) return;
        this.addNode("exploit_root", ["EXPLOIT_GRAPH_ROOT"]);
    }

    private buildOrgAttackGraph(orgData: any) {
        if (!orgData) return;
        this.addNode("org_attack_root", ["ORG_ATTACK_GRAPH_ROOT"]);
    }

    public exportGraph() {
        return {
            nodes: Array.from(this.nodes.values()),
            edges: this.edges,
            queryEngine: "OmniScan Neo4j-like Cypher Engine Simulation"
        };
    }
}
