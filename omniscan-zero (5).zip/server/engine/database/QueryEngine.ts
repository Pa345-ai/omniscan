import { GraphEdge, GraphNode } from "./SemanticDatabase";

export class OmniscanQueryEngine {
    private nodes: Map<string, GraphNode> = new Map();
    private edges: GraphEdge[] = [];

    constructor(dbExport: { nodes: GraphNode[], edges: GraphEdge[] }) {
        dbExport.nodes.forEach(n => this.nodes.set(n.id, n));
        this.edges = dbExport.edges;
    }

    // 1. Semantic Queries
    public executeSemanticQuery(queryDSL: string): GraphNode[] {
        console.log(`[QueryEngine] Executing Semantic Query: ${queryDSL}`);
        // Simulated query parsing resembling CodeQL or Cypher
        if (queryDSL.includes("MATCH (n:AST_NODE) WHERE n.type = 'CallExpression'")) {
            return Array.from(this.nodes.values()).filter(n => n.labels.includes("AST_NODE") && n.properties.type === "CallExpression");
        }
        return [];
    }

    // 2. Vulnerability Pattern Queries
    public executeVulnerabiltyQuery(patternName: string): GraphNode[] {
        console.log(`[QueryEngine] Searching for vulnerability pattern: ${patternName}`);
        // Simple mock implementation
        if (patternName === "SQL_INJECTION") {
            return Array.from(this.nodes.values()).filter(n => 
                n.labels.includes("AST_NODE") && 
                n.properties.raw?.includes("SELECT") && 
                n.properties.raw?.includes("+")
            );
        }
        return [];
    }

    // 3. Graph Traversals
    public traverseGraph(startNodeId: string, edgeType: string, maxDepth: number = 5): GraphNode[] {
        console.log(`[QueryEngine] Traversing from ${startNodeId} via ${edgeType} up to depth ${maxDepth}`);
        const visited = new Set<string>();
        const result: GraphNode[] = [];
        
        const dfs = (currentId: string, depth: number) => {
            if (depth > maxDepth || visited.has(currentId)) return;
            visited.add(currentId);
            
            const node = this.nodes.get(currentId);
            if (node) result.push(node);

            const outgoingEdges = this.edges.filter(e => e.source === currentId && e.type === edgeType);
            outgoingEdges.forEach(e => dfs(e.target, depth + 1));
        };

        dfs(startNodeId, 0);
        return result;
    }

    // 4. Taint Traversals
    public executeTaintTraversal(sourceLabels: string[], sinkLabels: string[]): any[] {
        console.log(`[QueryEngine] Traversing Taint from ${sourceLabels.join("|")} to ${sinkLabels.join("|")}`);
        // Find path from any node with sourceLabel to any node with sinkLabel
        const taintPaths: any[] = [];
        
        // Mocked traversal using DFG_FLOW edges
        const sources = Array.from(this.nodes.values()).filter(n => sourceLabels.some(l => n.labels.includes(l)));
        const sinks = Array.from(this.nodes.values()).filter(n => sinkLabels.some(l => n.labels.includes(l)));

        sources.forEach(source => {
            sinks.forEach(sink => {
                const path = this.findPath(source.id, sink.id, "DFG_FLOW");
                if (path.length > 0) taintPaths.push({ source, sink, path });
            });
        });

        return taintPaths;
    }

    // 5. Exploitability Queries
    public assessExploitability(nodeId: string): number {
        console.log(`[QueryEngine] Assessing exploitability index for node ${nodeId}`);
        const node = this.nodes.get(nodeId);
        if (!node) return 0;
        
        // Calculate an exploitability score based on proximity to user input and execution sinks
        const distanceToInput = this.traverseGraph(nodeId, "DFG_FLOW", 10).length;
        return distanceToInput > 0 ? 0.8 : 0.2; // Mock score
    }

    private findPath(startId: string, endId: string, edgeType: string): string[] {
        // BFS for shortest path
        const queue: { id: string, path: string[] }[] = [{ id: startId, path: [startId] }];
        const visited = new Set<string>();

        while (queue.length > 0) {
            const { id, path } = queue.shift()!;
            if (id === endId) return path;

            if (!visited.has(id)) {
                visited.add(id);
                const nextEdges = this.edges.filter(e => e.source === id && e.type === edgeType);
                nextEdges.forEach(e => queue.push({ id: e.target, path: [...path, e.target] }));
            }
        }
        return [];
    }
}
