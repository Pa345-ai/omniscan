import { parentPort, workerData } from "worker_threads";
import { AuditorRegistry } from "./Registry";
import { ScanContext } from "./Context";
import { SemanticParser } from "./Parser";
import { FlowAnalyzer } from "./Flow";
import { InterproceduralAnalyzer } from "./Interprocedural";
import { PathAnalyzer } from "./PathAnalyzer";
import { IRTranslator } from "./ir/Translator";
import { SemanticAnalyzer } from "./semantics/SemanticAnalyzer";

const { code, filename, context } = workerData;

async function runAudit() {
  try {
    const parser = new SemanticParser();
    const flow = new FlowAnalyzer();
    const interprocedural = new InterproceduralAnalyzer();
    const pathSensitive = new PathAnalyzer();
    const translator = new IRTranslator();
    const semantic = new SemanticAnalyzer();

    const language = filename.endsWith(".sol") ? "solidity" : 
                     filename.endsWith(".py") ? "python" :
                     filename.endsWith(".go") ? "go" :
                     filename.endsWith(".rs") ? "rust" :
                     filename.endsWith(".java") ? "java" :
                     filename.endsWith(".move") ? "move" : "typescript";
    const ast = await parser.parseSourceToAST(code, language);
    const ir = translator.translate(ast, language);
    const semanticEnrichment = semantic.analyze(ir);
    const fullFlow = await flow.analyzeFullFlow(ir);
    const graph = await flow.buildExecutionGraph(ast);
    const interproceduralMetrics = await interprocedural.analyze(code, ir, graph);
    const unreachablePaths = await pathSensitive.resolvePathFeasibility(code, graph);

    const auditors = AuditorRegistry.getAuditors();
    const scanContext = new ScanContext(code, filename);
    scanContext.metadata = { 
      ast, 
      ir,
      semanticEnrichment,
      fullFlow,
      graph, 
      interproceduralMetrics, 
      unreachablePaths, 
      ...context 
    };

    const results = await Promise.all(
      auditors.map(auditor => auditor.audit(code, scanContext))
    );

    const flatResults = results.flat();
    
    // Enrich with file info
    flatResults.forEach(f => {
      f.file = filename;
    });

    parentPort?.postMessage({ status: "success", findings: flatResults });
  } catch (error: any) {
    parentPort?.postMessage({ status: "error", error: error.message });
  }
}

runAudit();
