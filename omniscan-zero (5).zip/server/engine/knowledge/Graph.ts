
import { IntelligenceKnowledgeBase } from "./KnowledgeBase";

export interface KnowledgeNode {
  id: string;
  type: "CVE" | "Vulnerability" | "Primitive" | "Framework";
  label: string;
  metadata: any;
}

export interface KnowledgeEdge {
  from: string;
  to: string;
  relationship: "RelatesTo" | "Implements" | "VulnerableTo" | "ChainStep";
}

export class SecurityKnowledgeGraph {
  private nodes: KnowledgeNode[] = [];
  private edges: KnowledgeEdge[] = [];
  private kb = new IntelligenceKnowledgeBase();

  constructor() {
    this.buildGraph();
  }

  private buildGraph() {
    // Transform KB into a graph structure
    // Example: CVE-2021-22965 -> relates to -> Prototype Pollution
    this.nodes.push({ id: "PP", type: "Vulnerability", label: "Prototype Pollution", metadata: {} });
    this.nodes.push({ id: "CVE-2021-22965", type: "CVE", label: "qs Prototype Pollution", metadata: {} });
    this.edges.push({ from: "CVE-2021-22965", to: "PP", relationship: "RelatesTo" });

    this.nodes.push({ id: "EVM", type: "Framework", label: "Ethereum Virtual Machine", metadata: {} });
    this.nodes.push({ id: "Reentrancy", type: "Vulnerability", label: "Reentrancy", metadata: {} });
    this.edges.push({ from: "EVM", to: "Reentrancy", relationship: "VulnerableTo" });
  }

  getRelatedContext(vulnName: string): KnowledgeNode[] {
    const relatedIds = this.edges
      .filter(e => e.from === vulnName || e.to === vulnName)
      .map(e => e.from === vulnName ? e.to : e.from);
    
    return this.nodes.filter(n => relatedIds.includes(n.id));
  }
}
