
export interface CVEInfo {
  id: string;
  title: string;
  description: string;
  affectedVersions: string[];
  patterns: string[]; // Regex or structural patterns matching the bug
  severity: "Critical" | "High" | "Medium" | "Low";
  cwe: string;
}

export interface ExploitPrimitive {
  id: string;
  name: string;
  description: string;
  sinkPattern: string;
  sourcePattern: string;
}

export interface FrameworkFingerprint {
  name: string;
  indicators: string[]; // Files or code patterns
  commonSinks: string[];
}

export interface ExploitChainPattern {
  name: string;
  sequence: string[]; // List of vulnerability categories or primitives
  impact: string;
}
