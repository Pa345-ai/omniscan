
import { CVEInfo, ExploitPrimitive, FrameworkFingerprint, ExploitChainPattern } from "./Types";

export class IntelligenceKnowledgeBase {
  private cves: CVEInfo[] = [
    {
      id: "CVE-2021-22965",
      title: "Prototype Pollution in qs",
      description: "Insecure parsing of nested objects allows prototype pollution.",
      affectedVersions: ["<6.10.3"],
      patterns: ["qs.parse", "__proto__"],
      severity: "High",
      cwe: "CWE-1321"
    },
    {
      id: "CVE-2023-40015",
      title: "Vyper Decimal Overflow",
      description: "Incorrect handling of decimals in certain versions of Vyper compiler.",
      affectedVersions: ["0.3.7"],
      patterns: ["decimal", "balance"],
      severity: "Critical",
      cwe: "CWE-190"
    }
  ];

  private primitives: ExploitPrimitive[] = [
    {
      id: "P-001",
      name: "Unchecked External Call",
      description: "Using .call() without checking the return value.",
      sinkPattern: "\\.call\\{",
      sourcePattern: "msg.sender"
    },
    {
      id: "P-002",
      name: "Tainted SQL Sink",
      description: "Direct user input into a SQL query string.",
      sinkPattern: "SELECT .* FROM .* WHERE .*=.*",
      sourcePattern: "req\\.query"
    }
  ];

  private fingerprints: FrameworkFingerprint[] = [
    {
      name: "Express.js",
      indicators: ["express()", "app.use", "req.params"],
      commonSinks: ["res.send", "res.render", "res.redirect"]
    },
    {
      name: "Hardhat",
      indicators: ["hardhat", "ethers", "deployProxy"],
      commonSinks: ["delegatecall"]
    }
  ];

  private chains: ExploitChainPattern[] = [
    {
      name: "Flashloan Governance Attack",
      sequence: ["Flashloan", "Governance Voting", "State Update", "Withdrawal"],
      impact: "Total Funds Drained"
    }
  ];

  private ontology: Map<string, string[]> = new Map([
    ["Reentrancy", ["State Machine Flaw", "External Call", "Atomic Violation"]],
    ["Oracle Manip", ["Market Flaw", "Price Drift", "NAV Desync"]],
    ["Auth Bypass", ["Role Escalation", "Trust Boundary Breach"]]
  ]);

  getMatchingCVEs(code: string): CVEInfo[] {
    return this.cves.filter(cve => 
      cve.patterns.some(p => new RegExp(p, "i").test(code))
    );
  }

  getMatchingPrimitives(code: string): ExploitPrimitive[] {
    return this.primitives.filter(p => 
      new RegExp(p.sinkPattern, "i").test(code) && new RegExp(p.sourcePattern, "i").test(code)
    );
  }

  detectFrameworks(code: string): FrameworkFingerprint[] {
    return this.fingerprints.filter(f => 
      f.indicators.some(i => code.includes(i))
    );
  }

  getExploitChains(): ExploitChainPattern[] {
    return this.chains;
  }
}
