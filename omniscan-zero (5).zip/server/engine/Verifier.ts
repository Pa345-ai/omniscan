import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { BugReport } from "./Auditor";

export class Verifier {
  constructor(private ai: GoogleGenAI) {}

  async verify(code: string, findings: BugReport[]): Promise<BugReport[]> {
    if (findings.length === 0) return [];

    console.log(`[Verifier] Scrutinizing ${findings.length} findings for false positives...`);

    const response = await this.ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: [
        {
          role: "user",
          parts: [{
            text: `You are a World-Class Security Researcher. Your goal is ZERO FALSE POSITIVES.
            
            Analyze the following findings found in a code audit. 
            For each finding, you must decide if it is a GENUINE bug or a FALSE POSITIVE.
            
            A finding is a FALSE POSITIVE if:
            1. It is technically impossible in the given context.
            2. It is a stylistic preference rather than a bug.
            3. It is based on a misunderstanding of the code's logic.
            
            CODE:
            ---
            ${code}
            ---
            
            CANDIDATE FINDINGS:
            ${JSON.stringify(findings, null, 2)}
            
            Return ONLY the verified genuine findings as a JSON array. 
            If a finding is questionable, DISCARD IT. We only want the high-confidence truth.`
          }]
        }
      ],
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              severity: { type: Type.STRING },
              category: { type: Type.STRING },
              reasoning: { type: Type.STRING },
              solution: { type: Type.STRING },
              confidence: { type: Type.NUMBER }
            },
            required: ["title", "severity", "category", "reasoning", "solution"]
          }
        }
      }
    });

    try {
      const verified = JSON.parse(response.text || "[]");
      return verified.filter((f: any) => f.confidence > 0.85); // Extreme filter for zero false positives
    } catch (e) {
      console.error("[Verifier] Failed to parse verification response", e);
      return [];
    }
  }
}
