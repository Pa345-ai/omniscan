
import { IRInstruction, BasicBlock } from "../ir/IRTypes";

export enum FlowNodeType {
  ENTRY = "ENTRY",
  EXIT = "EXIT",
  BASIC_BLOCK = "BASIC_BLOCK",
  BRANCH = "BRANCH",
  LOOP_HEADER = "LOOP_HEADER",
  EXCEPTION_HANDLER = "EXCEPTION_HANDLER"
}

export interface CFGNode {
  id: string;
  type: FlowNodeType;
  block?: BasicBlock;
  successors: string[];
  predecessors: string[];
  dominators: Set<string>;
  postDominators: Set<string>;
  immediateDominator?: string;
}

export interface ControlFlowGraph {
  nodes: Map<string, CFGNode>;
  entryNode: string;
  exitNode: string;
}

export interface DataFlowEdge {
  from: string; // Identifier or node ID
  to: string;
  type: "DEFINE" | "USE" | "MUTATE";
  instructionIndex: number;
  blockId: string;
}

export interface TaintState {
  tainted: boolean;
  source?: string;
  path: string[];
  sanitizers: string[];
}
