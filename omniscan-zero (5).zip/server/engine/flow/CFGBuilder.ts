
import { IRFunction, BasicBlock } from "../ir/IRTypes";
import { CFGNode, ControlFlowGraph, FlowNodeType } from "./FlowTypes";

export class CFGBuilder {
  build(func: IRFunction): ControlFlowGraph {
    const nodes = new Map<string, CFGNode>();
    
    // Create Entry and Exit nodes
    const entryId = "ENTRY_" + func.name;
    const exitId = "EXIT_" + func.name;

    nodes.set(entryId, {
      id: entryId,
      type: FlowNodeType.ENTRY,
      successors: [func.entryBlock],
      predecessors: [],
      dominators: new Set([entryId]),
      postDominators: new Set()
    });

    nodes.set(exitId, {
      id: exitId,
      type: FlowNodeType.EXIT,
      successors: [],
      predecessors: [],
      dominators: new Set(),
      postDominators: new Set([exitId])
    });

    // Map IR blocks to CFG nodes
    func.blocks.forEach((block, id) => {
      nodes.set(id, {
        id,
        type: this.inferNodeType(block),
        block,
        successors: block.successors.length > 0 ? block.successors : [exitId],
        predecessors: block.predecessors,
        dominators: new Set(),
        postDominators: new Set()
      });
    });

    // Link predecessors
    nodes.forEach(node => {
      node.successors.forEach(succId => {
        const succ = nodes.get(succId);
        if (succ && !succ.predecessors.includes(node.id)) {
          succ.predecessors.push(node.id);
        }
      });
    });

    this.calculateDominance(nodes, entryId);
    this.calculatePostDominance(nodes, exitId);

    return {
      nodes,
      entryNode: entryId,
      exitNode: exitId
    };
  }

  private calculatePostDominance(nodes: Map<string, CFGNode>, exitId: string) {
    const allIds = Array.from(nodes.keys());
    
    // Initialize
    nodes.forEach(node => {
      if (node.id === exitId) {
        node.postDominators = new Set([exitId]);
      } else {
        node.postDominators = new Set(allIds);
      }
    });

    // Iterative Fixed-Point
    let changed = true;
    while (changed) {
      changed = false;
      nodes.forEach(node => {
        if (node.id === exitId) return;

        const newPostDoms = new Set([node.id]);
        if (node.successors.length > 0) {
          let first = true;
          node.successors.forEach(succId => {
            const succ = nodes.get(succId);
            if (succ) {
              if (first) {
                succ.postDominators.forEach(d => newPostDoms.add(d));
                first = false;
              } else {
                // Intersection
                newPostDoms.forEach(d => {
                  if (!succ.postDominators.has(d) && d !== node.id) {
                    newPostDoms.delete(d);
                  }
                });
              }
            }
          });
        }

        if (newPostDoms.size !== node.postDominators.size) {
          node.postDominators = newPostDoms;
          changed = true;
        }
      });
    }
  }

  private inferNodeType(block: BasicBlock): FlowNodeType {
    const last = block.instructions[block.instructions.length - 1];
    if (last?.opcode === "JUMPI") return FlowNodeType.BRANCH;
    // Simple heuristic for loops - if it jumps back
    if (block.successors.some(s => parseInt(s.split('_')[1]) <= parseInt(block.id.split('_')[1]))) {
        return FlowNodeType.LOOP_HEADER;
    }
    return FlowNodeType.BASIC_BLOCK;
  }

  private calculateDominance(nodes: Map<string, CFGNode>, entryId: string) {
    const allIds = Array.from(nodes.keys());
    
    // Initialize
    nodes.forEach(node => {
      if (node.id === entryId) {
        node.dominators = new Set([entryId]);
      } else {
        node.dominators = new Set(allIds);
      }
    });

    // Iterative Fixed-Point
    let changed = true;
    while (changed) {
      changed = false;
      nodes.forEach(node => {
        if (node.id === entryId) return;

        const newDoms = new Set([node.id]);
        if (node.predecessors.length > 0) {
          let first = true;
          node.predecessors.forEach(predId => {
            const pred = nodes.get(predId);
            if (pred) {
              if (first) {
                pred.dominators.forEach(d => newDoms.add(d));
                first = false;
              } else {
                // Intersection
                newDoms.forEach(d => {
                  if (!pred.dominators.has(d) && d !== node.id) {
                    newDoms.delete(d);
                  }
                });
              }
            }
          });
        }

        if (newDoms.size !== node.dominators.size) {
          node.dominators = newDoms;
          changed = true;
        }
      });
    }
  }
}
