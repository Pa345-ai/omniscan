
import { UnifiedIR, IRFunction, IRInstruction, OpCode } from "../ir/IRTypes";
import { TaintSources, TaintSinks, Sanitizers } from "../TaintTracker";
import { TaintState } from "./FlowTypes";

export interface TaintVulnerability {
  source: string;
  sink: string;
  path: string[];
  sinkInstruction: IRInstruction;
  confidence: number;
}

export class TaintEngine {
  private visitedFunctions = new Set<string>();

  analyze(ir: UnifiedIR): TaintVulnerability[] {
    const vulnerabilities: TaintVulnerability[] = [];
    console.log("[TaintEngine] Starting interprocedural multi-stage taint analysis...");

    ir.functions.forEach((func, name) => {
      const results = this.analyzeFunction(func, ir, new Map());
      vulnerabilities.push(...results);
    });

    return vulnerabilities;
  }

  private analyzeFunction(func: IRFunction, ir: UnifiedIR, initialTaint: Map<string, TaintState>): TaintVulnerability[] {
    const findings: TaintVulnerability[] = [];
    const localTaint = new Map<string, TaintState>(initialTaint);
    
    // Mark parameters as tainted if they are coming from a tainted call site
    func.params.forEach(param => {
        if (!localTaint.has(param)) {
            // Assume framework injected params (like req, res, next) are sources
            if (TaintSources.some(s => param.includes(s) || param === 'req' || param === 'body')) {
                localTaint.set(param, { tainted: true, source: param, path: [func.name], sanitizers: [] });
            }
        }
    });

    func.blocks.forEach((block, blockId) => {
      block.instructions.forEach((inst, idx) => {
        // 1. Source Identification & Property Sensitivity
        this.identifySources(inst, localTaint, func.name);

        // 2. Taint Propagation (including field sensitivity: obj -> obj.prop)
        this.propagateTaint(inst, localTaint);

        // 3. Sanitizer Detection
        this.applySanitizers(inst, localTaint);

        // 4. Sink Detection
        const vuln = this.checkSinks(inst, localTaint);
        if (vuln) findings.push(vuln);

        // 5. Interprocedural & Async/Callback Analysis
        if (inst.opcode === OpCode.CALL) {
          const callee = inst.operands[0];
          
          // Case A: Standard Function Call
          const targetFunc = ir.functions.get(callee);
          if (targetFunc) {
            this.handleCall(targetFunc, inst, ir, localTaint, findings);
          }

          // Case B: Async Callback / Event Listener (e.g. app.get('/', (req, res) => ...))
          inst.operands.forEach(op => {
            if (typeof op === 'string') {
              const callback = ir.functions.get(op);
              if (callback && op !== callee) {
                // This is likely a callback argument
                console.log(`[TaintEngine] Tracing async callback: ${op}`);
                this.handleCall(callback, inst, ir, localTaint, findings);
              }
            }
          });
        }
      });
    });

    return findings;
  }

  private handleCall(targetFunc: IRFunction, inst: IRInstruction, ir: UnifiedIR, localTaint: Map<string, TaintState>, findings: TaintVulnerability[]) {
    if (this.visitedFunctions.has(targetFunc.name)) return;
    this.visitedFunctions.add(targetFunc.name);

    const callTaint = new Map<string, TaintState>();
    targetFunc.params.forEach((param, pIdx) => {
      const arg = inst.operands[pIdx + 1];
      if (localTaint.has(arg)) {
        callTaint.set(param, localTaint.get(arg)!);
      }
      // If we are calling a route handler, inject fresh taint for params
      if (param === 'req' || param === 'query' || param === 'body') {
         callTaint.set(param, { tainted: true, source: `API_${param}`, path: [targetFunc.name], sanitizers: [] });
      }
    });

    const subFindings = this.analyzeFunction(targetFunc, ir, callTaint);
    findings.push(...subFindings);
    this.visitedFunctions.delete(targetFunc.name); // Functional context cleanup
  }

  private identifySources(inst: IRInstruction, state: Map<string, TaintState>, funcName: string) {
    inst.operands.forEach(op => {
      if (typeof op === 'string') {
        // Source Identification: Check patterns and framework-specific fields
        if (TaintSources.some(s => op.includes(s)) || op.includes('req.') || op.includes('process.env')) {
            state.set(op, { tainted: true, source: op, path: [funcName], sanitizers: [] });
        }
      }
    });

    if (inst.opcode === OpCode.LOAD || inst.opcode === OpCode.UNTRUSTED) {
       const target = inst.operands[0];
       state.set(target, { tainted: true, source: target, path: [funcName], sanitizers: [] });
    }
  }

  private propagateTaint(inst: IRInstruction, state: Map<string, TaintState>) {
    if (inst.opcode === OpCode.STORE || inst.opcode === OpCode.CONCAT || inst.opcode === OpCode.MATH || inst.opcode === OpCode.MOVE) {
      const target = inst.operands[0];
      const sources = inst.operands.slice(1);
      
      const taintedSource = sources.find(s => {
          if (state.get(s)?.tainted) return true;
          // Check if parent object is tainted (Field Sensitivity)
          const base = s.split('.')[0];
          return state.get(base)?.tainted;
      });

      if (taintedSource) {
        const sourceState = state.get(taintedSource) || state.get(taintedSource.split('.')[0])!;
        state.set(target, { 
            ...sourceState, 
            path: [...sourceState.path, target] 
        });
      }
    }
  }

  private applySanitizers(inst: IRInstruction, state: Map<string, TaintState>) {
    if (inst.opcode === OpCode.CALL || inst.opcode === OpCode.CHECK) {
      const callee = inst.operands[0];
      if (Sanitizers.some(s => callee.includes(s.replace('(', '')))) {
        const target = inst.operands[1]; // Typically first arg is sanitized result
        if (state.has(target)) {
          state.get(target)!.sanitizers.push(callee);
          state.get(target)!.tainted = false; // Mark as clean (sanitized)
        }
      }
    }
  }

  private checkSinks(inst: IRInstruction, state: Map<string, TaintState>): TaintVulnerability | null {
    if (inst.opcode === OpCode.CALL) {
      const callee = inst.operands[0];
      if (TaintSinks.some(s => callee.includes(s.replace('(', '')))) {
        // Check if any argument is tainted and NOT sanitized
        const taintedArg = inst.operands.slice(1).find(arg => {
            const argState = state.get(arg);
            return argState?.tainted && argState.sanitizers.length === 0;
        });

        if (taintedArg) {
            const argState = state.get(taintedArg)!;
            return {
              source: argState.source || "unknown",
              sink: callee,
              path: argState.path,
              sinkInstruction: inst,
              confidence: 0.9
            };
        }
      }
    }
    return null;
  }
}
