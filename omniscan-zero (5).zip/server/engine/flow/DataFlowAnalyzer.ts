
import { UnifiedIR, IRFunction, OpCode } from "../ir/IRTypes";
import { DataFlowEdge } from "./FlowTypes";

export class DataFlowAnalyzer {
  analyze(func: IRFunction): DataFlowEdge[] {
    const edges: DataFlowEdge[] = [];
    const lastDef: Map<string, { blockId: string, instIndex: number }> = new Map();

    func.blocks.forEach((block, blockId) => {
      block.instructions.forEach((inst, instIndex) => {
        // Simple Use-Def tracking
        const operands = inst.operands || [];
        
        // Operands are 'uses'
        operands.forEach((op, i) => {
          if (typeof op === 'string' && op.match(/^[a-zA-Z_$][a-zA-Z0-9_$]*$/)) {
            const def = lastDef.get(op);
            if (def) {
              edges.push({
                from: `${def.blockId}_${def.instIndex}`,
                to: `${blockId}_${instIndex}`,
                type: "USE",
                instructionIndex: instIndex,
                blockId
              });
            }
          }
        });

        // Opcode might define or mutate
        if (inst.opcode === OpCode.STORE || inst.opcode === OpCode.LOAD) {
          const target = operands[0];
          const value = operands[1];
          
          if (typeof target === 'string') {
            // Field Sensitivity: obj.prop
            const fieldMatch = target.match(/^([^.]+)\.(.+)$/);
            if (fieldMatch) {
                const base = fieldMatch[1];
                const prop = fieldMatch[2];
                lastDef.set(target, { blockId, instIndex });
                edges.push({
                  from: base,
                  to: target,
                  type: "MUTATE",
                  instructionIndex: instIndex,
                  blockId
                });
            } else {
                lastDef.set(target, { blockId, instIndex });
                edges.push({
                  from: target,
                  to: `${blockId}_${instIndex}`,
                  type: "DEFINE",
                  instructionIndex: instIndex,
                  blockId
                });
            }
          }
        }
        
        if (inst.opcode === OpCode.CALL) {
           // Calls might mutate arguments (pointers/objects)
           operands.slice(1).forEach((op, i) => {
             if (typeof op === 'string') {
                edges.push({
                    from: `${blockId}_${instIndex}`,
                    to: op,
                    type: "MUTATE",
                    instructionIndex: instIndex,
                    blockId
                });
             }
           });
        }
      });
    });

    return edges;
  }
}
