import { BugReport } from "./Auditor";

export interface Symbol {
  name: string;
  type: string;
  kind: 'function' | 'variable' | 'class' | 'module' | 'interface' | 'macro' | 'decorator';
  scope: string;
  definitionPos: number;
  references: number[];
  inferredType?: string;
  isExported: boolean;
  metadata?: Record<string, any>;
}

export interface ASTNode {
  type: string;
  start: number;
  end: number;
  children: ASTNode[];
  raw?: string;
  metadata?: {
    symbolId?: string;
    typeInfo?: string;
    isMacroExpansion?: boolean;
    isCoroutine?: boolean;
    isAsync?: boolean;
    closureCaptures?: string[];
    exceptionEdges?: number[];
    [key: string]: any;
  };
}

export interface FlowEdge {
  from: number;
  to: number;
  type: 'control' | 'data';
  label?: string;
}

export interface TaintFlow {
  source: string;
  sink: string;
  path: number[]; // Array of line numbers or node IDs
  sanitizers: string[];
}

export interface SecurityGraph {
  nodes: Map<number, ASTNode>;
  edges: FlowEdge[];
  symbols: Symbol[];
}
