
type Task = () => Promise<any>;

export class ScanQueue {
  private static queues: Map<string, { tasks: Task[], running: boolean }> = new Map();

  static async enqueue(key: string, task: Task): Promise<any> {
    if (!this.queues.has(key)) {
      this.queues.set(key, { tasks: [], running: false });
    }

    const queue = this.queues.get(key)!;
    
    return new Promise((resolve, reject) => {
      const wrappedTask = async () => {
        try {
          const result = await task();
          resolve(result);
        } catch (err) {
          reject(err);
        }
      };

      queue.tasks.push(wrappedTask);
      this.processQueue(key);
    });
  }

  private static async processQueue(key: string) {
    const queue = this.queues.get(key);
    if (!queue || queue.running || queue.tasks.length === 0) return;

    queue.running = true;
    while (queue.tasks.length > 0) {
      const task = queue.tasks.shift();
      if (task) {
        await task();
      }
    }
    queue.running = false;
  }
}
