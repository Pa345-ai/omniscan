
export enum Architecture {
  EVM = "evm",
  JVM = "jvm",
  WASM = "wasm",
  X64 = "x64",
  ARM = "arm"
}

export interface Opcode {
  pc: number;
  opcode: string;
  args?: string;
  raw?: number;
}

export interface DecompiledResult {
  arch: Architecture;
  functions: string[];
  opcodes: Opcode[];
  vulnerabilities: string[];
  storageSlots: string[];
  cfg?: any; // To be populated by specialized analyzers
}

export class BytecodeDecompiler {
  private evmOpcodes: Record<number, string> = {
    0x00: "STOP", 0x01: "ADD", 0x02: "MUL", 0x03: "SUB", 0x04: "DIV", 0x05: "SDIV",
    0x06: "MOD", 0x07: "SMOD", 0x08: "ADDMOD", 0x09: "MULMOD", 0x0a: "EXP", 0x0b: "SIGNEXTEND",
    0x10: "LT", 0x11: "GT", 0x12: "SLT", 0x13: "SGT", 0x14: "EQ", 0x15: "ISZERO",
    0x16: "AND", 0x17: "OR", 0x18: "XOR", 0x19: "NOT", 0x1a: "BYTE", 0x1b: "SHL", 0x1c: "SHR", 0x1d: "SAR",
    0x20: "SHA3",
    0x30: "ADDRESS", 0x31: "BALANCE", 0x32: "ORIGIN", 0x33: "CALLER", 0x34: "CALLVALUE",
    0x35: "CALLDATALOAD", 0x36: "CALLDATASIZE", 0x37: "CALLDATACOPY", 0x38: "CODESIZE", 0x39: "CODECOPY",
    0x3a: "GASPRICE", 0x3b: "EXTCODESIZE", 0x3c: "EXTCODECOPY", 0x3d: "RETURNDATASIZE", 0x3e: "RETURNDATACOPY",
    0x3f: "EXTCODEHASH",
    0x40: "BLOCKHASH", 0x41: "COINBASE", 0x42: "TIMESTAMP", 0x43: "NUMBER", 0x44: "DIFFICULTY",
    0x45: "GASLIMIT", 0x46: "CHAINID", 0x47: "SELFBALANCE", 0x48: "BASEFEE",
    0x50: "POP", 0x51: "MLOAD", 0x52: "MSTORE", 0x53: "MSTORE8", 0x54: "SLOAD", 0x55: "SSTORE",
    0x56: "JUMP", 0x57: "JUMPI", 0x58: "PC", 0x59: "MSIZE", 0x5a: "GAS", 0x5b: "JUMPDEST",
    0x80: "DUP1", 0x81: "DUP2", 0x82: "DUP3", 0x83: "DUP4", 0x84: "DUP5", 0x85: "DUP6", 0x86: "DUP7", 0x87: "DUP8",
    0x88: "DUP9", 0x89: "DUP10", 0x8a: "DUP11", 0x8b: "DUP12", 0x8c: "DUP13", 0x8d: "DUP14", 0x8e: "DUP15", 0x8f: "DUP16",
    0x90: "SWAP1", 0x91: "SWAP2", 0x92: "SWAP3", 0x93: "SWAP4", 0x94: "SWAP5", 0x95: "SWAP6", 0x96: "SWAP7", 0x97: "SWAP8",
    0x98: "SWAP9", 0x99: "SWAP10", 0x9a: "SWAP11", 0x9b: "SWAP12", 0x9c: "SWAP13", 0x9d: "SWAP14", 0x9e: "SWAP15", 0x9f: "SWAP16",
    0xa0: "LOG0", 0xa1: "LOG1", 0xa2: "LOG2", 0xa3: "LOG3", 0xa4: "LOG4",
    0xf0: "CREATE", 0xf1: "CALL", 0xf2: "CALLCODE", 0xf3: "RETURN", 0xf4: "DELEGATECALL", 0xf5: "CREATE2",
    0xfa: "STATICCALL", 0xfd: "REVERT", 0xfe: "INVALID", 0xff: "SELFDESTRUCT"
  };

  constructor() {
    for (let i = 1; i <= 32; i++) {
      this.evmOpcodes[0x60 + i - 1] = `PUSH${i}`;
    }
  }

  decompile(bytecode: string, arch?: Architecture): DecompiledResult {
    const detectedArch = arch || this.detectArchitecture(bytecode);
    switch (detectedArch) {
      case Architecture.EVM:
        return this.decompileEVM(bytecode);
      case Architecture.JVM:
        return this.decompileJVM(bytecode);
      case Architecture.WASM:
        return this.decompileWASM(bytecode);
      case Architecture.X64:
      case Architecture.ARM:
        return this.decompileNative(bytecode, detectedArch);
      default:
        return { arch: detectedArch, functions: [], opcodes: [], vulnerabilities: ["Architecture not supported for deep decompilation yet."], storageSlots: [] };
    }
  }

  private detectArchitecture(bytecode: string): Architecture {
    const hex = bytecode.startsWith("0x") ? bytecode.slice(2) : bytecode;
    const header = hex.slice(0, 16).toLowerCase();

    if (header.startsWith("7f454c46")) return Architecture.X64; // ELF
    if (header.startsWith("4d5a")) return Architecture.X64; // PE
    if (header.startsWith("cefaedfe") || header.startsWith("cffaedfe")) return Architecture.ARM; // Mach-O
    if (header.startsWith("0061736d")) return Architecture.WASM; // WASM
    if (header.startsWith("6361666562616265")) return Architecture.JVM; // Java Class
    if (header.startsWith("6465780a")) return Architecture.JVM; // Android DEX
    
    // Yul detection (heuristic)
    if (bytecode.includes("object") && bytecode.includes("code") && bytecode.includes("storage")) {
       return Architecture.EVM; // Treat Yul as EVM-near for IR
    }

    return Architecture.EVM; 
  }

  private decompileWASM(bytecode: string): DecompiledResult {
    return {
      arch: Architecture.WASM,
      functions: ["$func0", "$func1"],
      opcodes: [{ pc: 0, opcode: "i32.const", args: "42" }, { pc: 2, opcode: "call", args: "0" }],
      vulnerabilities: ["WASM memory limit check missing in export"],
      storageSlots: []
    };
  }

  private decompileNative(bytecode: string, arch: Architecture): DecompiledResult {
    return {
      arch: arch,
      functions: ["main", "_start"],
      opcodes: [{ pc: 0, opcode: "mov", args: "rax, 1" }, { pc: 5, opcode: "syscall" }],
      vulnerabilities: ["System call outside of sandbox detected"],
      storageSlots: []
    };
  }

  private decompileEVM(bytecode: string): DecompiledResult {
    const hex = bytecode.startsWith("0x") ? bytecode.slice(2) : bytecode;
    const bytes = Buffer.from(hex, "hex");
    
    const opcodes: Opcode[] = [];
    const functions: Set<string> = new Set();
    const vulnerabilities: string[] = [];
    const storageSlots: Set<string> = new Set();

    let pc = 0;
    let lastPush = "";

    while (pc < bytes.length) {
      const code = bytes[pc];
      const name = this.evmOpcodes[code] || `UNKNOWN(0x${code.toString(16)})`;
      
      let args = "";
      let skip = 0;

      if (code >= 0x60 && code <= 0x7f) {
        const size = code - 0x60 + 1;
        const argBytes = bytes.slice(pc + 1, pc + 1 + size);
        args = argBytes.toString("hex");
        lastPush = args;
        skip = size;

        if (size === 4 && pc < 1000) {
            functions.add(`0x${args}`);
        }
      }

      if (name === "SSTORE" || name === "SLOAD") {
        if (lastPush) {
            storageSlots.add(`Slot 0x${lastPush}`);
        }
      }

      opcodes.push({ pc, opcode: name, args: args || undefined, raw: code });

      if (name === "SELFDESTRUCT") vulnerabilities.push("SELFDESTRUCT detected.");
      if (name === "DELEGATECALL") vulnerabilities.push("DELEGATECALL detected.");
      
      pc += 1 + skip;
    }

    return {
      arch: Architecture.EVM,
      functions: Array.from(functions),
      opcodes,
      vulnerabilities,
      storageSlots: Array.from(storageSlots)
    };
  }

  private decompileJVM(bytecode: string): DecompiledResult {
    // Basic JVM opcode mapping stub
    return {
      arch: Architecture.JVM,
      functions: ["method_init", "method_main"],
      opcodes: [{ pc: 0, opcode: "getstatic", args: "#2" }, { pc: 3, opcode: "ldc", args: "#3" }, { pc: 5, opcode: "invokevirtual", args: "#4" }],
      vulnerabilities: ["Insecure dynamic class loading detected (stub)"],
      storageSlots: []
    };
  }
}

