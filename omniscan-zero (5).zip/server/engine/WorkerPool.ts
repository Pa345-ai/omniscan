import { Worker } from "worker_threads";
import path from "path";
import os from "os";

export class WorkerPool {
  private workers: Worker[] = [];
  private poolSize: number;
  private queue: { task: any, resolve: Function, reject: Function }[] = [];
  private activeCount = 0;

  constructor(size?: number) {
    this.poolSize = size || Math.max(1, os.cpus().length - 1);
  }

  async run(workerScript: string, workerData: any): Promise<any> {
    return new Promise((resolve, reject) => {
      this.queue.push({ task: { workerScript, workerData }, resolve, reject });
      this.processQueue();
    });
  }

  private processQueue() {
    if (this.activeCount >= this.poolSize || this.queue.length === 0) {
      return;
    }

    const { task, resolve, reject } = this.queue.shift()!;
    this.activeCount++;

    const worker = new Worker(task.workerScript, {
      workerData: task.workerData,
      execArgv: task.workerScript.endsWith(".ts") ? ["--import", "tsx"] : []
    });

    worker.on("message", (msg) => {
      this.activeCount--;
      if (msg.status === "success") {
        resolve(msg.findings);
      } else {
        reject(new Error(msg.error));
      }
      this.processQueue();
      worker.terminate();
    });

    worker.on("error", (err) => {
      this.activeCount--;
      reject(err);
      this.processQueue();
      worker.terminate();
    });

    worker.on("exit", (code) => {
      if (code !== 0) {
        this.activeCount--;
        reject(new Error(`Worker stopped with exit code ${code}`));
        this.processQueue();
      }
    });
  }
}
