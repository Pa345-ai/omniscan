
import { BugReport } from "./Auditor";

export interface ComplianceStandard {
  id: string;
  name: string;
  description: string;
}

export interface ComplianceMapping {
  standard: string;
  controlId: string;
  requirement: string;
}

export class ComplianceService {
  public static STANDARDS: Record<string, ComplianceStandard> = {
    "SOC2": { id: "soc2", name: "SOC 2 Type II", description: "Security, Availability, Processing Integrity, Confidentiality, and Privacy." },
    "GDPR": { id: "gdpr", name: "GDPR", description: "General Data Protection Regulation for EU data privacy." },
    "PCI-DSS": { id: "pci", name: "PCI DSS v4.0", description: "Payment Card Industry Data Security Standard." },
    "OWASP": { id: "owasp", name: "OWASP Top 10", description: "Standard awareness document for developers and web application security." },
    "HIPAA": { id: "hipaa", name: "HIPAA", description: "Health Insurance Portability and Accountability Act." }
  };

  private static MAPPINGS: Record<string, ComplianceMapping[]> = {
    "XSS": [
      { standard: "OWASP", controlId: "A03:2021", requirement: "Injection" },
      { standard: "PCI-DSS", controlId: "6.5.7", requirement: "Cross-site scripting (XSS) flaws" },
      { standard: "SOC2", controlId: "CC7.1", requirement: "System monitoring and protection" }
    ],
    "SQLi": [
      { standard: "OWASP", controlId: "A03:2021", requirement: "Injection" },
      { standard: "PCI-DSS", controlId: "6.5.1", requirement: "Injection flaws" },
      { standard: "SOC2", controlId: "CC7.1", requirement: "Boundary protections" }
    ],
    "Auth": [
      { standard: "OWASP", controlId: "A07:2021", requirement: "Identification and Authentication Failures" },
      { standard: "GDPR", controlId: "Article 32", requirement: "Security of processing" },
      { standard: "HIPAA", controlId: "164.308(a)(4)", requirement: "Information Access Management" }
    ],
    "DataPrivacy": [
      { standard: "GDPR", controlId: "Article 25", requirement: "Data protection by design and by default" },
      { standard: "HIPAA", controlId: "164.306(a)", requirement: "Security Standards: General Rules" }
    ],
    "Secret": [
      { standard: "SOC2", controlId: "CC6.1", requirement: "Logical Access Controls" },
      { standard: "PCI-DSS", controlId: "3.5", requirement: "Protect stored cardholder data" }
    ],
    "AccessControl": [
      { standard: "OWASP", controlId: "A01:2021", requirement: "Broken Access Control" },
      { standard: "SOC2", controlId: "CC6.3", requirement: "Registration and Deregistration of Users" }
    ],
    "Smart Contract": [
      { standard: "SOC2", controlId: "CC7.1", requirement: "System monitoring and protection" },
      { standard: "OWASP", controlId: "A03:2021", requirement: "Injection (Broken Logic)" }
    ]
  };

  static getComplianceData(category: string): ComplianceMapping[] {
    // Basic fuzzy mapping
    for (const key of Object.keys(this.MAPPINGS)) {
      if (category.toLowerCase().includes(key.toLowerCase())) {
        return this.MAPPINGS[key];
      }
    }
    return [];
  }

  static generateReport(findings: BugReport[]) {
    const report: any = {
      summary: {
        totalFindings: findings.length,
        totalFiles: new Set(findings.map(f => f.file)).size,
        critical: findings.filter(f => f.severity === 'Critical').length,
        high: findings.filter(f => f.severity === 'High').length,
        mitigated: findings.filter(f => (f as any).mitigation_status === 'Mitigated').length
      },
      standards: this.STANDARDS,
      frameworks: {
        "SOC2": { passed: true, gaps: [] },
        "GDPR": { passed: true, gaps: [] },
        "PCI-DSS": { passed: true, gaps: [] },
        "OWASP": { passed: true, gaps: [] },
        "HIPAA": { passed: true, gaps: [] }
      },
      evidence: []
    };

    findings.forEach(finding => {
      const mapping = this.getComplianceData(finding.category || 'General');
      
      mapping.forEach(m => {
        if (report.frameworks[m.standard]) {
          report.frameworks[m.standard].passed = false;
          report.frameworks[m.standard].gaps.push({
            id: (finding as any).id,
            control: m.controlId,
            requirement: m.requirement,
            findingTitle: finding.title,
            severity: finding.severity,
            status: (finding as any).mitigation_status === 'Mitigated' ? "Mitigated" : "Open"
          });
        }
      });

      report.evidence.push({
        file: finding.file,
        finding: finding.title,
        reasoning: finding.reasoning,
        location: `Line ${finding.lineStart || 'unknown'}`
      });
    });

    return report;
  }
}
