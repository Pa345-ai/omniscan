import { BaseSecurityAgent } from "./BaseAgent";
import { AgentRole, ResearchTask } from "./Types";

export class HistoricalCVEAgent extends BaseSecurityAgent {
  constructor(ai: any) {
    super(ai, AgentRole.PENTESTER); // Reuse PENTESTER or add a new role
  }

  async execute(task: ResearchTask): Promise<any> {
    const { archMap, hypotheses } = task.context;
    
    console.log(`[Agent:CVESearcher] Comparing identified components against historical CVEs...`);

    const prompt = `
      You are an elite Security Threat Intelligence Agent. Review the architecture map and hypotheses.
      
      ARCH_MAP: ${JSON.stringify(archMap)}
      HYPOTHESES: ${JSON.stringify(hypotheses || [])}
      
      TASK:
      1. Analyze the components and tech stack identified.
      2. Compare them against historical CVE data, known architectural anti-patterns, and past exploit chains in similar systems.
      3. Point out if any of the hypotheses resemble legendary CVE responses (e.g., Log4Shell, Heartbleed, Reentrancy in TheDAO).
      
      Return JSON with keys: cveMatches (list of objects with cveId, description, similarityScore), historicalInsights (string).
    `;

    return await this.promptAI(prompt);
  }
}
