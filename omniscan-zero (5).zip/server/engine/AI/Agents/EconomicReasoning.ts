
import { BaseSecurityAgent } from "./BaseAgent";
import { AgentRole, ResearchTask } from "./Types";

export class EconomicReasoningAgent extends BaseSecurityAgent {
  constructor(ai: any) {
    super(ai, AgentRole.ECONOMIST);
  }

  async execute(task: ResearchTask): Promise<any> {
    const { code } = task.context;
    
    console.log(`[Agent:Economist] Analyzing economic incentives and business logic...`);

    const prompt = `
      You are a specialized Crypto-Economic Auditor. Analyze the business logic and economic incentives in this code.
      
      CODE: ${code}
      
      TASK:
      1. Identify potential "Economic Exploits" (Price manipulation, Flashloan attacks, MEV).
      2. Discover business logic flaws that lead to financial loss without technical crashes.
      3. Verify "Invariant Violations" (e.g. "total supply should never decrease accidentally").
      
      Return JSON with keys: hotspots (list), economicRisks (list), invariantViolations (list).
    `;

    return await this.promptAI(prompt);
  }
}
