
export enum AgentRole {
  ARCHITECT = "ARCHITECT",
  PENTESTER = "PENTESTER",
  EXPLOIT_DEV = "EXPLOIT_DEV",
  ECONOMIST = "ECONOMIST",
  COMPLIANCE = "COMPLIANCE"
}

export interface ResearchTask {
  id: string;
  role: AgentRole;
  objective: string;
  context: any;
  status: "PENDING" | "RUNNING" | "COMPLETED" | "FAILED";
  result?: any;
}

export interface ResearchHypothesis {
  title: string;
  description: string;
  confidence: number;
  attackVector: string;
  prerequisites: string[];
}

export interface ExploitChain {
  steps: {
    action: string;
    target: string;
    expectedState: string;
  }[];
  poc: string;
  impact: string;
}
