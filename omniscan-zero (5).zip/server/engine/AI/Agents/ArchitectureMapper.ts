
import { BaseSecurityAgent } from "./BaseAgent";
import { AgentRole, ResearchTask } from "./Types";

export class ArchitectureMapperAgent extends BaseSecurityAgent {
  constructor(ai: any) {
    super(ai, AgentRole.ARCHITECT);
  }

  async execute(task: ResearchTask): Promise<any> {
    const { codeFiles } = task.context;
    
    console.log(`[Agent:Architect] Mapping architecture for ${codeFiles.length} files...`);

    const prompt = `
      You are an Elite Security Architect. Analyze the following project structure and code snippets.
      
      CODE FILES:
      ${codeFiles.map((f: any) => `File: ${f.name}\n${f.content.slice(0, 1000)}...`).join('\n\n')}
      
      TASK:
      1. Map the system architecture.
      2. Identify the core components and their interactions.
      3. Discover hidden trust boundaries.
      4. Infer potential entry points (APIs, public methods, entry points).
      5. Identify critical state managers (Databases, Storage, Configs).
      
      Return JSON with keys: components (list), trustBoundaries (list), entryPoints (list), dataFlow (graph orientation).
    `;

    return await this.promptAI(prompt);
  }
}
