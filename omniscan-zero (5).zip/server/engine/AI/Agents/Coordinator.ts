
import { GoogleGenAI } from "@google/genai";
import { ArchitectureMapperAgent } from "./ArchitectureMapper";
import { AttackSurfaceAgent } from "./AttackSurface";
import { ExploitResearcherAgent } from "./ExploitResearcher";
import { EconomicReasoningAgent } from "./EconomicReasoning";
import { HistoricalCVEAgent } from "./HistoricalCVEAgent";
import { AgentRole, ResearchTask } from "./Types";

export class ResearchCoordinator {
  private architect: ArchitectureMapperAgent;
  private pentester: AttackSurfaceAgent;
  private exploitDev: ExploitResearcherAgent;
  private economist: EconomicReasoningAgent;
  private cveAgent: HistoricalCVEAgent;

  constructor(ai: GoogleGenAI) {
    this.architect = new ArchitectureMapperAgent(ai);
    this.pentester = new AttackSurfaceAgent(ai);
    this.exploitDev = new ExploitResearcherAgent(ai);
    this.economist = new EconomicReasoningAgent(ai);
    this.cveAgent = new HistoricalCVEAgent(ai);
  }

  async runResearchCycle(files: {name: string, content: string}[]): Promise<any> {
    console.log(`[ResearchCoordinator] Starting autonomous research cycle across ${files.length} files...`);
    
    // Step 1: Map Architecture
    const archMapTask: ResearchTask = {
      id: "1", role: AgentRole.ARCHITECT, objective: "Map project architecture", status: "PENDING",
      context: { codeFiles: files }
    };
    const archResult = await this.architect.execute(archMapTask);

    // Step 2: Economic/Business Logic Scan
    const economicTask: ResearchTask = {
      id: "2", role: AgentRole.ECONOMIST, objective: "Scan for economic flaws", status: "PENDING",
      context: { code: files.map(f => `File: ${f.name}\n${f.content}`).join('\n\n') }
    };
    const economicResult = await this.economist.execute(economicTask);

    // Step 3: Hypothesize Attack Surface
    const pentestTask: ResearchTask = {
      id: "3", role: AgentRole.PENTESTER, objective: "Hypothesize vectors", status: "PENDING",
      context: { archMap: archResult, artifacts: economicResult }
    };
    const hypotheses = await this.pentester.execute(pentestTask);

    // Step 3.5: Historical CVEs Comparison
    const cveTask: ResearchTask = {
      id: "3.5", role: AgentRole.PENTESTER, objective: "Historical CVE comparison", status: "PENDING",
      context: { archMap: archResult, hypotheses: hypotheses }
    };
    const cveResult = await this.cveAgent.execute(cveTask);

    // Step 4: Research Exploits for High-Confidence Hypotheses
    const finalFindings = [];
    for (const hypo of hypotheses.filter((h: any) => h.confidence > 0.7)) {
      const exploitTask: ResearchTask = {
        id: `exploit_${hypo.title}`, role: AgentRole.EXPLOIT_DEV, objective: "Build PoC", status: "PENDING",
        context: { 
          hypothesis: hypo, 
          codeContext: files.map(f => `File: ${f.name}\n${f.content}`).join('\n\n'),
          constraints: archResult.trustBoundaries?.map((tb: any) => tb.condition) || [], 
          semanticContext: { interactions: archResult.components }
        }
      };
      const exploitChain = await this.exploitDev.execute(exploitTask);
      finalFindings.push({ hypothesis: hypo, exploit: exploitChain, historicalContext: cveResult });
    }

    return {
      arch: archResult,
      economic: economicResult,
      cveMatches: cveResult,
      findings: finalFindings
    };
  }
}

