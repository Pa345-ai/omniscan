
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import { AgentRole, ResearchTask } from "./Types";

export abstract class BaseSecurityAgent {
  constructor(
    protected ai: GoogleGenAI,
    public role: AgentRole
  ) {}

  abstract execute(task: ResearchTask): Promise<any>;

  protected async promptAI(prompt: string, useThinking: boolean = true) {
    const response = await this.ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: [{
        role: "user",
        parts: [{ text: prompt }]
      }],
      config: {
        thinkingConfig: useThinking ? { thinkingLevel: ThinkingLevel.HIGH } : undefined,
        responseMimeType: "application/json"
      }
    });
    return JSON.parse(response.text || "{}");
  }
}
