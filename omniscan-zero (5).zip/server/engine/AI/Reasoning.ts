import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { BugReport } from "../Auditor";
import { SecurityGraph } from "../Types";
import { ResearchCoordinator } from "./Agents/Coordinator";
import { PatchValidationEngine, ValidationResult } from "../patch/ValidationEngine";
import { ExploitSynthesizer } from "../exploit/Synthesizer";

export class AIReasoningLayer {
  private coordinator: ResearchCoordinator;
  private validator = new PatchValidationEngine();
  private synthesizer: ExploitSynthesizer;

  constructor(private ai: GoogleGenAI) {
    this.coordinator = new ResearchCoordinator(this.ai);
    this.synthesizer = new ExploitSynthesizer(this.ai);
  }

  async runDeepResearch(files: {name: string, content: string}[]): Promise<any> {
    return await this.coordinator.runResearchCycle(files);
  }

  async verifyExploitability(code: string, finding: BugReport, context: any): Promise<{
    isExploitable: boolean;
    poc?: string;
    explanation: string;
    confidence: number;
    attackerPath?: string;
    synthesis?: any;
  }> {
    const { semanticEnrichment, symbolicFindings, pathConstraints } = context;

    // 1. Synthesize concrete exploit payload using symbolic solutions
    const synthesis = await this.synthesizer.synthesize(code, finding, context);

    const response = await this.ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: [{
        role: "user",
        parts: [{
          text: `You are an AI Security Verifier. Your task is to prove or disprove the exploitability of a technical finding using the provided static analysis signals and a synthesized exploit candidate.
          
          FINDING: ${finding.title}
          REASONING: ${finding.reasoning}

          SYNTHESIZED EXPLOIT STRATEGY:
          ${synthesis.strategy || "No strategy"}

          SYNTHESIZED PAYLOAD:
          ${synthesis.payload || "No payload"}
          
          SYMBOLIC PATH CONSTRAINTS:
          ${JSON.stringify(pathConstraints || [])}
          
          SEMANTIC ENRICHMENT (SSA & ALIASES):
          ${JSON.stringify(semanticEnrichment || {})}
          
          CODE CONTEXT:
          ${code}
          
          VERIFICATION PROTOCOL:
          1. Reachability Check: Does the synthesized payload satisfy the symbolic path constraints?
          2. SSA Flow Check: Does the tainted data from the payload reach the sink without sanitization?
          3. Logic Proof: Provide a logic proof of why this state is reachable or a counter-proof of why it isn't.
          
          Return JSON with keys: isExploitable (bool), poc (string), explanation (string), confidence (0.0-1.0), attackerPath (string).`
        }]
      }],
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text || "{}");
    return { ...result, synthesis };
  }

  async generateAutonomousPatch(code: string, finding: BugReport): Promise<{
    patch: string;
    validation: ValidationResult;
  }> {
    const response = await this.ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: [{
        role: "user",
        parts: [{
          text: `Generate a surgical, minimal, and performance-optimized patch for this vulnerability.
          
          VULNERABILITY: ${finding.title}
          PROBLEM: ${finding.reasoning}
          
          CODE:
          ${code}
          
          Return ONLY the corrected code block.`
        }]
      }]
    });
    
    const patch = response.text;
    const validation = await this.validator.validate(code, patch, finding);
    
    return { patch, validation };
  }
}
