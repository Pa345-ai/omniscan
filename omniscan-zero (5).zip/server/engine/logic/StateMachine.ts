
export interface StateTransition {
  from: string;
  to: string;
  trigger: string;
  guards: string[];
}

export class ProtocolStateMachine {
  private states = new Set<string>();
  private transitions: StateTransition[] = [];

  addTransition(t: StateTransition) {
    this.states.add(t.from);
    this.states.add(t.to);
    this.transitions.push(t);
  }

  detectSequencingFlaws(): string[] {
    const flaws: string[] = [];
    // Pattern: Critical state change without a preceding auth/lock state
    const criticalStates = ["WITHDRAWN", "ADMIN_UPDATED", "BRIDGE_EXECUTED"];
    
    criticalStates.forEach(cs => {
      const paths = this.transitions.filter(t => t.to === cs);
      paths.forEach(p => {
        if (!p.guards.some(g => g.includes("require") || g.includes("onlyOwner") || g.includes("_lock"))) {
          flaws.push(`Auth Sequencing Flaw: State '${cs}' can be reached via '${p.trigger}' without apparent access control guards.`);
        }
      });
    });

    return flaws;
  }
}
