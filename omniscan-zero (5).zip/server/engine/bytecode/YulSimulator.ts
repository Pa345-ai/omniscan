import { Opcode } from "../BytecodeDecompiler";

export interface SimulatorState {
  stack: bigint[];
  memory: Map<number, bigint>;
  storage: Map<bigint, bigint>;
  reentrancyGuard: boolean;
  pc: number;
}

export class YulSimulator {
  private state: SimulatorState;

  constructor() {
    this.state = {
      stack: [],
      memory: new Map(),
      storage: new Map(),
      reentrancyGuard: false,
      pc: 0
    };
  }

  simulate(opcodes: Opcode[]) {
    // Very simplified simulation for detecting state-machine bugs
    for (const op of opcodes) {
      this.execute(op);
    }
  }

  private execute(op: Opcode) {
    switch (op.opcode) {
      case "PUSH":
      case op.opcode.startsWith("PUSH") ? op.opcode : "":
        if (op.args) this.state.stack.push(BigInt("0x" + op.args));
        break;
      case "POP":
        this.state.stack.pop();
        break;
      case "SSTORE":
        const slot = this.state.stack.pop();
        const val = this.state.stack.pop();
        if (slot !== undefined && val !== undefined) {
          this.state.storage.set(slot, val);
        }
        break;
      case "CALL":
        // Mark that an external call occurred
        // If state is updated after this without a guard, it's reentrancy
        break;
      // ... more opcodes
    }
  }

  getState() { return this.state; }
}
