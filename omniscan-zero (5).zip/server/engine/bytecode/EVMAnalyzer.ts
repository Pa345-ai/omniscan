import { Opcode, DecompiledResult } from "../BytecodeDecompiler";

export interface CFGNode {
  id: number;
  opcodes: Opcode[];
  successors: number[];
}

export class EVMAnalyzer {
  analyze(decompiled: DecompiledResult): DecompiledResult {
    const cfg = this.buildCFG(decompiled.opcodes);
    const vulnerabilities = [...decompiled.vulnerabilities];
    
    if (this.detectReentrancy(cfg)) {
      vulnerabilities.push("Critical Reentrancy: State change detected after external call in the same execution path.");
    }

    if (this.detectDelegateCallRisk(decompiled.opcodes)) {
      vulnerabilities.push("High Risk DelegateCall: User-controlled address can be passed to DELEGATECALL.");
    }

    return {
      ...decompiled,
      vulnerabilities,
      cfg
    };
  }

  private buildCFG(opcodes: Opcode[]): CFGNode[] {
    const blocks: CFGNode[] = [];
    let currentBlock: Opcode[] = [];
    let blockId = 0;

    for (let i = 0; i < opcodes.length; i++) {
      const op = opcodes[i];
      currentBlock.push(op);

      if (["JUMP", "JUMPI", "STOP", "RETURN", "REVERT", "SELFDESTRUCT", "INVALID"].includes(op.opcode)) {
        blocks.push({
          id: blockId++,
          opcodes: currentBlock,
          successors: this.resolveSuccessors(op, opcodes, i)
        });
        currentBlock = [];
      } else if (i + 1 < opcodes.length && opcodes[i + 1].opcode === "JUMPDEST") {
          // New block starts at JUMPDEST
          blocks.push({
            id: blockId++,
            opcodes: currentBlock,
            successors: [opcodes[i+1].pc]
          });
          currentBlock = [];
      }
    }

    if (currentBlock.length > 0) {
      blocks.push({ id: blockId++, opcodes: currentBlock, successors: [] });
    }

    return blocks;
  }

  private resolveSuccessors(op: Opcode, allOpcodes: Opcode[], currentIndex: number): number[] {
    const succs: number[] = [];
    if (op.opcode === "JUMPI") {
      // Branch taken (if possible to determine staticly, else both)
      // Branch not taken (next PC)
      if (currentIndex + 1 < allOpcodes.length) {
        succs.push(allOpcodes[currentIndex + 1].pc);
      }
    } else if (op.opcode === "JUMP") {
      // Dynamic jump resolution would need symbolic execution
    } else if (!["STOP", "RETURN", "REVERT", "SELFDESTRUCT", "INVALID"].includes(op.opcode)) {
       if (currentIndex + 1 < allOpcodes.length) {
        succs.push(allOpcodes[currentIndex + 1].pc);
      }
    }
    return succs;
  }

  private detectReentrancy(cfg: CFGNode[]): boolean {
    // Traverse CFG to find CALL followed by SSTORE
    for (const node of cfg) {
      const hasCall = node.opcodes.some(o => o.opcode === "CALL");
      if (hasCall) {
        // Check if any reachable block perform SSTORE
        if (this.reachesSStore(node.id, cfg, new Set())) {
          return true;
        }
      }
    }
    return false;
  }

  private reachesSStore(startId: number, cfg: CFGNode[], visited: Set<number>): boolean {
    if (visited.has(startId)) return false;
    visited.add(startId);

    const node = cfg.find(n => n.id === startId);
    if (!node) return false;

    // Check current node (excluding instructions before the call if it was the same node)
    if (node.opcodes.some(o => o.opcode === "SSTORE")) return true;

    for (const succPc of node.successors) {
      const succBlock = cfg.find(n => n.opcodes[0].pc === succPc);
      if (succBlock && this.reachesSStore(succBlock.id, cfg, visited)) return true;
    }

    return false;
  }

  private detectDelegateCallRisk(opcodes: Opcode[]): boolean {
    // Pattern: CALLDATALOAD/CALLDATACOPY followed by DELEGATECALL
    let dataLoaded = false;
    for (const op of opcodes) {
      if (op.opcode.includes("CALLDATA")) dataLoaded = true;
      if (op.opcode === "DELEGATECALL" && dataLoaded) return true;
    }
    return false;
  }
}
