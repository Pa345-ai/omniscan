import { BytecodeDecompiler, Architecture, DecompiledResult } from "../BytecodeDecompiler";
import { EVMAnalyzer } from "./EVMAnalyzer";
import { BinaryFormatAnalyzer } from "./BinaryAnalyzer";

export class BytecodeCoordinator {
  private decompiler: BytecodeDecompiler;
  private evmAnalyzer: EVMAnalyzer;
  private binaryAnalyzer: BinaryFormatAnalyzer;

  constructor() {
    this.decompiler = new BytecodeDecompiler();
    this.evmAnalyzer = new EVMAnalyzer();
    this.binaryAnalyzer = new BinaryFormatAnalyzer();
  }

  async analyze(bytecode: string, arch?: Architecture): Promise<DecompiledResult> {
    const decompiled = this.decompiler.decompile(bytecode, arch);
    
    // For native formats, add more metadata
    if ([Architecture.X64, Architecture.ARM, Architecture.WASM].includes(decompiled.arch)) {
        const binInfo = this.binaryAnalyzer.analyze(bytecode);
        decompiled.vulnerabilities.push(...binInfo.vulnerabilities);
    }

    switch (decompiled.arch) {
      case Architecture.EVM:
        return this.evmAnalyzer.analyze(decompiled);
      case Architecture.JVM:
        return decompiled;
      default:
        return decompiled;
    }
  }
}
