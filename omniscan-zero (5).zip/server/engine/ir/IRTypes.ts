
export enum OpCode {
  LOAD = "LOAD",       // Load from memory/storage
  STORE = "STORE",     // Store to memory/storage
  CALL = "CALL",       // Function/Contract call
  JUMP = "JUMP",       // Unconditional jump
  JUMPI = "JUMPI",     // Conditional jump
  CONCAT = "CONCAT",   // String/Bytes concatenation
  MATH = "MATH",       // Arithmetic operations
  LOGIC = "LOGIC",     // Logical operations
  UNTRUSTED = "UNTRUSTED", // Explicitly mark untrusted input
  CHECK = "CHECK",     // Security check/validation
  RET = "RET",          // Return
  MOVE = "MOVE",
  DECLARE = "DECLARE",
  NEW_OBJECT = "NEW_OBJECT",
  PHINODE = "PHINODE"
}

export interface IRInstruction {
  opcode: OpCode;
  operands: any[];
  result?: string;
  metadata?: {
    line?: number;
    file?: string;
    column?: number;
    originalSource?: string;
  };
}

export interface BasicBlock {
  id: string;
  instructions: IRInstruction[];
  successors: string[]; // Block IDs
  predecessors: string[];
}

export interface IRFunction {
  name: string;
  params: string[];
  blocks: Map<string, BasicBlock>;
  entryBlock: string;
}

export interface UnifiedIR {
  functions: Map<string, IRFunction>;
  globals: Map<string, any>;
}
