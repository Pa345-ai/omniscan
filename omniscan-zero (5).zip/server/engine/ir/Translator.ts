
import { UnifiedIR, IRInstruction, OpCode, IRFunction, BasicBlock } from "./IRTypes";

export class IRTranslator {
  private blockCount = 0;
  private currentFunction?: IRFunction;
  private currentBlock?: BasicBlock;

  translate(ast: any, language: string = 'javascript'): UnifiedIR {
    const ir: UnifiedIR = {
      functions: new Map(),
      globals: new Map()
    };

    if (language === 'python') this.processPythonAst(ast, ir);
    else if (language === 'go') this.processGoAst(ast, ir);
    else if (language === 'rust') this.processRustAst(ast, ir);
    else if (language === 'java' || language === 'kotlin' || language === 'scala') this.processJVMAst(ast, ir);
    else if (language === 'solidity' || language === 'cairo') this.processWeb3Ast(ast, ir);
    else if (language === 'move') this.processMoveAst(ast, ir);
    else if (language === 'llvm' || language === 'cpp' || language === 'c') this.processLLVMAst(ast, ir);
    else if (language === 'dotnet' || language === 'csharp') this.processDotNetAst(ast, ir);
    else this.processTopLevel(ast, ir);
    
    return ir;
  }

  private processPythonAst(node: any, ir: UnifiedIR) {
      if (!ir.functions.has('main')) ir.functions.set('main', this.createEmptyFunction('main', []));
      const main = ir.functions.get('main')!;
      const entry = main.blocks.get(main.entryBlock)!;
      // Simulated translation for python
      if (node && node.type === 'DjangoRequest') {
          entry.instructions.push({ opcode: OpCode.UNTRUSTED, operands: ['expr_result', 'request.GET'] });
      }
      this.processTopLevel(node, ir);
  }

  private processGoAst(node: any, ir: UnifiedIR) {
      if (!ir.functions.has('main')) ir.functions.set('main', this.createEmptyFunction('main', []));
      // Simulated go translation mapping goroutines and channels to IR
      this.processTopLevel(node, ir);
  }

  private processRustAst(node: any, ir: UnifiedIR) {
      if (!ir.functions.has('main')) ir.functions.set('main', this.createEmptyFunction('main', []));
      // Simulated rust translation mapping pointers and lifetimes
      this.processTopLevel(node, ir);
  }

  private processJVMAst(node: any, ir: UnifiedIR) {
      if (!ir.functions.has('main')) ir.functions.set('main', this.createEmptyFunction('main', []));
      // JVM Specific: Reflection modeling and virtual dispatch
      this.processTopLevel(node, ir);
  }

  private processWeb3Ast(node: any, ir: UnifiedIR) {
      if (!ir.functions.has('fallback')) ir.functions.set('fallback', this.createEmptyFunction('fallback', []));
      // Web3 Specific: State transitions and reentrancy sites
      this.processTopLevel(node, ir);
  }

  private processLLVMAst(node: any, ir: UnifiedIR) {
      // LLVM/C/C++ Specific: Pointer arithmetic and manual memory management
      if (!ir.functions.has('_start')) ir.functions.set('_start', this.createEmptyFunction('_start', []));
      this.processTopLevel(node, ir);
  }

  private processDotNetAst(node: any, ir: UnifiedIR) {
      // .NET Specific: Metadata and IL mapping
      this.processTopLevel(node, ir);
  }

  private processMoveAst(node: any, ir: UnifiedIR) {
      // Move / Aptos / Sui translation 
      this.processTopLevel(node, ir);
  }

  private processTopLevel(node: any, ir: UnifiedIR) {
    if (!node) return;

    if (node.type === 'File' || node.type === 'Program') {
      const body = node.body || (node.program && node.program.body);
      if (body) {
        body.forEach((n: any) => this.processTopLevel(n, ir));
      }
    }

    if (node.type === 'FunctionDeclaration' || node.type === 'ArrowFunctionExpression' || node.type === 'FunctionExpression') {
      const funcName = node.id ? node.id.name : `anonymous_${this.blockCount++}`;
      const irFunc = this.translateFunction(node, funcName);
      ir.functions.set(funcName, irFunc);
    }
    
    // Handle top-level statements as a "main" function if needed
    if (node.type === 'ExpressionStatement' || node.type === 'VariableDeclaration') {
      if (!ir.functions.has('main')) {
          ir.functions.set('main', this.createEmptyFunction('main', []));
      }
      const main = ir.functions.get('main')!;
      const entry = main.blocks.get(main.entryBlock)!;
      const instrs = this.translateStatement(node, main);
      entry.instructions.push(...instrs);
    }
  }

  private createEmptyFunction(name: string, params: string[]): IRFunction {
    const entryId = `block_${this.blockCount++}`;
    const entryBlock: BasicBlock = {
      id: entryId,
      instructions: [],
      successors: [],
      predecessors: []
    };
    return {
      name,
      params,
      blocks: new Map([[entryId, entryBlock]]),
      entryBlock: entryId
    };
  }

  private translateFunction(node: any, name: string): IRFunction {
    const params = node.params ? node.params.map((p: any) => p.name || p.left?.name || 'param') : [];
    const irFunc = this.createEmptyFunction(name, params);
    
    this.currentFunction = irFunc;
    this.currentBlock = irFunc.blocks.get(irFunc.entryBlock);

    if (node.body) {
      if (node.body.type === 'BlockStatement') {
        node.body.body.forEach((stmt: any) => {
          this.processStatementFlow(stmt, irFunc);
        });
      } else {
        // Arrow function shorthand: (x) => x + 1
        const instrs = this.translateExpression(node.body);
        this.currentBlock?.instructions.push(...instrs);
        this.currentBlock?.instructions.push({ opcode: OpCode.RET, operands: ['expr_result'] });
      }
    }

    return irFunc;
  }

  private processStatementFlow(stmt: any, func: IRFunction) {
    if (!this.currentBlock) return;

    switch (stmt.type) {
      case 'IfStatement': {
        const condInstrs = this.translateExpression(stmt.test);
        this.currentBlock.instructions.push(...condInstrs);
        
        const thenBlock = this.createNewBlock(func);
        const elseBlock = stmt.alternate ? this.createNewBlock(func) : undefined;
        const mergeBlock = this.createNewBlock(func);

        this.currentBlock.instructions.push({
          opcode: OpCode.JUMPI,
          operands: ['expr_result', thenBlock.id]
        });
        this.currentBlock.successors.push(thenBlock.id);
        thenBlock.predecessors.push(this.currentBlock.id);

        if (elseBlock) {
          this.currentBlock.successors.push(elseBlock.id);
          elseBlock.predecessors.push(this.currentBlock.id);
          
          this.currentBlock = thenBlock;
          this.processStatementFlow(stmt.consequent, func);
          this.currentBlock.instructions.push({ opcode: OpCode.JUMP, operands: [mergeBlock.id] });
          this.currentBlock.successors.push(mergeBlock.id);
          mergeBlock.predecessors.push(this.currentBlock.id);

          this.currentBlock = elseBlock;
          this.processStatementFlow(stmt.alternate, func);
          this.currentBlock.instructions.push({ opcode: OpCode.JUMP, operands: [mergeBlock.id] });
          this.currentBlock.successors.push(mergeBlock.id);
          mergeBlock.predecessors.push(this.currentBlock.id);
        } else {
          this.currentBlock.successors.push(mergeBlock.id);
          mergeBlock.predecessors.push(this.currentBlock.id);

          this.currentBlock = thenBlock;
          this.processStatementFlow(stmt.consequent, func);
          this.currentBlock.instructions.push({ opcode: OpCode.JUMP, operands: [mergeBlock.id] });
          this.currentBlock.successors.push(mergeBlock.id);
          mergeBlock.predecessors.push(this.currentBlock.id);
        }

        this.currentBlock = mergeBlock;
        break;
      }

      case 'VariableDeclaration':
      case 'ExpressionStatement':
      case 'ReturnStatement': {
        const instrs = this.translateStatement(stmt, func);
        this.currentBlock.instructions.push(...instrs);
        break;
      }

      default:
        // Fallback for unhandled statements
        this.currentBlock.instructions.push({
            opcode: OpCode.LOGIC,
            operands: [stmt.type],
            metadata: { originalSource: 'unhandled_statement' }
        });
    }
  }

  private createNewBlock(func: IRFunction): BasicBlock {
    const id = `block_${this.blockCount++}`;
    const block: BasicBlock = {
      id,
      instructions: [],
      successors: [],
      predecessors: []
    };
    func.blocks.set(id, block);
    return block;
  }

  private translateStatement(stmt: any, func: IRFunction): IRInstruction[] {
    const instrs: IRInstruction[] = [];
    const meta = { line: stmt.loc?.start?.line, originalSource: stmt.type };

    switch (stmt.type) {
      case 'VariableDeclaration':
        stmt.declarations.forEach((decl: any) => {
          if (decl.init) {
            instrs.push(...this.translateExpression(decl.init));
            instrs.push({
              opcode: OpCode.STORE,
              operands: [decl.id.name, 'expr_result'],
              metadata: meta
            });
          } else {
            instrs.push({
              opcode: OpCode.DECLARE,
              operands: [decl.id.name],
              metadata: meta
            });
          }
        });
        break;

      case 'ExpressionStatement':
        instrs.push(...this.translateExpression(stmt.expression));
        break;

      case 'ReturnStatement':
        if (stmt.argument) {
          instrs.push(...this.translateExpression(stmt.argument));
          instrs.push({ opcode: OpCode.RET, operands: ['expr_result'], metadata: meta });
        } else {
          instrs.push({ opcode: OpCode.RET, operands: [], metadata: meta });
        }
        break;
    }

    return instrs;
  }

  private translateExpression(expr: any): IRInstruction[] {
    const instrs: IRInstruction[] = [];
    if (!expr) return instrs;

    switch (expr.type) {
      case 'NumericLiteral':
      case 'StringLiteral':
      case 'BooleanLiteral':
      case 'Literal':
        instrs.push({
          opcode: OpCode.LOAD,
          operands: ['expr_result', expr.value],
          metadata: { originalSource: JSON.stringify(expr.value) }
        });
        break;

      case 'Identifier':
        const op = this.isUntrustedSource(expr.name) ? OpCode.UNTRUSTED : OpCode.LOAD;
        instrs.push({
          opcode: op,
          operands: ['expr_result', expr.name],
          metadata: { originalSource: expr.name }
        });
        break;

      case 'MemberExpression':
        // Handle req.body, process.env etc.
        const sourceName = this.getMemberExpressionName(expr);
        const memberOp = this.isUntrustedSource(sourceName) ? OpCode.UNTRUSTED : OpCode.LOAD;
        instrs.push({
            opcode: memberOp,
            operands: ['expr_result', sourceName],
            metadata: { originalSource: sourceName }
        });
        break;

      case 'BinaryExpression':
        instrs.push(...this.translateExpression(expr.left));
        instrs.push({ opcode: OpCode.STORE, operands: ['temp_left', 'expr_result'] });
        instrs.push(...this.translateExpression(expr.right));
        instrs.push({ opcode: OpCode.STORE, operands: ['temp_right', 'expr_result'] });
        instrs.push({
          opcode: OpCode.MATH,
          operands: ['expr_result', expr.operator, 'temp_left', 'temp_right']
        });
        break;

      case 'CallExpression':
        const callee = expr.callee.name || expr.callee.property?.name || 'anonymous_call';
        const args: any[] = [];
        expr.arguments.forEach((arg: any, i: number) => {
           instrs.push(...this.translateExpression(arg));
           const argName = `arg_${i}`;
           instrs.push({ opcode: OpCode.STORE, operands: [argName, 'expr_result'] });
           args.push(argName);
        });

        // Security Normalization: Check for known sinks or auth checks
        const opcode = this.isAuthCheck(callee) ? OpCode.CHECK : OpCode.CALL;
        
        instrs.push({
          opcode,
          operands: [callee, ...args],
          metadata: { originalSource: callee }
        });
        break;
      
      case 'AssignmentExpression':
        instrs.push(...this.translateExpression(expr.right));
        const target = expr.left.name || expr.left.property?.name || 'unknown_target';
        instrs.push({
            opcode: OpCode.STORE,
            operands: [target, 'expr_result']
        });
        break;
    }

    return instrs;
  }

  private isAuthCheck(name: string): boolean {
    const checks = ['auth', 'isAdmin', 'checkPermission', 'validate', 'verify'];
    return checks.some(c => name.toLowerCase().includes(c.toLowerCase()));
  }

  private isUntrustedSource(name: string): boolean {
    const sources = ['req', 'body', 'query', 'params', 'env', 'user_input', 'payload'];
    return sources.some(s => name.toLowerCase().includes(s.toLowerCase()));
  }

  private getMemberExpressionName(expr: any): string {
    if (expr.type === 'Identifier') return expr.name;
    if (expr.type === 'MemberExpression') {
        const object = this.getMemberExpressionName(expr.object);
        const property = expr.property.name || expr.property.value;
        return `${object}.${property}`;
    }
    return 'unknown_member';
  }
}
