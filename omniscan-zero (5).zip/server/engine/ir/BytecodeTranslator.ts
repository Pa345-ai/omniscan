
import { Architecture, DecompiledResult } from "../BytecodeDecompiler";
import { UnifiedIR, IRFunction, BasicBlock, OpCode } from "./IRTypes";

export class BytecodeIRTranslator {
  translate(decompiled: DecompiledResult): UnifiedIR {
    const ir: UnifiedIR = {
      functions: new Map(),
      globals: new Map()
    };

    if (decompiled.arch === Architecture.EVM) {
      this.translateEVM(decompiled, ir);
    } else if (decompiled.arch === Architecture.WASM) {
      this.translateWASM(decompiled, ir);
    } else if (decompiled.arch === Architecture.JVM) {
      this.translateJVM(decompiled, ir);
    }
    // Add other archs as needed...

    return ir;
  }

  private translateWASM(decompiled: DecompiledResult, ir: UnifiedIR) {
    const wasmFunc: IRFunction = {
        name: "wasm_module",
        params: ["memory"],
        blocks: new Map(),
        entryBlock: "block_0"
    };

    const block: BasicBlock = { id: "block_0", instructions: [], successors: [], predecessors: [] };
    wasmFunc.blocks.set(block.id, block);

    decompiled.opcodes.forEach(op => {
        if (op.opcode.includes("call")) {
            block.instructions.push({ opcode: OpCode.CALL, operands: [op.args || "func"], metadata: { originalSource: "WASM_CALL" } });
        } else if (op.opcode.includes("store")) {
            block.instructions.push({ opcode: OpCode.STORE, operands: ["wasm_mem", op.args || "val"], metadata: { originalSource: "WASM_STORE" } });
        }
    });

    ir.functions.set(wasmFunc.name, wasmFunc);
  }

  private translateJVM(decompiled: DecompiledResult, ir: UnifiedIR) {
    const jvmFunc: IRFunction = {
        name: "jvm_runtime",
        params: ["stack"],
        blocks: new Map(),
        entryBlock: "block_0"
    };

    const block: BasicBlock = { id: "block_0", instructions: [], successors: [], predecessors: [] };
    jvmFunc.blocks.set(block.id, block);

    decompiled.opcodes.forEach(op => {
        if (op.opcode.startsWith("invoke")) {
            block.instructions.push({ opcode: OpCode.CALL, operands: [op.args || "method"], metadata: { originalSource: "JVM_INVOKE" } });
        } else if (op.opcode === "putstatic" || op.opcode === "putfield") {
            block.instructions.push({ opcode: OpCode.STORE, operands: [op.args || "field", "val"], metadata: { originalSource: "JVM_STORE" } });
        }
    });

    ir.functions.set(jvmFunc.name, jvmFunc);
  }

  private translateEVM(decompiled: DecompiledResult, ir: UnifiedIR) {
    const mainFunc: IRFunction = {
      name: "runtime_bytecode",
      params: ["calldata"],
      blocks: new Map(),
      entryBlock: "block_0"
    };

    const entryBlock: BasicBlock = {
      id: "block_0",
      instructions: [],
      successors: [],
      predecessors: []
    };
    mainFunc.blocks.set("block_0", entryBlock);

    let currentBlock = entryBlock;
    let blockCounter = 1;

    decompiled.opcodes.forEach(op => {
      // Create new block on JUMPDEST
      if (op.opcode === 'JUMPDEST') {
          const nextBlock: BasicBlock = {
              id: `block_${blockCounter++}`,
              instructions: [],
              successors: [],
              predecessors: [currentBlock.id]
          };
          currentBlock.successors.push(nextBlock.id);
          mainFunc.blocks.set(nextBlock.id, nextBlock);
          currentBlock = nextBlock;
      }

      // Very simplified mapping to security IR
      switch (op.opcode) {
        case 'SSTORE':
          currentBlock.instructions.push({
            opcode: OpCode.STORE,
            operands: [`storage[${op.args || 'top'}]`, 'stack_top'],
            metadata: { originalSource: 'SSTORE' }
          });
          break;
        case 'SLOAD':
          currentBlock.instructions.push({
            opcode: OpCode.LOAD,
            operands: ['stack_top', `storage[${op.args || 'top'}]`],
            metadata: { originalSource: 'SLOAD' }
          });
          break;
        case 'CALL':
        case 'DELEGATECALL':
        case 'STATICCALL':
          currentBlock.instructions.push({
            opcode: OpCode.CALL,
            operands: [op.opcode, op.args || 'unknown'],
            metadata: { originalSource: op.opcode }
          });
          break;
        case 'CALLER':
          currentBlock.instructions.push({
            opcode: OpCode.LOAD,
            operands: ['caller', 'msg.sender'],
            metadata: { originalSource: 'CALLER' }
          });
          break;
        case 'CALLVALUE':
          currentBlock.instructions.push({
            opcode: OpCode.UNTRUSTED,
            operands: ['value', 'msg.value'],
            metadata: { originalSource: 'CALLVALUE' }
          });
          break;
        // JUMP/JUMPI would logic would split blocks... for now simple linear approximation
      }
    });

    ir.functions.set(mainFunc.name, mainFunc);
  }
}
