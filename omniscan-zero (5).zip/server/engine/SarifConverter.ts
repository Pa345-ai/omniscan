export function convertToSarif(findings: any[]): any {
  const rules = new Map<string, any>();
  const results = [];

  const getSarifSeverity = (severity: string): "error" | "warning" | "note" => {
    if (severity === "High") return "error";
    if (severity === "Medium") return "warning";
    return "note";
  };

  for (const bug of findings) {
    const ruleId = bug.cwe || bug.category.replace(/\s+/g, '-').toUpperCase();
    
    if (!rules.has(ruleId)) {
      const cweNumber = bug.cwe && bug.cwe.startsWith('CWE-') ? bug.cwe.replace('CWE-', '') : undefined;
      rules.set(ruleId, {
        id: ruleId,
        shortDescription: { text: bug.title },
        fullDescription: { text: bug.reasoning },
        help: { text: bug.solution },
        helpUri: cweNumber ? `https://cwe.mitre.org/data/definitions/${cweNumber}.html` : undefined,
        properties: {
          category: bug.category,
          securitySeverity: bug.cvssScore ? bug.cvssScore.toString() : undefined
        }
      });
    }

    const result: any = {
      ruleId,
      level: getSarifSeverity(bug.severity),
      message: {
        text: bug.reasoning ? `${bug.title}\n\n${bug.reasoning}` : bug.title
      },
      locations: [
        {
          physicalLocation: {
            artifactLocation: {
              uri: bug.file || "unknown"
            },
            region: {
              startLine: bug.lineStart || 1
            }
          }
        }
      ]
    };

    results.push(result);
  }

  return {
    $schema: "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
    version: "2.1.0",
    runs: [
      {
        tool: {
          driver: {
            name: "OmniScan",
            informationUri: "https://omniscan.security",
            rules: Array.from(rules.values())
          }
        },
        results
      }
    ]
  };
}
