import { SecurityGraph, ASTNode } from "./Types";
import { init } from 'z3-solver';

export class PathAnalyzer {
  private z3InitPromise: Promise<any> | null = null;
  private Context: any = null;

  constructor() {
    this.z3InitPromise = init().then((z3: any) => {
      this.Context = z3.Context;
    }).catch((e: any) => {
      console.warn("Z3 solver failed to initialize", e);
    });
  }

  async resolvePathFeasibility(code: string, graph: SecurityGraph): Promise<number[]> {
    if (!this.Context && this.z3InitPromise) {
      await this.z3InitPromise;
    }

    const unreachableNodes: number[] = [];
    // nodeConstraints will store constraints for each node, not just an array.
    // wait, we can just do the bfs.

    // BFS to propagate constraints down the control flow
    const queue: { id: number; constraints: string[] }[] = [];
    const rootId = Array.from(graph.nodes.keys())[0];
    if (rootId !== undefined) {
      queue.push({ id: rootId, constraints: [] });
    }

    const visited = new Set<number>();

    while (queue.length > 0) {
      const { id, constraints } = queue.shift()!;
      if (visited.has(id)) continue;
      visited.add(id);

      const node = graph.nodes.get(id);
      if (!node) continue;

      // Ask Z3 if path is impossible
      let impossible = false;
      if (this.Context) {
        impossible = await this.isPathImpossibleZ3(constraints);
      } else {
        // Fallback to legacy
        impossible = this.isPathImpossible(constraints);
      }

      if (impossible) {
        unreachableNodes.push(id);
        // If impossible, don't propagate further?
        // Wait, previously we still queued children for node. If we continue, we skip queuing children!
        // The original code didn't use `continue`, so children got constraints. But dead code is dead. Let's just continue.
        // Wait, if we keep them in unreachable nodes but keep going, we might find more unreachable nodes. But everything
        // under a dead node is also dead. We should mark them unreachable.
      }

      // Propagate to children
      const childrenEdges = graph.edges.filter(e => e.from === id && e.type === 'control');
      for (const edge of childrenEdges) {
        let nextConstraints = [...constraints];
        
        // If current node is an IfStatement, add constraint to branches
        if (node.type === "IfStatement") {
          const condition = node.children.find(c => c.type.includes("Expression"))?.raw;
          if (condition) {
            // This is a simplification: assuming the first edge is 'true' branch
            // In a real CFG, edges would have labels
            if (edge.label === 'true') {
              nextConstraints.push(condition);
            } else if (edge.label === 'false') {
              nextConstraints.push(`!(${condition})`);
            }
          }
        }

        if (!impossible) {
          queue.push({ id: edge.to, constraints: nextConstraints });
        }
      }
    }

    return unreachableNodes;
  }

  private async isPathImpossibleZ3(constraints: string[]): Promise<boolean> {
    if (constraints.length < 2) return false;

    const ctx = new this.Context('main');
    const { Solver, Int, Bool, And, Or, Not } = ctx;
    const solver = new Solver();
    
    // We need a context to keep track of variables
    const vars: Record<string, any> = {};

    const getVar = (name: string, type: 'Int' | 'Bool') => {
      if (!vars[name]) {
        vars[name] = type === 'Int' ? Int.const(name) : Bool.const(name);
      }
      return vars[name];
    };

    const parseConstraint = (expr: string): any => {
      expr = expr.trim();
      
      // Basic unwrapping
      if (expr.startsWith('(') && expr.endsWith(')')) {
        return parseConstraint(expr.slice(1, -1));
      }
      if (expr.startsWith('!(') && expr.endsWith(')')) {
        return Not(parseConstraint(expr.slice(2, -1)));
      }
      if (expr.startsWith('!')) {
        const inner = expr.slice(1).trim();
        return Not(parseConstraint(inner));
      }
       
      // Handle logical operators
      if (expr.includes('&&')) {
        const parts = expr.split('&&').map(p => parseConstraint(p.trim()));
        return And(...parts);
      }
      if (expr.includes('||')) {
        const parts = expr.split('||').map(p => parseConstraint(p.trim()));
        return Or(...parts);
      }

      // Comparisons
      let m = expr.match(/^([a-zA-Z0-9_]+)\s*(>|<|>=|<=|===|!==|==|!=)\s*([0-9]+)$/);
      if (m) {
        const left = getVar(m[1], 'Int');
        const right = parseInt(m[3], 10);
        switch (m[2]) {
          case '>': return left.gt(right);
          case '<': return left.lt(right);
          case '>=': return left.ge(right);
          case '<=': return left.le(right);
          case '===':
          case '==': return left.eq(right);
          case '!==':
          case '!=': return left.neq(right);
        }
      }

      m = expr.match(/^([a-zA-Z0-9_]+)\s*(===|!==|==|!=)\s*(true|false)$/);
      if (m) {
        const left = getVar(m[1], 'Bool');
        const right = m[3] === 'true' ? Bool.val(true) : Bool.val(false);
        switch(m[2]) {
          case '===':
          case '==': return left.eq(right);
          case '!==':
          case '!=': return left.neq(right);
        }
      }

      m = expr.match(/^typeof\s+([a-zA-Z0-9_]+)\s*(===|==|!==|!=)\s*['"]([a-z]+)['"]$/);
      if (m) {
        // Represent type as an integer (string=1, number=2, boolean=3, object=4, etc)
        const left = getVar(`typeof_${m[1]}`, 'Int');
        let typeVal = 0;
        if (m[3] === 'string') typeVal = 1;
        else if (m[3] === 'number') typeVal = 2;
        else if (m[3] === 'boolean') typeVal = 3;
        else typeVal = 4;

        if (m[2].includes('!')) {
          return left.neq(typeVal);
        } else {
          return left.eq(typeVal);
        }
      }

      // Identifier matching for unary booleans
      if (/^[a-zA-Z0-9_]+$/.test(expr)) {
        // Can be null checks or unhandled. Just register as Bool to catch direct contradictions
        return getVar(expr, 'Bool');
      }

      // fallback
      return Bool.val(true);
    };

    for (const c of constraints) {
      solver.add(parseConstraint(c));
    }

    const result = await solver.check();
    return result === 'unsat';
  }

  private isPathImpossible(constraints: string[]): boolean {
    if (constraints.length < 2) return false;

    // Check all pairs for direct contradictions
    for (let i = 0; i < constraints.length; i++) {
      for (let j = i + 1; j < constraints.length; j++) {
        if (this.areContradictory(constraints[i], constraints[j])) {
          return true;
        }
      }
    }
    return false;
  }

  private areContradictory(c1: string, c2: string): boolean {
    const clean = (s: string) => s.replace(/\s+/g, '').replace(/[()]/g, '');
    const s1 = clean(c1);
    const s2 = clean(c2);

    // Direct negation: !A and A
    if (s1 === `!${s2}` || s2 === `!${s1}`) return true;

    // Split compound conditions
    const parts1 = s1.split('&&');
    const parts2 = s2.split('&&');

    for (const p1 of parts1) {
      for (const p2 of parts2) {
        if (p1 === `!${p2}` || p2 === `!${p1}`) return true;
      }
    }

    // Type contradictions
    if (s1.includes('typeof') && s2.includes('typeof')) {
      const match1 = s1.match(/typeof([a-zA-Z0-9]+)===['"]([a-z]+)['"]/);
      const match2 = s2.match(/typeof([a-zA-Z0-9]+)===['"]([a-z]+)['"]/);
      if (match1 && match2 && match1[1] === match2[1] && match1[2] !== match2[2]) {
        return true;
      }
    }

    return false;
  }

  private isContradictory(condition: string): boolean {
    // Legacy single-line check
    const patterns = [
      /([a-zA-Z0-9]+)\s*&&\s*!\1/,
      /!([a-zA-Z0-9]+)\s*&&\s*\1/,
      /([a-zA-Z0-9]+)\s*===\s*null\s*&&\s*\1/,
      /typeof\s+([a-zA-Z0-9]+)\s*===\s*['"]string['"]\s*&&\s*typeof\s+\1\s*===\s*['"]number['"]/
    ];
    return patterns.some(p => p.test(condition));
  }
}
