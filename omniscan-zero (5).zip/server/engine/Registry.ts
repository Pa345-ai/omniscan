import { BaseAuditor } from "./Auditor";
import { InjectionAuditor } from "./auditors/InjectionAuditor";
import { AuthAuditor } from "./auditors/AuthAuditor";
import { JWTOAuthAuditor } from "./auditors/JWTOAuthAuditor";
import { BytecodeAuditor } from "./auditors/BytecodeAuditor";
import { CryptoAuditor } from "./auditors/CryptoAuditor";
import { LogicAuditor } from "./auditors/LogicAuditor";
import { SecretAuditor } from "./auditors/SecretAuditor";
import { PerformanceAuditor } from "./auditors/PerformanceAuditor";
import { DependencyAuditor } from "./auditors/DependencyAuditor";
import { ConcurrencyAuditor } from "./auditors/ConcurrencyAuditor";
import { ResourceLeakAuditor } from "./auditors/ResourceLeakAuditor";
import { ErrorHandlingAuditor } from "./auditors/ErrorHandlingAuditor";
import { AccessControlAuditor } from "./auditors/AccessControlAuditor";
import { DataPrivacyAuditor } from "./auditors/DataPrivacyAuditor";
import { NetworkSecurityAuditor } from "./auditors/NetworkSecurityAuditor";
import { InfrastructureAuditor } from "./auditors/InfrastructureAuditor";
import { StorageAuditor } from "./auditors/StorageAuditor";
import { ArithmeticAuditor } from "./auditors/ArithmeticAuditor";
import { InputValidationAuditor } from "./auditors/InputValidationAuditor";
import { SessionManagementAuditor } from "./auditors/SessionManagementAuditor";
import { LoggingAuditor } from "./auditors/LoggingAuditor";
import { XSSAuditor } from "./auditors/XSSAuditor";
import { CSRFAuditor } from "./auditors/CSRFAuditor";
import { SQLIAuditor } from "./auditors/SQLIAuditor";
import { CommandInjectionAuditor } from "./auditors/CommandInjectionAuditor";
import { DeserializationAuditor } from "./auditors/DeserializationAuditor";
import { BusinessLogicAuditor } from "./auditors/BusinessLogicAuditor";
import { CVEIntegrityAuditor } from "./auditors/CVEAuditor";
import { SemanticVulnerabilityAuditor } from "./auditors/SemanticVulnerabilityAuditor";
import { SandboxAuditor } from "./auditors/SandboxAuditor";
import { ProtobufAuditor } from "./auditors/ProtobufAuditor";
import { GraphQLAuditor } from "./auditors/GraphQLAuditor";
import { ComplianceAuditor } from "./auditors/ComplianceAuditor";
import { SSRFAuditor } from "./auditors/SSRFAuditor";
import { PrototypePollutionAuditor } from "./auditors/PrototypePollutionAuditor";
import { IAMAuditor } from "./auditors/IAMAuditor";
import { SBOMAuditor } from "./auditors/SBOMAuditor";
import { SSTIAuditor } from "./auditors/SSTIAuditor";
import { TaintAuditor } from "./auditors/TaintAuditor";
import { TaintVulnerabilityAuditor } from "./auditors/TaintVulnerabilityAuditor";
import { Web3Analyzer } from "./auditors/Web3Analyzer";
import { ProjectReconstructor } from "./auditors/ProjectReconstructor";
import { AIAuditor } from "./auditors/AIAuditor";

import { PromptInjectionAuditor } from "./auditors/PromptInjectionAuditor";
import { CrossChainAuditor } from "./auditors/CrossChainAuditor";
import { ZKCircuitAuditor } from "./auditors/ZKCircuitAuditor";
import { CICDPipelineAuditor } from "./auditors/CICDPipelineAuditor";
import { DeFiInvariantAuditor } from "./auditors/DeFiInvariantAuditor";
import { EIP712Auditor } from "./auditors/EIP712Auditor";
import { AICodeDetectorAuditor } from "./auditors/AICodeDetectorAuditor";

export class AuditorRegistry {
  static getAuditors(): BaseAuditor[] {
    return [
      new InjectionAuditor(),
      new AuthAuditor(),
      new JWTOAuthAuditor(),
      new BytecodeAuditor(),
      new CryptoAuditor(),
      new LogicAuditor(),
      new SecretAuditor(),
      new PerformanceAuditor(),
      new DependencyAuditor(),
      new ConcurrencyAuditor(),
      new ResourceLeakAuditor(),
      new ErrorHandlingAuditor(),
      new AccessControlAuditor(),
      new DataPrivacyAuditor(),
      new NetworkSecurityAuditor(),
      new InfrastructureAuditor(),
      new StorageAuditor(),
      new ArithmeticAuditor(),
      new InputValidationAuditor(),
      new SessionManagementAuditor(),
      new LoggingAuditor(),
      new XSSAuditor(),
      new CSRFAuditor(),
      new SQLIAuditor(),
      new CommandInjectionAuditor(),
      new DeserializationAuditor(),
      new BusinessLogicAuditor(),
      new CVEIntegrityAuditor(),
      new SemanticVulnerabilityAuditor(),
      new SandboxAuditor(),
      new ProtobufAuditor(),
      new GraphQLAuditor(),
      new ComplianceAuditor(),
      new AIAuditor(),
      new SSRFAuditor(),
      new PrototypePollutionAuditor(),
      new IAMAuditor(),
      new SSTIAuditor(),
      new SBOMAuditor(),
      new TaintAuditor(),
      new TaintVulnerabilityAuditor(),
      new Web3Analyzer(),
      new ProjectReconstructor(),
      new PromptInjectionAuditor(),
      new CrossChainAuditor(),
      new ZKCircuitAuditor(),
      new CICDPipelineAuditor(),
      new DeFiInvariantAuditor(),
      new EIP712Auditor(),
      new AICodeDetectorAuditor()
    ];
  }
}
