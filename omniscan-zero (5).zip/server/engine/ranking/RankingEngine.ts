import { BugReport, BugReportScores } from "../Auditor";
import { SecurityGraph } from "../Types";

export class SemanticRankingEngine {
  rank(findings: BugReport[], code: string, graph: SecurityGraph): BugReport[] {
    const scoredFindings = findings.map(f => {
      const scores = this.calculateScores(f, code, graph, findings);
      return { ...f, scores };
    });

    // Sort by combinedRisk descending
    return scoredFindings.sort((a, b) => (b.scores?.combinedRisk || 0) - (a.scores?.combinedRisk || 0));
  }

  private calculateScores(finding: BugReport, code: string, graph: SecurityGraph, allFindings: BugReport[]): BugReportScores {
    const exploitability = this.calculateExploitability(finding, code, graph);
    const reachability = this.calculateReachability(finding, graph);
    const impact = this.calculateImpact(finding);
    const chainability = this.calculateChainability(finding, allFindings);
    const privilegeEscalation = this.calculatePrivilegeEscalation(finding, code);
    const internetExposure = this.calculateInternetExposure(finding, code);
    const attackSurface = this.calculateAttackSurface(finding, code, graph);

    // Formula: risk = exploitability × reachability × impact × chainability
    // Elite scoring uses exponential weights for critical components
    const riskProduct = (exploitability * 1.5) * (reachability * 1.2) * (impact * 2.0) * (chainability * 1.1);
    
    // Scale additives for environmental exposure
    const enviroBoost = (attackSurface * 0.8) + (internetExposure * 1.2) + (privilegeEscalation * 1.5);
    
    const combinedRisk = Math.min(100, Math.round((riskProduct * 5) + enviroBoost));

    return {
      exploitability,
      reachability,
      impact,
      chainability,
      privilegeEscalation,
      internetExposure,
      attackSurface,
      combinedRisk
    };
  }

  private calculateAttackSurface(finding: BugReport, code: string, graph: SecurityGraph): number {
    // Attack surface is physical entry point density
    let surface = 0.3;
    if (code.includes('process.env') || code.includes('req.body') || code.includes('req.query')) surface += 0.3;
    if (finding.file?.includes('controllers/') || finding.file?.includes('routes/')) surface += 0.2;
    if (graph.nodes.size > 100) surface += 0.1; // Complex graph = larger surface
    return Math.min(1, surface);
  }

  private calculateExploitability(finding: BugReport, code: string, graph: SecurityGraph): number {
    let score = finding.confidence;
    if (finding.cves && finding.cves.length > 0) score += 0.3;
    if (finding.exploitDB) score += 0.2;
    if (finding.poc) score += 0.4;
    return Math.min(1, score);
  }

  private calculateReachability(finding: BugReport, graph: SecurityGraph): number {
    if (!finding.title) return 0.5;
    const isPublic = finding.reasoning.toLowerCase().includes("public") || finding.reasoning.toLowerCase().includes("external");
    if (isPublic) return 0.95;
    
    if (graph.nodes.size > 0) {
        return Math.min(0.8, (graph.edges.length / graph.nodes.size) * 0.5);
    }
    return 0.4;
  }

  private calculateImpact(finding: BugReport): number {
    let impact = 0.5;
    switch (finding.severity) {
      case "Critical": impact = 1.0; break;
      case "High": impact = 0.8; break;
      case "Medium": impact = 0.5; break;
      case "Low": impact = 0.2; break;
    }
    if (finding.category.includes("Logic") || finding.category.includes("Economic")) impact = Math.min(1.0, impact * 1.2);
    return impact;
  }

  private calculateChainability(finding: BugReport, allFindings: BugReport[]): number {
    const moduleFindings = allFindings.filter(f => f.file === finding.file);
    if (moduleFindings.length > 5) return 0.95;
    if (moduleFindings.length > 2) return 0.8;
    return 0.6;
  }

  private calculatePrivilegeEscalation(finding: BugReport, code: string): number {
    if (finding.reasoning.toLowerCase().includes("privilege") || finding.reasoning.toLowerCase().includes("admin") || code.includes("grantRole")) {
      return 0.95;
    }
    return 0.1;
  }

  private calculateInternetExposure(finding: BugReport, code: string): number {
    const isPublic = code.includes("app.get") || code.includes("app.post") || code.includes("router.") || finding.file?.endsWith(".sol") || code.includes("public");
    return isPublic ? 0.95 : 0.3;
  }
}
