export class ScanContext {
  public startTime: number;
  public metadata: Record<string, any> = {};

  constructor(public code: string, public filename: string) {
    this.startTime = Date.now();
  }

  logAudit(auditor: string, message: string) {
    console.log(`[${auditor}] ${message}`);
  }
}
