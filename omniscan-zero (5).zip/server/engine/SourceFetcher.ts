import * as git from "isomorphic-git";
import http from "isomorphic-git/http/node";
import fs from "fs-extra";
import path from "path";
import axios from "axios";

export class SourceFetcher {
  private baseDir = "/tmp/omniscan_workspace";
  private MAX_REPO_SIZE_MB = 100;
  private CLONE_TIMEOUT_MS = 60000; // 1 minute

  constructor() {
    fs.ensureDirSync(this.baseDir);
  }

  /**
   * Validates if the provided URL is a safe and valid GitHub/GitLab URL.
   */
  public validateRepositoryURL(url: string): boolean {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:") return false;

      const allowedHosts = ["github.com", "gitlab.com"];
      const isAllowedHost = allowedHosts.some(host => parsed.hostname.endsWith(host));
      
      if (url.includes("..") || url.includes("\0")) return false;

      return isAllowedHost;
    } catch {
      return false;
    }
  }

  async cloneRepository(url: string, ref: string = "main"): Promise<string> {
    if (!this.validateRepositoryURL(url)) {
      throw new Error("Invalid or unsupported repository URL. Only HTTPS GitHub/GitLab links are permitted.");
    }

    const repoId = Math.random().toString(36).substring(7);
    const targetPath = path.join(this.baseDir, repoId);
    
    console.log(`[SourceFetcher] Secure Cloning ${url} (branch: ${ref}) to ${targetPath}`);
    
    const clonePromise = git.clone({
      fs,
      http,
      dir: targetPath,
      url,
      ref,
      singleBranch: true,
      depth: 1,
      noTags: true,
    });

    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error("Clone operation timed out")), this.CLONE_TIMEOUT_MS)
    );

    try {
      await Promise.race([clonePromise, timeoutPromise]);
      
      const size = await this.getDirectorySize(targetPath);
      if (size > this.MAX_REPO_SIZE_MB * 1024 * 1024) {
        await this.cleanup(targetPath);
        throw new Error(`Repository exceeds hardware safety limits (${this.MAX_REPO_SIZE_MB}MB)`);
      }

      return targetPath;
    } catch (error: any) {
      await this.cleanup(targetPath);
      throw new Error(`Cloning failure: ${error.message}`);
    }
  }

  private async getDirectorySize(dir: string): Promise<number> {
    let size = 0;
    const files = await fs.readdir(dir);
    for (const file of files) {
      const filePath = path.join(dir, file);
      const stats = await fs.stat(filePath);
      if (stats.isDirectory()) {
        size += await this.getDirectorySize(filePath);
      } else {
        size += stats.size;
      }
    }
    return size;
  }

  async fetchSmartContract(address: string, network: string = "eth"): Promise<{ files: { path: string, content: string }[], bytecode?: string }> {
    console.log(`[SourceFetcher] Fetching contract ${address} on ${network}`);
    
    // Attempt Sourcify first (high fidelity metadata)
    let bytecodeResult: string | undefined;
    try {
        bytecodeResult = await this.fetchBytecode(address, network);
    } catch (e) {
        console.warn("[SourceFetcher] Bytecode fetch failed", e);
    }

    try {
      const sourcifyResult = await this.fetchFromSourcify(address, network);
      if (sourcifyResult) return { ...sourcifyResult, bytecode: bytecodeResult };
    } catch (e) {
      console.warn("[SourceFetcher] Sourcify fetch failed, falling back to Etherscan", e);
    }

    // Etherscan API mapping
    const endpoints: Record<string, string> = {
      eth: "https://api.etherscan.io/api",
      base: "https://api.basescan.org/api",
      arbitrum: "https://api.arbiscan.io/api",
      polygon: "https://api.polygonscan.com/api"
    };

    const url = `${endpoints[network] || endpoints.eth}?module=contract&action=getsourcecode&address=${address}`;
    
    try {
      const response = await axios.get(url);
      const result = response.data.result[0];

      if (!result || result.SourceCode === "") {
        console.log(`[SourceFetcher] Source not verified for ${address}, attempting bytecode fetch...`);
        const bytecode = bytecodeResult || await this.fetchBytecode(address, network);
        return { files: [{ path: "bytecode.evm", content: bytecode }], bytecode };
      }

      // Handle both single file and multi-file (JSON) sources
      let files: { path: string; content: string }[] = [];
      
      if (result.SourceCode.startsWith("{{")) {
        // Multi-file JSON format
        const jsonStr = result.SourceCode.slice(1, -1);
        const sourceObj = JSON.parse(jsonStr);
        for (const [filePath, fileObj] of Object.entries(sourceObj.sources)) {
          files.push({ path: filePath, content: (fileObj as any).content });
        }
      } else if (result.SourceCode.startsWith("{")) {
        // Some APIs return raw JSON without double braces
        const sourceObj = JSON.parse(result.SourceCode);
        if (sourceObj.sources) {
           for (const [filePath, fileObj] of Object.entries(sourceObj.sources)) {
            files.push({ path: filePath, content: (fileObj as any).content });
          }
        }
      } else {
        files.push({ path: "contract.sol", content: result.SourceCode });
      }

      return { files, bytecode: bytecodeResult };
    } catch (error: any) {
       // Final fallback if everything failed but we might still get bytecode
       try {
          const bytecode = bytecodeResult || await this.fetchBytecode(address, network);
          return { files: [{ path: "bytecode.evm", content: bytecode }], bytecode };
       } catch (innerError) {
          throw new Error(`Failed to fetch smart contract: ${error.message}`);
       }
    }
  }

  async fetchBytecode(address: string, network: string = "eth"): Promise<string> {
    const endpoints: Record<string, string> = {
      eth: "https://api.etherscan.io/api",
      base: "https://api.basescan.org/api",
      arbitrum: "https://api.arbiscan.io/api",
      polygon: "https://api.polygonscan.com/api"
    };

    const url = `${endpoints[network] || endpoints.eth}?module=proxy&action=eth_getCode&address=${address}`;
    const response = await axios.get(url);
    if (response.data && response.data.result && response.data.result !== "0x") {
      return response.data.result;
    }
    throw new Error("Bytecode not found at address.");
  }

  private async fetchFromSourcify(address: string, network: string): Promise<{ files: { path: string, content: string }[] } | null> {
    const chainIds: Record<string, number> = { eth: 1, base: 8453, arbitrum: 42161, polygon: 137 };
    const chainId = chainIds[network] || 1;
    
    const url = `https://sourcify.dev/server/files/any/${chainId}/${address}`;
    try {
      const response = await axios.get(url);
      if (response.data && response.data.files) {
        const files = response.data.files
          .filter((f: any) => f.name.endsWith(".sol"))
          .map((f: any) => ({ path: f.name, content: f.content }));
        return files.length > 0 ? { files } : null;
      }
    } catch (e) {
      return null;
    }
    return null;
  }

  async cleanup(dirPath: string) {
    if (dirPath.startsWith(this.baseDir)) {
      await fs.remove(dirPath);
    }
  }
}
