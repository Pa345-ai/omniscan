import { SecurityGraph, ASTNode } from "./Types";
import { UnifiedIR, IRFunction, OpCode, IRInstruction } from "./ir/IRTypes";

export interface CallGraphNode {
  id: string;
  func: IRFunction;
  callsites: Map<string, string[]>; // instructionId -> potential callees
}

export interface AnalysisContext {
  callStack: string[];
  objectThis?: string;
}

export class InterproceduralAnalyzer {
  private globalCallGraph: Map<string, string[]> = new Map();
  private frameworkManifest: Set<string> = new Set();
  private inheritanceMap: Map<string, string[]> = new Map(); // parent -> children
  private classMetadata: Map<string, { methods: string[], parent?: string }> = new Map();
  private virtualTable: Map<string, string[]> = new Map(); // class:method -> implementations
  private contextCallGraph: Map<string, Set<string>> = new Map(); // contextHash -> targetContexts

  async analyze(code: string, ir: UnifiedIR, graph?: SecurityGraph) {
    console.log("[Interprocedural] Constructing elite semantic linkage graph from IR...");

    this.detectFrameworks(code);
    this.extractClassMetadata(ir);
    this.resolveVirtualDispatch();
    this.buildCallGraph(ir);
    
    // Perform a recursive context-sensitive traversal for deeper analysis
    const entryPoints = ["main", "runtime_bytecode"];
    entryPoints.forEach(ep => {
      if (ir.functions.has(ep)) {
        this.traverseContextSensitive(ir, ep, { callStack: [ep] });
      }
    });

    return {
      frameworks: Array.from(this.frameworkManifest),
      callGraph: Object.fromEntries(this.globalCallGraph),
      contextualGraph: this.serializeContextGraph(),
      inheritance: Object.fromEntries(this.inheritanceMap),
      virtualTable: Object.fromEntries(this.virtualTable),
      metrics: {
        depth: this.calculateMaxCallDepth(),
        complexity: this.estimateInterproceduralComplexity()
      }
    };
  }

  private extractClassMetadata(ir: UnifiedIR) {
    // In a real IR, classes would be represented. 
    // Here we use a heuristic based on function names: ClassName.methodName
    ir.functions.forEach((func, name) => {
      if (name.includes(".")) {
        const [className, methodName] = name.split(".");
        let meta = this.classMetadata.get(className);
        if (!meta) {
          meta = { methods: [] };
          this.classMetadata.set(className, meta);
        }
        meta.methods.push(methodName);
      }
    });
  }

  private resolveVirtualDispatch() {
    this.classMetadata.forEach((meta, className) => {
      meta.methods.forEach(method => {
        const key = `${className}.${method}`;
        const impls = [key];
        
        // Search in sub-classes
        const children = this.inheritanceMap.get(className) || [];
        const queue = [...children];
        while (queue.length > 0) {
          const subClass = queue.shift()!;
          if (this.classMetadata.get(subClass)?.methods.includes(method)) {
            impls.push(`${subClass}.${method}`);
          }
          queue.push(...(this.inheritanceMap.get(subClass) || []));
        }
        this.virtualTable.set(key, impls);
      });
    });
  }

  private buildCallGraph(ir: UnifiedIR) {
    ir.functions.forEach((func, name) => {
      const callees = new Set<string>();
      func.blocks.forEach(block => {
        block.instructions.forEach(inst => {
          if (inst.opcode === OpCode.CALL) {
            const potentialTargets = this.resolvePotentialTargets(inst, ir);
            potentialTargets.forEach(t => callees.add(t));
          }
        });
      });
      this.globalCallGraph.set(name, Array.from(callees));
    });
  }

  private resolvePotentialTargets(inst: IRInstruction, ir: UnifiedIR): string[] {
    const callee = inst.operands[0];
    if (typeof callee !== "string") return [];

    // Virtual dispatch resolution
    if (callee.includes(".")) {
        const [obj, method] = callee.split(".");
        // Check if we know the type of obj
        // In real analysis, this would be object-sensitive
        if (this.virtualTable.has(callee)) {
            return this.virtualTable.get(callee)!;
        }
    }

    // Dynamic Dispatch: If callee is a variable, it could point to many things
    if (callee.startsWith("var_") || callee.startsWith("ptr_")) {
        // Simple heuristic: match by signature if possible
        // For now, return empty or based on semantic data
    }

    return [callee];
  }

  private traverseContextSensitive(ir: UnifiedIR, funcName: string, ctx: AnalysisContext, depth: number = 0) {
    if (depth > 20 || ctx.callStack.length > 20) return;

    const ctxHash = this.getHash(ctx);
    const func = ir.functions.get(funcName);
    if (!func) return;

    func.blocks.forEach(block => {
      block.instructions.forEach(inst => {
        if (inst.opcode === OpCode.CALL) {
          const targets = this.resolvePotentialTargets(inst, ir);
          targets.forEach(target => {
            const nextCtx: AnalysisContext = {
              callStack: [...ctx.callStack, target],
              objectThis: inst.operands[0].includes(".") ? inst.operands[0].split(".")[0] : ctx.objectThis
            };
            
            const nextHash = this.getHash(nextCtx);
            const targetsForCtx = this.contextCallGraph.get(ctxHash) || new Set();
            targetsForCtx.add(nextHash);
            this.contextCallGraph.set(ctxHash, targetsForCtx);

            // Avoid infinite recursion
            if (!ctx.callStack.includes(target) || ctx.callStack.filter(f => f === target).length < 2) {
                this.traverseContextSensitive(ir, target, nextCtx, depth + 1);
            }
          });
        }
      });
    });
  }

  private getHash(ctx: AnalysisContext): string {
    return ctx.callStack.join("->") + (ctx.objectThis ? `[@${ctx.objectThis}]` : "");
  }

  private serializeContextGraph(): any {
    const obj: any = {};
    this.contextCallGraph.forEach((targets, src) => {
        obj[src] = Array.from(targets);
    });
    return obj;
  }

  private calculateMaxCallDepth(): number {
    let max = 0;
    this.globalCallGraph.forEach((_, start) => {
      max = Math.max(max, this.getCallDepth(start, new Set()));
    });
    return max;
  }

  private getCallDepth(func: string, seen: Set<string>): number {
    if (seen.has(func)) return 0; // Cycle detected
    seen.add(func);
    
    const callees = this.globalCallGraph.get(func) || [];
    if (callees.length === 0) return 1;
    
    let subMax = 0;
    callees.forEach(c => {
      subMax = Math.max(subMax, this.getCallDepth(c, new Set(seen)));
    });
    return 1 + subMax;
  }

  private estimateInterproceduralComplexity(): number {
    let nodes = this.globalCallGraph.size;
    let edges = 0;
    this.globalCallGraph.forEach(callees => edges += callees.length);
    return nodes + edges;
  }

  private detectFrameworks(code: string) {
    const frameworks = [
      { key: "express", name: "Express" },
      { key: "next/", name: "NextJS" },
      { key: "@nestjs", name: "NestJS" },
      { key: "@google/genai", name: "Gemini SDK" },
      { key: "react", name: "React" }
    ];
    frameworks.forEach(f => {
      if (code.toLowerCase().includes(f.key)) this.frameworkManifest.add(f.name);
    });
  }
}
