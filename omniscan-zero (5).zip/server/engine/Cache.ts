import fs from "fs-extra";
import path from "path";
import crypto from "crypto";

export interface ScanCacheData {
  previousCommit: string;
  files: Record<string, {
    hash: string;
    findings: any[];
  }>;
}

export class ScanCache {
  private cacheFilePath = "/tmp/omniscan_fingerprints.json";
  private cache: Record<string, ScanCacheData> = {};

  constructor() {
    this.loadCache();
  }

  private async loadCache() {
    try {
      if (await fs.pathExists(this.cacheFilePath)) {
        this.cache = await fs.readJson(this.cacheFilePath);
      }
    } catch (e) {
      console.error("Cache load error", e);
    }
  }

  private async saveCache() {
    try {
      await fs.writeJson(this.cacheFilePath, this.cache, { spaces: 2 });
    } catch (e) {
      console.error("Cache save error", e);
    }
  }

  public getCache(repoIdentifier: string): ScanCacheData | undefined {
    return this.cache[repoIdentifier];
  }

  public async updateCache(repoIdentifier: string, commit: string, files: Record<string, { hash: string, findings: any[] }>) {
    this.cache[repoIdentifier] = {
      previousCommit: commit,
      files
    };
    await this.saveCache();
  }
}
