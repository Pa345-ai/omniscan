import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class AccessControlAuditor extends BaseAuditor {
  name = "Access Control Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/app\.(get|post|put|delete)\(\s*['"][^'"]*admin[^'"]*['"]\s*,\s*(async\s+)?\(req,\s*res/i.test(code) && !/auth|rbac|permission|roleAdmin/i.test(code)) {
        findings.push(this.createFinding({
            title: "Broken Access Control",
            severity: "High",
            reasoning: "Administrative route detected without explicit role/permission checks.",
            solution: "Enforce strict Role-Based Access Control (RBAC) middleware for admin APIs.",
            confidence: 0.7
        }));
    }
    return findings;
  }
}
