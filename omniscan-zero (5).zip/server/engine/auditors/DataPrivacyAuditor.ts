import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class DataPrivacyAuditor extends BaseAuditor {
  name = "Data Privacy Scanner";
  category = "Compliance";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(ssn|social_security|credit_card|passport)\s*[:=].*req\.(body|params)/i.test(code) && !/(encrypt|hash|mask)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Unencrypted PII Storage/Processing",
            severity: "High",
            reasoning: "Potentially highly sensitive PII is handled without encryption.",
            solution: "Use field-level encryption for at-rest storage of PII.",
            confidence: 0.7
        }));
    }
    return findings;
  }
}
