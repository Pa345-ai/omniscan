import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class PromptInjectionAuditor extends BaseAuditor {
  name = "Prompt Injection Scanner";
  category = "AI Security" as const;

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/llm\.complete|openai\.ChatCompletion|prompt\s*\+.*req\.body/i.test(code)) {
        findings.push(this.createFinding({
            title: "Potential Prompt Injection",
            severity: "High",
            reasoning: "User-controlled input is directly concatenated into an LLM prompt/system prompt.",
            solution: "Use few-shot boundaries, separate user input from system prompts, or use guardrails.",
            confidence: 0.85
        }));
    }
    return findings;
  }
}
