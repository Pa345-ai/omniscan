import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class CSRFAuditor extends BaseAuditor {
  name = "CSRF Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/app\.(post|put|delete|patch)/i.test(code) && !/csrf|token|csurf/i.test(code) && !/sameSite/i.test(code)) {
        findings.push(this.createFinding({
            title: "Missing CSRF Protection",
            severity: "Medium",
            reasoning: "State-changing routes detected without apparent CSRF tokens or SameSite cookie configuration.",
            solution: "Implement Anti-CSRF tokens or use SameSite=Lax/Strict cookies.",
            confidence: 0.6
        }));
    }
    return findings;
  }
}
