import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class NetworkSecurityAuditor extends BaseAuditor {
  name = "Network Security Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(http\.createServer|https\.createServer\(\{\s*rejectUnauthorized\s*:\s*false)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Insecure Network Configuration (TLS)",
            severity: "Medium",
            reasoning: "Server disabled TLS validation or is only serving over unencrypted HTTP.",
            solution: "Require TLS and valid certificates for all remote connections.",
            confidence: 0.8
        }));
    }
    return findings;
  }
}
