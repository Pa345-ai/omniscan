
import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";
import { BytecodeDecompiler } from "../BytecodeDecompiler";

export class EVMBytecodeAuditor extends BaseAuditor {
  name = "EVM Bytecode Auditor";
  category = "Smart Contract Security";
  private decompiler = new BytecodeDecompiler();

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    // Check if the "code" looks like bytecode (hex string)
    const isBytecode = /^(0x)?[0-9a-fA-F]{40,}$/.test(code.trim()) && !code.includes("pragma solidity");
    
    if (!isBytecode) {
      return [];
    }

    const findings: BugReport[] = [];
    const result = this.decompiler.decompile(code);

    // 1. Function Recovrery Info
    if (result.functions.length > 0) {
        findings.push(this.createFinding({
            title: "Disclosed Function Selectors",
            severity: "Low",
            reasoning: `Found ${result.functions.length} function selectors in bytecode: ${result.functions.slice(0, 5).join(", ")}${result.functions.length > 5 ? '...' : ''}`,
            solution: "Verify these selectors against known function databases (like 4byte.directory) to map them to original function names.",
            confidence: 0.8
        }));
    }

    // 1.5 Storage Layout Recovery
    if (result.storageSlots.length > 0) {
        findings.push(this.createFinding({
            title: "Recovered Storage Layout",
            severity: "Low",
            reasoning: `Identified ${result.storageSlots.length} potential storage slots being accessed: ${result.storageSlots.slice(0, 5).join(", ")}${result.storageSlots.length > 5 ? '...' : ''}`,
            solution: "Verify if these slots correspond to sensitive state variables (e.g., owner, balances) and ensure they are protected by appropriate access controls.",
            confidence: 0.7
        }));
    }

    // 2. Map vulnerabilities from decompiler to findings
    result.vulnerabilities.forEach(vuln => {
        let severity: "High" | "Medium" | "Low" = "Medium";
        let title = "Bytecode Vulnerability Detected";
        let cwe = "";

        if (vuln.includes("SELFDESTRUCT")) {
            severity = "High";
            title = "SELFDESTRUCT Instruction Detected";
            cwe = "CWE-670";
        } else if (vuln.includes("DELEGATECALL")) {
            severity = "High";
            title = "DELEGATECALL Instruction Detected";
            cwe = "CWE-829";
        } else if (vuln.includes("CALL and SSTORE")) {
            severity = "Medium";
            title = "Potential Reentrancy Pattern in Bytecode";
            cwe = "CWE-841";
        }

        findings.push(this.createFinding({
            title,
            severity,
            cwe,
            reasoning: vuln,
            solution: "Review the contract logic to ensure this instruction is only reachable by authorized users and doesn't lead to state hijacking.",
            confidence: 0.7
        }));
    });

    // 3. Known Malicious Bytecode Signatures (Rug Pulls / Honeypots)
    const maliciousSignatures = [
        { sig: "73...ff", name: "Direct Selfdestruct Rugpull" }, // Simplified
        { sig: "608060405234801561001057600080fd5b50610113", name: "Generic Honeypot Template" }
    ];

    maliciousSignatures.forEach(m => {
        if (code.includes(m.sig)) {
            findings.push(this.createFinding({
                title: `Known Malicious Signature: ${m.name}`,
                severity: "High",
                reasoning: "The bytecode matches a known malicious contract template frequently used in rug pulls or honeypots.",
                solution: "Do not interact with this contract. It is highly likely to be a scam.",
                confidence: 0.9
            }));
        }
    });

    return findings;
  }
}
