import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class SSTIAuditor extends BaseAuditor {
  name = "Template Injection (SSTI) Specialist";
  category = "Injection & RCE";
  description = "Detects Server-Side Template Injection across multiple engines (EJS, Pug, Handlebars, Jinja2, etc.)";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];

    // 1. Detect Template Engine Usage & Imports
    const engines = [
      { name: 'EJS', pattern: /require\(['"]ejs['"]\)|import.*from\s+['"]ejs['"]/i },
      { name: 'Pug', pattern: /require\(['"]pug['"]\)|import.*from\s+['"]pug['"]/i },
      { name: 'Handlebars', pattern: /require\(['"]handlebars['"]\)|import.*from\s+['"]handlebars['"]/i },
      { name: 'Mustache', pattern: /require\(['"]mustache['"]\)|import.*from\s+['"]mustache['"]/i },
      { name: 'Nunjucks', pattern: /require\(['"]nunjucks['"]\)|import.*from\s+['"]nunjucks['"]/i },
      { name: 'Twig', pattern: /Twig/ },
      { name: 'Jinja2', pattern: /jinja2/i }
    ];

    const detectedEngines = engines.filter(e => e.pattern.test(code)).map(e => e.name);

    // 2. Generic SSTI Pattern: user input concatenated into render/compile
    const inputSources = ['req\\.body', 'req\\.query', 'req\\.params', 'req\\.headers', 'window\\.location', 'input'];
    const renderMethods = ['render', 'compile', 'renderString', 'renderFile'];
    
    for (const source of inputSources) {
      for (const method of renderMethods) {
        // Pattern like: ejs.render(req.query.tmpl, ...) or pug.compile(userInput)
        const sstiRegex = new RegExp(`${method}\\s*\\(\\s*.*${source}.*`, 'i');
        if (sstiRegex.test(code)) {
          findings.push(this.createFinding({
            title: `Potential Server-Side Template Injection (SSTI)`,
            severity: "High",
            reasoning: `User-controlled input from '${source.replace('\\', '')}' is being passed directly into a template '${method}' function. This can allow an attacker to inject malicious template directives, leading to Remote Code Execution (RCE).`,
            solution: "Never pass unsanitized user input directly as a template string. Use a static template file and pass user data as context variables which are properly escaped by the engine.",
            confidence: 0.85,
            cwe: "CWE-94"
          }));
        }
      }
    }

    // 3. EJS Specific: Dynamic View Names in Express
    // res.render(req.query.page)
    if (code.includes("res.render")) {
      const ejsDynamicView = /res\.render\s*\(\s*req\.(query|params|body)\./i;
      if (ejsDynamicView.test(code)) {
        findings.push(this.createFinding({
          title: "Insecure Dynamic View Rendering (EJS/Express)",
          severity: "High",
          reasoning: "The application uses user-controlled input to determine which view file to render. While not direct SSTI in the template string, in many configurations (like EJS), this can be exploited to render arbitrary files or even achieve RCE if the engine allows it.",
          solution: "Use an allowlist of permitted view names or a mapping object to translate user input to internal view paths.",
          confidence: 0.9,
          cwe: "CWE-706"
        }));
      }
    }

    // 4. Handlebars: Insecure Helper Registration
    if (code.includes("Handlebars.registerHelper")) {
      if (code.includes("eval(") || code.includes("new Function")) {
        findings.push(this.createFinding({
          title: "Insecure Handlebars Helper Implementation",
          severity: "High",
          reasoning: "Custom Handlebars helper detected using dangerous execution functions (eval/new Function). This is a common pattern for creating highly exploitable SSTI vectors.",
          solution: "Avoid dynamic code execution in template helpers. Implement logic using standard JavaScript without metaprogramming.",
          confidence: 0.8
        }));
      }
    }

    // 5. Detect usage of "raw" or "unescaped" tags when combined with user input
    // Handlebars: {{{ ... }}}, EJS: <%- ... %>, Jinja: {{ ... | safe }}
    const unescapedPatterns = [
      { engine: 'Handlebars', tag: '{{{', pattern: /\{\{\{.*(req\.|query|params|body).*\}\}\}/i },
      { engine: 'EJS', tag: '<%-', pattern: /<%-.*(req\.|query|params|body).*%/i },
      { engine: 'Jinja/Twig', tag: 'safe', pattern: /\{\{.*(req\.|query|params|body).*\|\s*safe\s*\}\}/i }
    ];

    for (const item of unescapedPatterns) {
      if (item.pattern.test(code)) {
        findings.push(this.createFinding({
          title: `Unescaped User Input in ${item.engine} Template`,
          severity: "Medium",
          reasoning: `User input is being rendered using unescaped tags ('${item.tag}'). While this primarily leads to XSS, it can also facilitate SSTI if the engine allows nested evaluations or if it's used in a sensitive context.`,
          solution: `Use standard escaping tags (e.g., {{ ... }} for Handlebars, <%= ... %> for EJS) which automatically neutralize malicious input.`,
          confidence: 0.7,
          cwe: "CWE-79"
        }));
      }
    }

    return findings;
  }
}
