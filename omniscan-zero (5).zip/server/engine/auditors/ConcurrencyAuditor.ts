import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class ConcurrencyAuditor extends BaseAuditor {
  name = "Concurrency Scanner";
  category = "Logic";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(go\s+func|Promise\.all).*(read.*write|select.*update)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Race Condition (TOCTOU)",
            severity: "High",
            reasoning: "Potential race condition detected around state reading and writing logic.",
            solution: "Use locks, atomic operations, or transactional isolation levels.",
            confidence: 0.6
        }));
    }
    return findings;
  }
}
