
import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";
import { IntelligenceKnowledgeBase } from "../knowledge/KnowledgeBase";

export class CVEIntegrityAuditor extends BaseAuditor {
  name = "CVE & Intelligence Auditor";
  category = "Intelligence & Historical";
  private intelligence = new IntelligenceKnowledgeBase();

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    const ir = context.metadata?.ir;

    // 1. Match against known CVE patterns (Regex + Structural)
    const matchedCVEs = this.intelligence.getMatchingCVEs(code);
    
    // Simulate structural resemblance mapping
    if (ir) {
      if (code.includes("selfdestruct") && code.includes("msg.sender")) {
        findings.push(this.createFinding({
            title: "Structural Resemblance: Reentrancy-to-SelfDestruct Chain",
            severity: "Critical",
            reasoning: "The IR sequence of this function structurally matches the 'SelfDestruct' exploit chain pattern identified in historical EVM compromises.",
            solution: "Implement a reentrancy guard or remove the selfdestruct capability.",
            confidence: 0.95
        }));
      }
    }

    matchedCVEs.forEach(cve => {
      findings.push(this.createFinding({
        title: `Historical CVE Match: ${cve.id} (${cve.title})`,
        severity: cve.severity,
        reasoning: `Code structure resembles the vulnerability patterns for ${cve.id}: ${cve.description}`,
        solution: "Patch the dependency or implement the recommended fix for this CVE.",
        confidence: 0.9,
        cves: [cve.id],
        cwe: cve.cwe,
        aiExplanation: `Knowledge Graph Insight: This pattern is mapped to the '${cve.title}' attack ontology node which involves ${cve.affectedVersions.join(", ")} logic flows.`
      }));
    });

    // 2. Detect Exploit Primitives
    const matchedPrimitives = this.intelligence.getMatchingPrimitives(code);
    matchedPrimitives.forEach(p => {
      findings.push(this.createFinding({
        title: `Exploit Primitive Detected: ${p.name}`,
        severity: "High",
        reasoning: p.description,
        solution: "Use safe wrapper functions or sanitize sources before they reach the detected sink.",
        confidence: 0.85
      }));
    });

    // 3. Framework-aware Analysis
    const frameworks = this.intelligence.detectFrameworks(code);
    frameworks.forEach(f => {
      findings.push(this.createFinding({
        title: `Framework Identified: ${f.name}`,
        severity: "Low",
        reasoning: `The scanner identified usage of ${f.name}. Applying framework-specific sink checks.`,
        solution: "No action required, purely informational.",
        confidence: 1.0
      }));

      // Check for dangerous framework-specific sinks
      f.commonSinks.forEach(sink => {
        if (code.includes(sink)) {
          findings.push(this.createFinding({
            title: `Dangerous Framework Sink: ${sink} (${f.name})`,
            severity: "Medium",
            reasoning: `Identified common sensitive sink for ${f.name}. Ensuring input is properly validated.`,
            solution: "Verify that all inputs reaching this sink are validated or sanitized.",
            confidence: 0.75
          }));
        }
      });
    });

    return findings;
  }
}
