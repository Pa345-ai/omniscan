import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class SecretAuditor extends BaseAuditor {
  name = "Secret Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    const secretRegex = /AIza[0-9A-Za-z-_]{35}|[0-9a-f]{32}|pk_live_[0-9a-zA-Z]{24}/g;
    if (secretRegex.test(code)) {
      findings.push(this.createFinding({
        title: "Hardcoded Secrets Detected",
        severity: "High",
        reasoning: "Potential API keys or secrets found in the codebase.",
        solution: "Move secrets to environment variables.",
        confidence: 0.99
      }));
    }
    return findings;
  }
}
