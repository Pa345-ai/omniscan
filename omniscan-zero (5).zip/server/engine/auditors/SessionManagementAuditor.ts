import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class SessionManagementAuditor extends BaseAuditor {
  name = "Session Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/express-session/i.test(code) && !/secure:\s*true/i.test(code) && !/httpOnly:\s*true/i.test(code)) {
        findings.push(this.createFinding({
            title: "Insecure Session Cookie configuration",
            severity: "Medium",
            reasoning: "Session cookie lacks Secure and/or HttpOnly flags.",
            solution: "Set cookie: { secure: true, httpOnly: true } in session config.",
            confidence: 0.8
        }));
    }
    return findings;
  }
}
