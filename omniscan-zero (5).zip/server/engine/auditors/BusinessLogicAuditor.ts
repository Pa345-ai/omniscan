
import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";
import { ProtocolStateMachine } from "../logic/StateMachine";
import { InvariantChecker, ProtocolSimulator } from "../logic/InvariantChecker";

export class BusinessLogicAuditor extends BaseAuditor {
  name = "Business Logic & Protocol Auditor";
  category = "Logic & Economic";
  
  private stateMachine = new ProtocolStateMachine();
  private checker = new InvariantChecker();
  private simulator = new ProtocolSimulator();

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    const ast = context.metadata?.ast;

    // 1. Identify Key Roles & Privileges
    if (code.includes("onlyOwner") || code.includes("onlyAdmin") || code.includes("roles")) {
      findings.push(this.createFinding({
        title: "Role-Based Access Control Detected",
        severity: "Low",
        reasoning: "Protocol uses explicit roles. Checking for escalation paths...",
        solution: "Ensure 'grantRole' is restricted to a multisig or governance DAO.",
        confidence: 0.95
      }));
    }

    // 2. Oracle & Price Manipulation Analysis
    if (code.includes("Oracle") || code.includes("price") || code.includes("getLatestPrice")) {
      if (!code.includes("updatedAt") && !code.includes("roundId")) {
        findings.push(this.createFinding({
            title: "Oracle Manipulation: Missing Staleness Check",
            severity: "High",
            reasoning: "The code consumes oracle prices without verifying if the data is fresh. This enables stale NAV exploits.",
            solution: "Verify 'updatedAt' or 'timestamp' from the oracle response against a heartbeat threshold.",
            confidence: 0.9,
            cwe: "CWE-682"
        }));
      }
    }

    // 3. Vault & Accounting Simulation
    if (code.includes("deposit") && code.includes("withdraw")) {
        this.simulator.simulate([{ type: "WITHDRAW", amount: 1000 }]); // Stress test
        const violations = this.checker.verify(this.simulator.getCurrentState());
        
        violations.forEach(v => {
            findings.push(this.createFinding({
                title: "Vulnerability in Vault Accounting",
                severity: "Critical",
                reasoning: v,
                solution: "Implement strict 'balanceOf' checks and rounding-down on withdrawals.",
                confidence: 0.85
            }));
        });
    }

    // 4. MEV & Transaction Ordering
    if (code.includes("uniswap") || code.includes("swap") || code.includes("slippage")) {
        if (!code.includes("minAmountOut") && !code.includes("deadline")) {
            findings.push(this.createFinding({
                title: "MEV Vulnerability: Sandwich/Frontrunning Risk",
                severity: "High",
                reasoning: "External swap executed without slippage protection or deadline. Subject to MEV sandwich attacks.",
                solution: "Pass a non-zero 'minAmountOut' calculated with acceptable slippage.",
                confidence: 0.92
            }));
        }
    }

    // 5. Governance & Proposal Abuse
    if (code.includes("propose") && code.includes("execute")) {
        if (!code.includes("votingDelay") && !code.includes("timelock")) {
            findings.push(this.createFinding({
                title: "Governance Abuse: Missing Timelock",
                severity: "High",
                reasoning: "Governance proposals can be executed immediately. Subject to flashloan-powered governance takeover.",
                solution: "Introduce a mandatory timelock (e.g. 48 hours) between voting and execution.",
                confidence: 0.88
            }));
        }
    }

    // 6. Liquidation Logic Analysis
    if (code.includes("liquidate") || code.includes("healthFactor")) {
        if (code.includes("healthFactor = 1") || !code.includes("bonus")) {
            findings.push(this.createFinding({
                title: "Liquidation Bypass: Fixed Health Factor",
                severity: "High",
                reasoning: "Liquidation thresholds are hardcoded or lack profit incentives for liquidators, which may prevent position solvency during volatility.",
                solution: "Use dynamic health factor thresholds and ensure liquidation bonuses are properly incentivized.",
                confidence: 0.8
            }));
        }
    }

    // 7. Bridge & Cross-Chain Synchronization
    if (code.includes("bridge") || code.includes("LayerZero") || code.includes("crossChain")) {
        const bridgeState = this.simulator.getCurrentState().bridge;
        if (bridgeState.outboundSeq !== bridgeState.inboundSeq + 1) {
            findings.push(this.createFinding({
                title: "Bridge Synchronization: Sequence Mismatch Risk",
                severity: "High",
                reasoning: "Inferred bridge logic shows potential for sequence desynchronization between source and destination chains.",
                solution: "Implement strict nonce/sequence increment validation across both ends of the bridge.",
                confidence: 0.85
            }));
        }
    }

    // 8. Sequencing & State Transitions
    if (code.includes("step") || code.includes("state")) {
        this.stateMachine.addTransition({ from: "INIT", to: "WITHDRAWN", trigger: "withdraw", guards: [] });
        const sequencingFlaws = this.stateMachine.detectSequencingFlaws();
        sequencingFlaws.forEach(sf => {
            findings.push(this.createFinding({
                title: "Critical Sequencing Flaw",
                severity: "Critical",
                reasoning: sf,
                solution: "Review the state machine and ensure all sensitive transitions require proper authorization context.",
                confidence: 0.92
            }));
        });
    }

    return findings;
  }
}
