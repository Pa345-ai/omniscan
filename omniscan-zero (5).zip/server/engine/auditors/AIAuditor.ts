import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class AIAuditor extends BaseAuditor {
  name = "AI Logic Scanner";
  category = "AI Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];

    // 1. Prompt Injection: User input concatenated into LLM prompts
    const inputSources = ['req\\.body', 'req\\.query', 'req\\.params', 'req\\.headers', 'input'];
    const aiMethods = ['generateContent', 'sendMessage', 'createCompletion', 'createChatCompletion', 'chat.completions.create'];
    
    for (const source of inputSources) {
      for (const method of aiMethods) {
        const promptInjectionRegex = new RegExp(`${method}\\s*\\(\\s*.*\\$\{.*${source}.*\}.*`, 'i');
        const concatRegex = new RegExp(`${method}\\s*\\(\\s*.*${source}.*\\+.*`, 'i');
        
        if (promptInjectionRegex.test(code) || concatRegex.test(code)) {
          findings.push(this.createFinding({
            title: "Potential Prompt Injection",
            severity: "High",
            category: "AI Security",
            reasoning: `User-controlled input from '${source.replace('\\', '')}' is being directly concatenated into an LLM prompt. This allows attackers to perform prompt injection attacks, bypassing application logic or exfiltrating data.`,
            solution: "Use structured prompts or templates where user input is clearly demarcated. Implement robust input validation and consider using a 'system prompt' to enforce constraints.",
            confidence: 0.85,
            cwe: "CWE-94" // Closest related to injection/logic bypass
          }));
        }
      }
    }

    // 2. Missing System Prompt Guards
    if (aiMethods.some(m => code.includes(m))) {
      const hasSystemPrompt = code.includes("systemInstruction") || code.includes("system_message") || code.includes("'role': 'system'");
      const hasDefensivePhrase = /ignore\s+previous|ignore\s+all\s+instructions|system\s+override/i.test(code);
      
      if (!hasSystemPrompt || !hasDefensivePhrase) {
        findings.push(this.createFinding({
          title: "Missing LLM System Guardrails",
          severity: "Medium",
          category: "AI Security",
          reasoning: "The application makes LLM calls but appears to lack explicit system-level instructions to ignore adversarial user overrides. Attackers can easily bypass instructions using phrases like 'Ignore all previous instructions'.",
          solution: "Always provide a strong system prompt that explicitly instructs the model to prioritize system instructions over user input and to ignore common injection patterns.",
          confidence: 0.7,
        }));
      }
    }

    // 3. Unvalidated Tool Outputs
    if (code.includes("functionResponse") || code.includes("tool_outputs")) {
      if (!code.includes("JSON.parse") && !code.includes("validator") && !code.includes("type")) {
         findings.push(this.createFinding({
          title: "Unvalidated Tool Call Response",
          severity: "High",
          category: "AI Security",
          reasoning: "Output from a tool call or function execution is being fed back into the LLM context without apparent validation. If a tool is compromised or returns adversarial data, it can lead to Indirect Prompt Injection.",
          solution: "Always validate, sanitize, and type-check the results of tool/function calls before appending them to the model's history or context.",
          confidence: 0.8,
        }));
      }
    }

    // 4. Hijackable Agent Loops
    const loopPatterns = [/while\s*\(true\)/, /while\s*\(.*\.status\s*!==\s*['"]finish['"]\)/, /recursive/];
    if (loopPatterns.some(p => p.test(code)) && aiMethods.some(m => code.includes(m))) {
      if (!code.includes("maxSteps") && !code.includes("iterationLimit") && !code.includes("timeout")) {
        findings.push(this.createFinding({
          title: "Unbounded AI Agent Loop",
          severity: "High",
          category: "AI Security",
          reasoning: "A loop structure calling an LLM was detected without a clear iteration limit or 'max steps' safety break. Adversarial input could trick the agent into an infinite loop, leading to Denial of Service or massive API costs.",
          solution: "Implement a strict maximum iteration count (e.g., 5-10 steps) for all autonomous agent loops.",
          confidence: 0.75,
          cwe: "CWE-835"
        }));
      }
    }

    // 5. Insecure LLM Output Storage
    const dbSaveMethods = ['db.save', '.insert(', '.update(', 'upsert'];
    if (aiMethods.some(m => code.includes(m)) && dbSaveMethods.some(db => code.includes(db))) {
      if (!code.includes("filter") && !code.includes("sanitize") && !code.includes("contentSafety")) {
        findings.push(this.createFinding({
          title: "Insecure Storage of LLM Generations",
          severity: "Medium",
          category: "AI Security",
          reasoning: "LLM-generated content is being saved to the database without explicit content filtering or safety checks. This can lead to Stored XSS or pollution of data with hallucinations/adversarial content.",
          solution: "Pass LLM outputs through a content safety filter or sanitizer before persisting them to the database.",
          confidence: 0.65,
          cwe: "CWE-79"
        }));
      }
    }

    return findings;
  }
}
