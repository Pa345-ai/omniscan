import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class DeserializationAuditor extends BaseAuditor {
  name = "Deserialization Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(serialize-javascript|node-serialize|yaml\.load|pickle\.loads|ObjectInputStream).*(req\.(body|query)|userInput)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Unsafe Deserialization",
            severity: "Critical",
            reasoning: "Untrusted input is deserialized using an unsafe function.",
            solution: "Use safer alternatives like secure JSON parsing without prototype/class hydration.",
            confidence: 0.85
        }));
    }
    return findings;
  }
}
