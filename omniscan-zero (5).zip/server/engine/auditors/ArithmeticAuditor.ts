import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class ArithmeticAuditor extends BaseAuditor {
  name = "Arithmetic Scanner";
  category = "Logic";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(uint.*=|int.*=)\s*.*(x|\+|-|\*)\s*.*/i.test(code) && /\.(cpp|rs|go|c|h|hpp)$/i.test(context.filename)) {
        findings.push(this.createFinding({
            title: "Integer Overflow/Underflow",
            severity: "Medium",
            reasoning: "Arithmetic operation detected without explicit bounds checking.",
            solution: "Use safe math libraries or bounds checking prior to math operations.",
            confidence: 0.5
        }));
    }
    return findings;
  }
}
