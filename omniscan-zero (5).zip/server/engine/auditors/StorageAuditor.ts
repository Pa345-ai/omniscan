import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class StorageAuditor extends BaseAuditor {
  name = "Storage Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(localStorage|sessionStorage)\.setItem\(.*(token|jwt|session|password).*/i.test(code)) {
        findings.push(this.createFinding({
            title: "Insecure Local Storage",
            severity: "High",
            reasoning: "Sensitive credentials or tokens are stored in unencrypted HTML5 storage, accessible to XSS.",
            solution: "Store sensitive session tokens in HttpOnly cookies securely.",
            confidence: 0.9
        }));
    }
    return findings;
  }
}
