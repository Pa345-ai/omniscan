import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class AICodeDetectorAuditor extends BaseAuditor {
  name = "AI-Generated Code Detector";
  category = "Heuristics" as const;

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(as an ai language model|as an ai|note:|warning:).*\n/i.test(code) || /import\s+\*\s+from\s+['"]crypto['"]/i.test(code)) {
        findings.push(this.createFinding({
            title: "Likely AI-Generated Code Artefact",
            severity: "Low",
            reasoning: "Detected language model generation artefacts or typical AI hallucinated crypto import patterns.",
            solution: "Verify AI-generated code for logical errors and security flaws.",
            confidence: 0.8
        }));
    }
    return findings;
  }
}
