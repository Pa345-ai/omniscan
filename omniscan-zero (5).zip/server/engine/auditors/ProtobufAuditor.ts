import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class ProtobufAuditor extends BaseAuditor {
  name = "Protobuf Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/syntax\s*=\s*"proto2"/i.test(code) && /required/i.test(code)) {
        findings.push(this.createFinding({
            title: "Legacy Protobuf Schema Risks",
            severity: "Low",
            reasoning: "Usage of 'required' fields in proto2 can cause denial of service upon deserialization if fields are missing.",
            solution: "Migrate to proto3, or use 'optional' instead in proto2.",
            confidence: 0.8
        }));
    }
    return findings;
  }
}
