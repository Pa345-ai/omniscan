import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class CommandInjectionAuditor extends BaseAuditor {
  name = "Command Injection Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(exec|spawn|eval)\s*\(.*(req\.(query|body|params)|userInput|\$|\+).*\)/i.test(code)) {
        findings.push(this.createFinding({
            title: "OS Command Injection",
            severity: "Critical",
            reasoning: "User-controlled data flows into an OS command execution sink.",
            solution: "Avoid shelling out if possible, use language-native APIs, or properly sanitize.",
            confidence: 0.9
        }));
    }
    return findings;
  }
}
