import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class JWTOAuthAuditor extends BaseAuditor {
  name = "JWT/OAuth Auditor";
  category = "Authentication & Authorization";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    const lines = code.split('\n');

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];

        // 1. JWT alg: none attack
        if (line.match(/jwt\.verify.*algorithms\s*:\s*\[\s*['"]none['"]\s*\]/i)) {
            findings.push(this.createFinding({
                title: "JWT 'alg: none' vulnerability",
                severity: "High",
                cwe: "CWE-347",
                reasoning: "The JWT verify function is explicitly allowing the 'none' algorithm. This allows attackers to forge tokens without a valid signature.",
                solution: "Remove 'none' from the allowed algorithms list and only permit strong algorithms like 'HS256' or 'RS256'.",
                lineStart: i + 1,
                confidence: 0.9
            }));
        }

        // 2. Weak HMAC Secret
        if (line.match(/(jwt_secret|jwtSecret|secret|SECRET)\s*[:=]\s*['"](secret|123456|password|admin|test|dev)['"]/i)) {
             findings.push(this.createFinding({
                title: "Weak JWT Secret",
                severity: "High",
                cwe: "CWE-321",
                reasoning: "Hardcoded or weak (dictionary-based) secret is used for JWT signing/verification. This can be easily brute-forced, allowing token forgery.",
                solution: "Use a strong, randomly generated cryptographic key (at least 256 bits) and store it in an environment variable.",
                lineStart: i + 1,
                confidence: 0.9
            }));
        } else if (line.match(/(jwt_secret|jwtSecret|secret|SECRET)\s*[:=]\s*['"](.{1,15})['"]/i)) {
             const val = line.match(/(jwt_secret|jwtSecret|secret|SECRET)\s*[:=]\s*['"]([^'"]+)['"]/i)?.[2];
             // If it's short and looks like a constant string
             if (val && val.length < 16 && !val.includes('${')) {
                 findings.push(this.createFinding({
                    title: "Short JWT Secret",
                    severity: "High",
                    cwe: "CWE-326",
                    reasoning: "A short JWT secret was detected. Secrets shorter than 256 bits (32 characters for HS256) are susceptible to dictionary and brute-force attacks.",
                    solution: "Ensure JWT secrets are long, securely generated cryptographic keys (e.g., 32+ characters).",
                    lineStart: i + 1,
                    confidence: 0.7
                }));
             }
        }

        // 3. Missing exp validation
        if (line.match(/ignoreExpiration\s*:\s*true/i)) {
            findings.push(this.createFinding({
                title: "JWT Expiration Ignored",
                severity: "Medium",
                cwe: "CWE-613",
                reasoning: "The JWT verification is configured to ignore the expiration time (exp). This allows replay attacks if tokens are intercepted.",
                solution: "Enforce JWT expiration validation by removing 'ignoreExpiration: true' from the options, or setting it to false.",
                lineStart: i + 1,
                confidence: 0.9
            }));
        }

        // Detect verify without audience/issuer
        // Not perfectly reliable with regex, but we can look for specific configurations in options
        if (line.match(/jwt\.verify\s*\([^,]+,\s*[^,]+((?!\b(audience|issuer)\b).)*\)/i)) {
            // Not adding a finding for every verify without it to avoid FPs, maybe check if verifying without options at all
            if (line.match(/jwt\.verify\s*\([^,]+,\s*[^\),]+\)/i)) {
                // simple 2 args
                /*
                findings.push(this.createFinding({
                    title: "JWT Options Missing (Audience/Issuer)",
                    severity: "Low",
                    cwe: "CWE-345",
                    reasoning: "JWT is verified without checking the issuer (iss) or audience (aud) claims.",
                    solution: "Provide expected 'audience' and 'issuer' within the jwt.verify options.",
                    lineStart: i + 1,
                    confidence: 0.5
                }));
                */
            }
        }

        // OAuth state missing in flow creation
        // example: /oauth/authorize\?client_id=[^&]+&redirect_uri=[^&]+&response_type=code/ without state
        if (code.match(/client_id=.*&response_type=code/i) && !code.match(/state=/i)) {
             // Let's do this per file instead of line, or per line but checking for state
             if (line.match(/client_id=/i) && line.match(/response_type=code/i) && !line.match(/state=/i)) {
                findings.push(this.createFinding({
                    title: "OAuth Missing State Parameter (CSRF)",
                    severity: "High",
                    cwe: "CWE-352",
                    reasoning: "An OAuth authorization URL is constructed without the 'state' parameter. Without a secure, random state parameter, the OAuth flow is vulnerable to Cross-Site Request Forgery (CSRF).",
                    solution: "Generate a secure random string, store it in the user's session, and pass it in the 'state' parameter of the authorization request. Verify it upon the callback.",
                    lineStart: i + 1,
                    confidence: 0.8
                }));
             }
        }

        // PKCE Bypass (code challenge missing in auth request when it might be expected, or just general OAuth 2.0 best practice)
        if (line.match(/response_type=code/i) && !code.match(/code_challenge/i)) {
             findings.push(this.createFinding({
                 title: "OAuth PKCE Extension Not Used",
                 severity: "Medium",
                 cwe: "CWE-306", // Generic for missing auth context 
                 reasoning: "The OAuth authorization request does not include PKCE (Proof Key for Code Exchange) parameters ('code_challenge'). PKCE is recommended for all OAuth 2.0 clients to prevent authorization code interception attacks.",
                 solution: "Implement PKCE by generating a code verifier and sending its transformed hash as 'code_challenge' with 'code_challenge_method=S256'.",
                 lineStart: i + 1,
                 confidence: 0.6
             }));
        }

        // Detect open redirect in OAuth redirect_uri
        // Example: redirect_uri=${req.query.redirect_uri}
        if (line.match(/redirect_uri=.*(req\.query|req\.body|req\.params)/i) || line.match(/res\.redirect\s*\(\s*(req\.query|req\.body|req\.params)\./i)) {
             findings.push(this.createFinding({
                 title: "Open Redirect in OAuth Flow",
                 severity: "High",
                 cwe: "CWE-601",
                 reasoning: "The OAuth redirect_uri or an application redirect is dynamically constructed using unvalidated user input. This allows open redirect attacks.",
                 solution: "Validate the redirect URI against a strict whitelist of allowed domains or paths.",
                 lineStart: i + 1,
                 confidence: 0.8
             }));
        }
    }

    // 3. Check for specific JWT library usages without required claims
    if (code.includes('jwt.verify') && !code.includes('audience') && !code.includes('issuer')) {
        findings.push(this.createFinding({
            title: "JWT Missing Audience/Issuer Validation",
            severity: "Medium",
            cwe: "CWE-345",
            reasoning: "The code parses JWTs without verifying the 'aud' (audience) or 'iss' (issuer) claims. This could allow tokens intended for other applications to be accepted.",
            solution: "Explicitly pass 'audience' and 'issuer' checks in the configuration object to the verification function.",
            lineStart: 1,
            confidence: 0.6
        }));
    }

    // Avoid duplicating PKCE
    const uniqueFindings = findings.filter((v,i,a)=>a.findIndex(v2=>(v2.title===v.title && v2.lineStart===v.lineStart))===i);
    
    return uniqueFindings;
  }
}
