import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class IAMAuditor extends BaseAuditor {
  name = "IAM Security Analyzer";
  category = "Identity";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (code.includes("\"Action\": \"*\"") || code.includes("\"Effect\": \"Allow\"")) {
      findings.push(this.createFinding({
        title: "Over-privileged IAM Role (Wildcard Action)",
        severity: "High",
        reasoning: "IAM policy contains a wildcard (*) action. This violates the principle of least privilege and can lead to massive blast radius if credentials are leaked.",
        solution: "Enumerate specific required actions instead of using wildcards.",
        confidence: 0.99
      }));
    }
    return findings;
  }
}
