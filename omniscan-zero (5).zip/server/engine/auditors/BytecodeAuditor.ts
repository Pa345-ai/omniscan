import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";
import { BytecodeCoordinator } from "../bytecode/Coordinator";
import { Architecture } from "../BytecodeDecompiler";

export class BytecodeAuditor extends BaseAuditor {
  name = "Elite Bytecode Auditor";
  category = "Bytecode & Binary Security";
  private coordinator = new BytecodeCoordinator();

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    // Detection logic for hex bytecode or binary blobs
    const codeTrimmed = code.trim();
    const isHex = /^(0x)?[0-9a-fA-F]{40,}$/.test(codeTrimmed);
    const isWasm = codeTrimmed.startsWith("\0asm") || codeTrimmed.includes("0061736d");
    
    if (!isHex && !isWasm) {
      return [];
    }

    const findings: BugReport[] = [];
    
    try {
      const result = await this.coordinator.analyze(code);
      
      findings.push(this.createFinding({
          title: `Architecture Detected: ${result.arch.toUpperCase()}`,
          severity: "Low",
          reasoning: `The scanner identified the input as ${result.arch} bytecode. Initiating deep semantic analysis...`,
          solution: "No action required, purely informational.",
          confidence: 1.0
      }));

      // Map vulnerabilities from deep analysis
      result.vulnerabilities.forEach(vuln => {
        findings.push(this.createFinding({
          title: "Bytecode Vulnerability Detected",
          severity: vuln.includes("Critical") ? "Critical" : (vuln.includes("High") ? "High" : "Medium"),
          reasoning: vuln,
          solution: "Disassemble/Decompile the binary to verify the instruction sequence and ensure proper bounds checking or auth guards.",
          confidence: 0.85
        }));
      });

      if (result.arch === Architecture.EVM) {
        this.addEVMSpecificFindings(result, findings);
      } else if (result.arch === Architecture.WASM) {
        this.addWASMSpecificFindings(result, findings);
      } else if (result.arch === Architecture.JVM) {
        this.addJVMSpecificFindings(result, findings);
      }

    } catch (e) {
      console.error("Bytecode analysis failed", e);
    }

    return findings;
  }

  private addWASMSpecificFindings(result: any, findings: BugReport[]) {
    findings.push(this.createFinding({
        title: "WASM: Potential Memory Limit Exhaustion",
        severity: "Medium",
        reasoning: "WASM module detected. Without explicit memory limits, a module could consume host resources uncontrollably.",
        solution: "Use the --max-memory flag during instantiation or limit the number of initial/maximum pages in the WASM memory section.",
        confidence: 0.8
    }));
  }

  private addJVMSpecificFindings(result: any, findings: BugReport[]) {
    findings.push(this.createFinding({
        title: "JVM: Insecure Class Loading",
        severity: "High",
        reasoning: "Java/Kotlin bytecode analysis found patterns associated with dynamic class loading which can lead to arbitrary code execution if inputs are untrusted.",
        solution: "Use a restricted ClassLoader with a whitelist of permitted classes.",
        confidence: 0.75
    }));
  }

  private addEVMSpecificFindings(result: any, findings: BugReport[]) {
      if (result.functions.length > 0) {
          findings.push(this.createFinding({
              title: "EVM: Disclosed Function Selectors",
              severity: "Low",
              reasoning: `Found ${result.functions.length} function selectors. Mapping these can reveal the contract's interface.`,
              solution: "Compare with 4byte.directory.",
              confidence: 0.9
          }));
      }
  }
}
