import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class ComplianceAuditor extends BaseAuditor {
  name = "Compliance Scanner";
  category = "Compliance";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/cookie\(|req\.session/i.test(code) && !/cookie-consent|GDPR/i.test(code)) {
        findings.push(this.createFinding({
            title: "Potential Compliance (GDPR) Issue",
            severity: "Low",
            reasoning: "Session/cookies created without apparent consent logic.",
            solution: "Ensure cookie banners and consent tracking are enforced where required.",
            confidence: 0.4
        }));
    }
    return findings;
  }
}
