import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class CrossChainAuditor extends BaseAuditor {
  name = "Cross-Chain Bridge Scanner";
  category = "Web3 Security" as const;

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/ecrecover/i.test(code) && !/chainid/i.test(code)) {
        findings.push(this.createFinding({
            title: "Cross-Chain Replay Attack",
            severity: "Critical",
            reasoning: "Signature verification lacks chainid, allowing a valid signature on Chain A to be replayed on Chain B.",
            solution: "Include block.chainid in the signed payload (EIP-712 domain separator).",
            confidence: 0.9
        }));
    }
    return findings;
  }
}
