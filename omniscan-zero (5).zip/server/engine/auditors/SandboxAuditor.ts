import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class SandboxAuditor extends BaseAuditor {
  name = "Sandbox Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(vm\.createContext|vm\.runInContext|isolated-vm)/i.test(code) && !/sandbox/i.test(code)) {
        findings.push(this.createFinding({
            title: "Potential Sandbox Escape",
            severity: "High",
            reasoning: "Insecure usage of Node VM modules can sometimes be escaped.",
            solution: "Use robust sandboxing environments, dropping privileges. Consider isolated-vm properly configured.",
            confidence: 0.5
        }));
    }
    return findings;
  }
}
