import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class CryptoAuditor extends BaseAuditor {
  name = "Crypto Scanner";
  category = "Cryptography";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (code.includes("md5") || code.includes("sha1")) {
      findings.push(this.createFinding({
        title: "Weak Cryptographic Algorithm",
        severity: "Medium",
        reasoning: "MD5/SHA1 detected. These are deprecated and vulnerable to collision attacks.",
        solution: "Upgrade to SHA-256 or better.",
        confidence: 0.95
      }));
    }
    return findings;
  }
}
