import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";
import yaml from 'js-yaml';

export class InfrastructureAuditor extends BaseAuditor {
  name = "Infrastructure & IaC Auditor";
  category = "Infrastructure";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    const fileName = context.filename.toLowerCase();

    if (fileName.includes('dockerfile')) {
      findings.push(...this.auditDockerfile(code));
    } else if (fileName.endsWith('.yaml') || fileName.endsWith('.yml')) {
      findings.push(...this.auditKubernetes(code));
    } else if (fileName.endsWith('.tf')) {
      findings.push(...this.auditTerraform(code));
    }

    return findings;
  }

  private auditDockerfile(code: string): BugReport[] {
    const findings: BugReport[] = [];
    const lines = code.split('\n');

    let hasUser = false;
    let hasHealthcheck = false;

    lines.forEach((line, index) => {
      const trimmed = line.trim();
      
      // 1. Running as root (default if no USER is found)
      if (trimmed.startsWith('USER ')) {
        hasUser = true;
      }

      // 2. Secrets in ARG/ENV
      if (trimmed.match(/^(ARG|ENV)\s+(.*(PASSWORD|SECRET|KEY|TOKEN|AUTH|CREDENTIALS).*=)/i)) {
        findings.push(this.createFinding({
          title: "Sensitive data in Dockerfile (ARG/ENV)",
          severity: "High",
          cwe: "CWE-522",
          reasoning: "Secrets or credentials found in ARG or ENV instructions are persisted in the image layers and can be retrieved by anyone with access to the image.",
          solution: "Use build-time secrets (e.g., Docker secrets or BuildKit --secret) or environment variables injected at runtime.",
          lineStart: index + 1,
          confidence: 0.9
        }));
      }

      // 3. COPY . . including .env
      if (trimmed.match(/^COPY\s+\.\s+\./i)) {
        findings.push(this.createFinding({
          title: "Potentially insecure COPY instruction",
          severity: "Medium",
          cwe: "CWE-200",
          reasoning: "Using 'COPY . .' might inadvertently include sensitive files like .env or local configuration files if a .dockerignore is not properly configured.",
          solution: "Be explicit about which files to copy or ensure a comprehensive .dockerignore file is present.",
          lineStart: index + 1,
          confidence: 0.7
        }));
      }

      // 4. Mutable base image tags
      if (trimmed.startsWith('FROM ')) {
        const tagMatch = trimmed.match(/FROM\s+([^\s:]+)(?::([^\s@]+))?(@[^\s]+)?/i);
        if (tagMatch) {
          const tag = tagMatch[2];
          const digest = tagMatch[3];
          if (!digest && (!tag || tag === 'latest')) {
            findings.push(this.createFinding({
              title: "Use of mutable or missing image tag",
              severity: "Medium",
              cwe: "CWE-494",
              reasoning: "Base images using 'latest' or no tag are mutable and can lead to non-deterministic builds and security regressions when the base image is updated.",
              solution: "Use a specific version tag or, ideally, an immutable image digest (SHA256).",
              lineStart: index + 1,
              confidence: 0.9
            }));
          }
        }
      }

      if (trimmed.startsWith('HEALTHCHECK ')) {
        hasHealthcheck = true;
      }
    });

    if (!hasUser) {
      findings.push(this.createFinding({
        title: "Dockerfile missing USER instruction",
        severity: "High",
        cwe: "CWE-250",
        reasoning: "No USER instruction found. The container will run as 'root' by default, which violates the principle of least privilege.",
        solution: "Add a 'USER <non-root-user>' instruction at the end of the Dockerfile.",
        confidence: 0.8
      }));
    }

    if (!hasHealthcheck) {
      findings.push(this.createFinding({
        title: "Dockerfile missing HEALTHCHECK",
        severity: "Low",
        reasoning: "Missing HEALTHCHECK instruction prevents the container orchestrator from detecting if the application inside the container is actually functional.",
        solution: "Add a 'HEALTHCHECK' instruction to your Dockerfile.",
        confidence: 0.8
      }));
    }

    return findings;
  }

  private auditKubernetes(code: string): BugReport[] {
    const findings: BugReport[] = [];
    try {
      const docs = yaml.loadAll(code) as any[];
      
      docs.forEach((doc) => {
        if (!doc) return;

        // Traverse doc for common K8s patterns
        this.traverseK8s(doc, findings);
      });
    } catch (e) {
      // Not a valid YAML or K8s file, skip
    }
    return findings;
  }

  private traverseK8s(val: any, findings: BugReport[]) {
    if (!val || typeof val !== 'object') return;

    // 1. Privileged: true
    if (val.privileged === true) {
      findings.push(this.createFinding({
        title: "Privileged container detected",
        severity: "High",
        cwe: "CWE-250",
        reasoning: "The container is running with 'privileged: true', granting it nearly all the same access as processes on the host.",
        solution: "Disable privileged mode and use specific 'capabilities' if necessary.",
        confidence: 0.9
      }));
    }

    // 2. Missing runAsNonRoot
    if (val.securityContext) {
      if (val.securityContext.runAsNonRoot === false) {
        findings.push(this.createFinding({
          title: "Container allowed to run as root",
          severity: "Medium",
          cwe: "CWE-250",
          reasoning: "SecurityContext explicitly allows running as root.",
          solution: "Set 'runAsNonRoot: true' in the securityContext.",
          confidence: 0.9
        }));
      }
    } else if (val.image && !val.securityContext) {
      // If we are in a container specification but no securityContext exists
       findings.push(this.createFinding({
          title: "Missing runAsNonRoot security context",
          severity: "Low",
          cwe: "CWE-250",
          reasoning: "The security context is missing 'runAsNonRoot', making it possible for the container to run as root if not restricted elsewhere.",
          solution: "Add 'securityContext: runAsNonRoot: true' to the specification.",
          confidence: 0.6
        }));
    }

    // 3. No resource limits
    if (val.containers && Array.isArray(val.containers)) {
      val.containers.forEach((container: any) => {
        if (!container.resources || !container.resources.limits) {
          findings.push(this.createFinding({
            title: "Missing resource limits",
            severity: "Medium",
            cwe: "CWE-770",
            reasoning: "No resource limits defined for the container. This can lead to resource exhaustion (DoS) on the node.",
            solution: "Define CPU and memory limits for all containers.",
            confidence: 0.7
          }));
        }

        // 4. Exposed secrets in env vars
        if (container.env && Array.isArray(container.env)) {
          container.env.forEach((e: any) => {
            if (e.value && /PASSWORD|SECRET|KEY|TOKEN|AUTH/i.test(e.name)) {
              findings.push(this.createFinding({
                title: "Sensitive data in K8s environment variables",
                severity: "High",
                cwe: "CWE-522",
                reasoning: "Secrets found in 'env' instead of 'envFrom' or 'secretKeyRef'.",
                solution: "Use Kubernetes Secrets and reference them via 'secretKeyRef'.",
                confidence: 0.9
              }));
            }
          });
        }
      });
    }

    // 5. RBAC wildcards
    if (val.kind === 'Role' || val.kind === 'ClusterRole') {
      if (val.rules && Array.isArray(val.rules)) {
        val.rules.forEach((rule: any) => {
          if ((rule.resources && rule.resources.includes('*')) || (rule.verbs && rule.verbs.includes('*'))) {
            findings.push(this.createFinding({
              title: "Over-permissive RBAC wildcard",
              severity: "High",
              cwe: "CWE-250",
              reasoning: "RBAC role uses wildcards (*) for resources or verbs, granting excessive permissions.",
              solution: "Follow the principle of least privilege and specify exact resources and verbs required.",
              confidence: 0.9
            }));
          }
        });
      }
    }

    // Recurse
    Object.values(val).forEach(v => this.traverseK8s(v, findings));
  }

  private auditTerraform(code: string): BugReport[] {
    const findings: BugReport[] = [];
    const lines = code.split('\n');

    lines.forEach((line, index) => {
      const trimmed = line.trim();

      // 1. S3 buckets with public ACL
      if (trimmed.match(/acl\s*=\s*['"]public-read['"]/i) || trimmed.match(/acl\s*=\s*['"]public-read-write['"]/i)) {
        findings.push(this.createFinding({
          title: "S3 Bucket with public ACL",
          severity: "High",
          cwe: "CWE-200",
          reasoning: "S3 bucket is configured with a public access control list. This can lead to unauthorized data exposure.",
          solution: "Set ACL to 'private' and use bucket policies for controlled access.",
          lineStart: index + 1,
          confidence: 0.9
        }));
      }

      // 2. Security groups with 0.0.0.0/0
      if (trimmed.match(/cidr_blocks\s*=\s*\[\s*['"]0\.0\.0\.0\/0['"]\s*\]/i)) {
        findings.push(this.createFinding({
          title: "Overly permissive security group (0.0.0.0/0)",
          severity: "High",
          cwe: "CWE-284",
          reasoning: "Security group allows traffic from any IP address (0.0.0.0/0).",
          solution: "Restrict CIDR blocks to specific, trusted IP ranges.",
          lineStart: index + 1,
          confidence: 0.9
        }));
      }

      // 3. Unencrypted EBS
      if (trimmed.match(/encrypted\s*=\s*false/i) && code.includes('aws_ebs_volume')) {
        findings.push(this.createFinding({
          title: "Unencrypted EBS volume",
          severity: "Medium",
          cwe: "CWE-311",
          reasoning: "EBS volume is explicitly configured without encryption.",
          solution: "Set 'encrypted = true' for sensitive data storage.",
          lineStart: index + 1,
          confidence: 0.8
        }));
      }

      // 4. No MFA delete
      if (trimmed.match(/mfa_delete\s*=\s*['"]Disabled['"]/i) || (code.includes('aws_s3_bucket') && code.includes('versioning') && !code.includes('mfa_delete'))) {
          // This is a bit noisy if just checking for absence without context, but let's stick to explicit disable or missing in versioning
          if (trimmed.match(/mfa_delete\s*=\s*['"]Disabled['"]/i)) {
            findings.push(this.createFinding({
                title: "S3 MFA Delete disabled",
                severity: "Medium",
                reasoning: "MFA delete is disabled for an S3 bucket with versioning. This makes it easier to accidentally or maliciously delete bucket versions.",
                solution: "Enable MFA delete for production S3 buckets.",
                lineStart: index + 1,
                confidence: 0.8
            }));
          }
      }
    });

    return findings;
  }
}
