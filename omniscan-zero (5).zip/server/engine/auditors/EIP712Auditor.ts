import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class EIP712Auditor extends BaseAuditor {
  name = "EIP-712 Scanner";
  category = "Web3 Security" as const;

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/EIP712Domain/i.test(code) && !/chainid/i.test(code)) {
        findings.push(this.createFinding({
            title: "EIP-712 Missing ChainID",
            severity: "Critical",
            reasoning: "EIP-712 domain separator does not include chainid, allowing signature replay across forks/networks.",
            solution: "Add 'uint256 chainid' to the domain separator.",
            confidence: 0.95
        }));
    }
    return findings;
  }
}
