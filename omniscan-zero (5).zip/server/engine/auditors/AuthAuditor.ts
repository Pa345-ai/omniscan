import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class AuthAuditor extends BaseAuditor {
  name = "Auth Scanner";
  category = "Authentication";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (code.toLowerCase().includes("password") && !code.toLowerCase().includes("hash")) {
      findings.push(this.createFinding({
        title: "Plaintext Password Handling",
        severity: "High",
        reasoning: "Stored or processed passwords may not be hashed properly.",
        solution: "Use bcrypt or argon2 for password hashing.",
        confidence: 0.7
      }));
    }
    return findings;
  }
}
