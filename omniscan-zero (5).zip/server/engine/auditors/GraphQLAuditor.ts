import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class GraphQLAuditor extends BaseAuditor {
  name = "GraphQL Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/graphql|apollo-server/i.test(code) && !/introspection:\s*false/i.test(code) && !/depthLimit/i.test(code)) {
        findings.push(this.createFinding({
            title: "Insecure GraphQL Configuration",
            severity: "Low",
            reasoning: "GraphQL endpoint may expose introspection queries or have unlimited query depth.",
            solution: "Disable introspection in production and introduce depth/complexity limiting rules.",
            confidence: 0.7
        }));
    }
    return findings;
  }
}
