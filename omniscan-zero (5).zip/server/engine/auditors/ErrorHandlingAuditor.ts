import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class ErrorHandlingAuditor extends BaseAuditor {
  name = "Error Handling Scanner";
  category = "Reliability";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/res\.status\(500\)\.(send|json)\(\s*(err\.stack|err\.message)\s*\)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Information Disclosure via Stack Trace Leak",
            severity: "Medium",
            reasoning: "Application returns unsanitized error messages or stack traces to the client.",
            solution: "Log errors internally and return a generic error message.",
            confidence: 0.9
        }));
    }
    return findings;
  }
}
