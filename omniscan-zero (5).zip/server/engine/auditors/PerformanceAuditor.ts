import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class PerformanceAuditor extends BaseAuditor {
  name = "Performance Scanner";
  category = "Performance";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (code.includes(".map(") && code.includes(".filter(") && code.length > 5000) {
      findings.push(this.createFinding({
        title: "Inefficient Collection Processing",
        severity: "Low",
        reasoning: "Multiple collection iterations detected on potentially large datasets.",
        solution: "Combine map and filter or use a single reduce call.",
        confidence: 0.6
      }));
    }
    return findings;
  }
}
