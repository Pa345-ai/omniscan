import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class PrototypePollutionAuditor extends BaseAuditor {
  name = "JS Prototype Engine";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (code.includes("__proto__") || code.includes("constructor.prototype")) {
      findings.push(this.createFinding({
        title: "Prototype Pollution Vulnerability",
        severity: "High",
        reasoning: "Direct access to __proto__ detected. Can lead to denial of service or remote code execution via object manipulation.",
        solution: "Use Map instead of object literals or sanitize keys to prevent '__proto__' and 'constructor' access.",
        confidence: 0.95
      }));
    }
    return findings;
  }
}
