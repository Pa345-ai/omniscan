import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class InputValidationAuditor extends BaseAuditor {
  name = "Input Validation Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/req\.body/.test(code) && !/(joi|zod|express-validator|class-validator)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Missing Input Validation",
            severity: "Medium",
            reasoning: "Request body accessed without an apparent validation library implementation.",
            solution: "Introduce strict schema-based input validation (e.g. Zod, Joi).",
            confidence: 0.6
        }));
    }
    return findings;
  }
}
