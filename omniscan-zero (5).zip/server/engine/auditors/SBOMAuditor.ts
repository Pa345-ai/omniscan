import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";
import axios from "axios";

export class SBOMAuditor extends BaseAuditor {
  name = "SBOM & Supply Chain Core";
  category = "Supply Chain";

  private npmCache: Map<string, any> = new Map();

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    if (!context.filename.endsWith("package.json")) {
      return [];
    }

    const findings: BugReport[] = [];
    let pkg: any;

    try {
      pkg = JSON.parse(code);
    } catch (e) {
      return [];
    }

    const allDeps = {
      ...(pkg.dependencies || {}),
      ...(pkg.devDependencies || {}),
      ...(pkg.optionalDependencies || {}),
      ...(pkg.peerDependencies || {}),
    };

    // 1. Detect npm: aliases (Supply Chain Hijacking)
    for (const [name, version] of Object.entries(allDeps)) {
      if (typeof version === 'string' && (version.startsWith("npm:") || version.includes("@"))) {
         findings.push(this.createFinding({
            title: "Dependency Aliasing Detected",
            severity: "Medium",
            reasoning: `The package '${name}' is aliased to '${version}'. This technique is often used to shadow official packages with malicious versions.`,
            solution: "Verify that the aliased package is intentional and from a trusted source.",
            confidence: 0.8
         }));
      }
    }

    // 2. Detect Malicious Life-cycle Scripts
    const scripts = pkg.scripts || {};
    const suspiciousPatterns = [/curl/i, /wget/i, /fetch/i, /http/i, /sh -c/i, /node -e/i, /eval\(/i];
    const lifecycleHooks = ['preinstall', 'postinstall', 'install', 'prepublish', 'prepare'];

    for (const hook of lifecycleHooks) {
      if (scripts[hook]) {
        if (suspiciousPatterns.some(p => p.test(scripts[hook]))) {
          findings.push(this.createFinding({
            title: `Suspicious Lifecycle Script: ${hook}`,
            severity: "High",
            reasoning: `The '${hook}' script contains potentially malicious command patterns (network requests or arbitrary code execution): "${scripts[hook]}"`,
            solution: "Review the script content. Lifecycle scripts are a common vector for persistent supply chain attacks.",
            confidence: 0.9,
            cwe: "CWE-94"
          }));
        }
      }
    }

    // 3. Dependency Confusion & Typosquatting (Heuristics + Registry)
    for (const depName of Object.keys(allDeps)) {
      // Internal-sounding names that aren't scoped
      if (!depName.startsWith("@") && (depName.includes("internal") || depName.includes("private") || depName.includes("dev-"))) {
        findings.push(this.createFinding({
          title: "Potential Dependency Confusion (Internal Naming)",
          severity: "Medium",
          reasoning: `The package name '${depName}' sounds like an internal utility but is not scoped. An attacker could register this name on the public NPM registry to hijack your build.`,
          solution: "Use private scopes (e.g., @company/package) for all internal dependencies and configure your registry to prefer private sources.",
          confidence: 0.7,
          cwe: "CWE-427"
        }));
      }

      // Typosquatting heuristics (e.g. popular package names with slight variations)
      const commonTypos = ["lodsh", "reacr", "expres", "mongooose", "payloaad"];
      if (commonTypos.some(typo => depName.includes(typo))) {
         findings.push(this.createFinding({
            title: "Potential Typosquatting Detected",
            severity: "High",
            reasoning: `The package name '${depName}' is very similar to a popular library. This is a common method for delivering malicious payloads via supply chain.`,
            solution: "Double-check the spelling of the dependency and verify its popularity/reputation on NPM.",
            confidence: 0.8
         }));
      }

      // 4. Registry-based verification
      if (process.env.NODE_ENV !== 'test') { // Skip during tests to avoid external calls
         try {
            const registryData = await this.fetchNpmData(depName);
            if (registryData) {
               const latestVersion = registryData['dist-tags']?.latest;
               const time = registryData.time?.[latestVersion];
               
               if (time) {
                  const publishDate = new Date(time);
                  const now = new Date();
                  const ageInDays = (now.getTime() - publishDate.getTime()) / (1000 * 3600 * 24);
                  
                  if (ageInDays < 7) {
                     findings.push(this.createFinding({
                        title: "Very New Dependency Detected",
                        severity: "Low",
                        reasoning: `The package '${depName}' was published less than 7 days ago (${publishDate.toLocaleDateString()}). New packages are higher risk for supply chain attacks.`,
                        solution: "Verify that this is a trusted package and not a recently released malicious payload.",
                        confidence: 0.6
                     }));
                  }
               }
            } else if (!depName.includes("/")) {
                // If package not found in public registry and not scoped, might be private/missing
                findings.push(this.createFinding({
                    title: "Unregistered Public Dependency",
                    severity: "Medium",
                    reasoning: `The package '${depName}' was not found on the public NPM registry. If this is an internal package, it is highly susceptible to dependency confusion.`,
                    solution: "Register the name as a placeholder on NPM or use a private scope.",
                    confidence: 0.6
                }));
            }
         } catch (err) {
            // Silently fail registry checks
         }
      }
    }

    return findings;
  }

  private async fetchNpmData(pkgName: string) {
    if (this.npmCache.has(pkgName)) return this.npmCache.get(pkgName);
    
    try {
      const response = await axios.get(`https://registry.npmjs.org/${pkgName}`, { timeout: 2000 });
      this.npmCache.set(pkgName, response.data);
      return response.data;
    } catch (e) {
      return null;
    }
  }
}
