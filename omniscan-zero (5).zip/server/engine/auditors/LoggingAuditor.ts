import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class LoggingAuditor extends BaseAuditor {
  name = "Logging Scanner";
  category = "Reliability";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/console\.log\(.*(password|token|secret|key).*/i.test(code)) {
        findings.push(this.createFinding({
            title: "Sensitive Data Logged",
            severity: "Medium",
            reasoning: "Credentials or sensitive tokens are being logged, risking exposure.",
            solution: "Mask or remove sensitive fields prior to logging.",
            confidence: 0.85
        }));
    }
    return findings;
  }
}
