import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class Web3Analyzer extends BaseAuditor {
  name = "Elite Web3 Auditor";
  category = "Smart Contract Security";

  private analyzeInheritance(code: string): string[] {
    const matches = code.match(/contract\s+\w+\s+is\s+([^\{]+)/);
    if (!matches) return [];
    return matches[1].split(",").map(i => i.trim());
  }

  private traceExternalCalls(code: string): string[] {
    const calls: string[] = [];
    const patterns = [
      /(\w+)\.transfer\(/g,
      /(\w+)\.send\(/g,
      /(\w+)\.call\{/g,
      /(\w+)\.delegatecall\(/g
    ];
    
    patterns.forEach(p => {
      let match;
      while ((match = p.exec(code)) !== null) {
        calls.push(match[1]);
      }
    });

    return calls;
  }

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    
    // 0. Metadata & Inheritance Analysis
    const inheritance = this.analyzeInheritance(code);
    if (inheritance.includes("Ownable") || inheritance.includes("AccessControl")) {
      console.log(`[Web3Analyzer] Found security modules: ${inheritance.join(", ")}`);
    }

    // 1. Reentrancy check
    if (code.includes(".call{value:") && !code.includes("nonReentrant")) {
      findings.push(this.createFinding({
        title: "Potential Reentrancy Vulnerability",
        severity: "High",
        reasoning: "External call detected without nonReentrant guard. An attacker could hijack control flow to drain contract funds.",
        solution: "Use OpenZeppelin's ReentrancyGuard or the Checks-Effects-Interactions pattern.",
        confidence: 0.95
      }));
    }

    // 2. Oracle manipulation
    if (code.includes("slot0") || (code.includes("IUniswapV3Pool") && code.includes("observe"))) {
      findings.push(this.createFinding({
        title: "Oracle Price Manipulation Risk",
        severity: "High",
        reasoning: "Direct use of UniswapV3 spot price detected. Flash loan attacks can manipulate the price significantly in a single transaction.",
        solution: "Use TWAP (Time-Weighted Average Price) or a decentralized oracle like Chainlink.",
        confidence: 0.9
      }));
    }

    // 3. Overflow/Underflow (Pre-Solidity 0.8)
    if (code.includes("pragma solidity 0.7") || code.includes("pragma solidity 0.6")) {
      if (!code.includes("SafeMath")) {
        findings.push(this.createFinding({
          title: "Integer Overflow/Underflow Risk",
          severity: "Medium",
          reasoning: "Contract uses an older Solidity version without built-in overflow checks and doesn't seem to use SafeMath.",
          solution: "Upgrade to Solidity 0.8+ or use SafeMath library.",
          confidence: 0.8
        }));
      }
    }

    // 4. Governance Takeover / Centralization
    if (code.includes("onlyOwner") && (code.includes("setFee") || code.includes("pause"))) {
       findings.push(this.createFinding({
        title: "Centralization Risk: Owner Control",
        severity: "Low",
        reasoning: "Critical functions restricted to a single owner address without a timelock or multisig.",
        solution: "Use a Timelock controller and a Multi-Signature wallet for admin roles.",
        confidence: 0.7
      }));
    }

    // 5. Flash Loan Vector
    if (code.includes("flashLoan") || code.includes("executeOperation")) {
       findings.push(this.createFinding({
        title: "Flash Loan Integration Detected",
        severity: "Medium",
        reasoning: "The contract interacts with flash loans. This significantly increases the attack surface for price manipulation and governance takeover.",
        solution: "Perform rigorous checks on state consistency before and after the flash loan operation.",
        confidence: 0.8
      }));
    }

    // 6. Precision Loss / Rounding Issues
    if (code.includes("/") && !code.includes("*") && (code.includes("amount") || code.includes("balance"))) {
       findings.push(this.createFinding({
        title: "Potential Precision Loss",
        severity: "Medium",
        reasoning: "Division detected which might lead to rounding down to zero, especially in smaller amounts. Division should generally happen last in a calculation.",
        solution: "Ensure multiplication happens before division to maintain maximum precision.",
        confidence: 0.75
      }));
    }

    // 7. Vault Accounting Errors
    if (code.includes("totalAssets()") && code.includes("shares") && code.includes("deposit")) {
       findings.push(this.createFinding({
        title: "Vault Inflation Attack Risk",
        severity: "High",
        reasoning: "Standard vault accounting detected. Early depositors can manipulate the exchange rate by sending external assets to the contract.",
        solution: "Use 'virtual shares' or ensure a minimum deposit amount for the first user.",
        confidence: 0.85
      }));
    }

    // 8. MEV & Frontrunning: Slippage Protection
    if (code.includes("swapExactTokensForTokens") || code.includes("swapExactETHForTokens")) {
      if (code.includes("0,") || code.includes("0)")) {
         findings.push(this.createFinding({
          title: "Hardcoded Zero Slippage (Frontrunning Risk)",
          severity: "High",
          reasoning: "AMM swap detected with a hardcoded minimum amount out of 0. This allows attackers (MEV bots) to sandwich the transaction or front-run it, causing massive slippage for the caller.",
          solution: "Always provide a user-defined 'amountOutMin' or calculate it using a trusted TWAP oracle.",
          confidence: 0.9,
          cwe: "CWE-682"
        }));
      }
    }

    // 9. Insecure Randomness via Block Headers
    if (code.includes("block.timestamp") || code.includes("block.number") || code.includes("block.difficulty")) {
      if (code.includes("%") || code.includes("keccak256")) {
        findings.push(this.createFinding({
          title: "Insecure Randomness (Miner Manipulation)",
          severity: "Medium",
          reasoning: "Use of block properties for randomness or logic control. Miners/Validators can manipulate these values within certain bounds to influence the outcome of the contract (e.g., lottery bias).",
          solution: "Use Chainlink VRF for provably fair and verifiable randomness.",
          confidence: 0.85,
          cwe: "CWE-338"
        }));
      }
    }

    // 10. Missing Commit-Reveal (Auction/Voting)
    if ((code.includes("function bid") || code.includes("function vote")) && !code.includes("reveal")) {
       findings.push(this.createFinding({
        title: "Absence of Commit-Reveal Scheme",
        severity: "Medium",
        reasoning: "Public bidding or voting detected without a reveal phase. This allows observers to see all transactions in the mempool and front-run with a slightly better bid or copy votes.",
        solution: "Implement a two-phase commit-reveal mechanism (Hashed Secret -> Open Secret).",
        confidence: 0.75
      }));
    }

    // 11. Cross-Function Reentrancy
    const stateVars = code.match(/(\w+)\s+(?:public|private|internal|constant)?\s*(\w+);/g);
    if (stateVars && code.includes(".call{") && !code.includes("nonReentrant")) {
       findings.push(this.createFinding({
        title: "Potential Cross-Function Reentrancy",
        severity: "High",
        reasoning: "The contract contains multiple entry points that interact with shared state variables and perform external calls. While single-function reentrancy might be guarded, state can still be inconsistent across different functions.",
        solution: "Use a global reentrancy guard or ensure the Checks-Effects-Interactions pattern is applied everywhere.",
        confidence: 0.7,
        cwe: "CWE-841"
      }));
    }

    // 12. Block Ordering Dependency
    if (code.includes("msg.sender") && code.includes("block.timestamp") && code.includes("==")) {
        findings.push(this.createFinding({
            title: "Block Ordering Dependency",
            severity: "Low",
            reasoning: "The logic depends on a precise match of block properties or sender order. Attackers can bribe miners or use Flashbots to ensure their transaction is placed at a specific position to exploit this check.",
            solution: "Ensure state-changing logic is robust to transaction ordering within a single block.",
            confidence: 0.65
        }));
    }

    return findings;
  }
}
