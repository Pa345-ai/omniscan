import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class XSSAuditor extends BaseAuditor {
  name = "XSS Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(innerHTML\s*=|<\%\-|\{\{\{.*\}\}\}|!\s*=)/i.test(code) && /req\.(query|params|body)|window\.location/i.test(code)) {
        findings.push(this.createFinding({
            title: "Potential Cross-Site Scripting (XSS)",
            severity: "High",
            reasoning: "Unescaped user input flows to a template output or DOM sink.",
            solution: "Strictly escape all user input before reflective output.",
            confidence: 0.85
        }));
    }
    return findings;
  }
}
