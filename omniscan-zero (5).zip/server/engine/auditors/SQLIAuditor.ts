import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class SQLIAuditor extends BaseAuditor {
  name = "SQL Injection Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/\.(query|execute|raw)\s*\(.*(\+|\$\{).*\)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Potential SQL Injection",
            severity: "Critical",
            reasoning: "String concatenation or template literals detected inside a database query method.",
            solution: "Use parameterized queries or prepared statements.",
            confidence: 0.8
        }));
    }
    return findings;
  }
}
