import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class SSRFAuditor extends BaseAuditor {
  name = "Elite SSRF Engine";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    const urlPatterns = [/fetch\(/, /axios\./, /http\.get/, /https\.request/];
    
    if (urlPatterns.some(p => p.test(code))) {
      findings.push(this.createFinding({
        title: "Potential Server-Side Request Forgery",
        severity: "High",
        reasoning: "External request detected. If the URL is constructed using user input without strict allowlisting, it could lead to internal network probing or cloud metadata theft (IMDSv2).",
        solution: "Use a strict allowlist for hostnames and validate the IP address range to exclude internal subnets.",
        confidence: 0.8
      }));
    }
    return findings;
  }
}
