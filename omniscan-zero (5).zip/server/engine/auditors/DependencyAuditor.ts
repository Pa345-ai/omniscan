import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class DependencyAuditor extends BaseAuditor {
  name = "Dependency Scanner";
  category = "Supply Chain";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/(from|require)\(['"](lodash|moment|axios)['"]\)/i.test(code)) {
        findings.push(this.createFinding({
            title: "Potentially Vulnerable Dependency",
            severity: "Low",
            reasoning: "Detected usage of dependencies known to have historically high CVE counts. Ensure latest versions.",
            solution: "Check library version against OSV or npm audit.",
            confidence: 0.4
        }));
    }
    return findings;
  }
}
