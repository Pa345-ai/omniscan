import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class ResourceLeakAuditor extends BaseAuditor {
  name = "Resource Leak Scanner";
  category = "Performance";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (/fs\.openSync/i.test(code) && !/fs\.closeSync/i.test(code)) {
         findings.push(this.createFinding({
            title: "File Descriptor Leak",
            severity: "Low",
            reasoning: "Opened file descriptors are not reliably closed.",
            solution: "Ensure resources are released using try-finally blocks or automatic resource management.",
            confidence: 0.6
        }));
    }
    return findings;
  }
}
