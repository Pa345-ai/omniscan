import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class CICDPipelineAuditor extends BaseAuditor {
  name = "CI/CD Pipeline Scanner";
  category = "Infrastructure" as const;

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    if (context.filename?.endsWith('.yml') || context.filename?.endsWith('.yaml')) {
        if (/pull_request_target/i.test(code) && /actions\/checkout/i.test(code)) {
            findings.push(this.createFinding({
                title: "Insecure GitHub Actions Workflow",
                severity: "Critical",
                reasoning: "pull_request_target with explicit checkout allows execution of untrusted code with repository secrets.",
                solution: "Avoid checking out the PR head, or use 'pull_request' which isolates secrets.",
                confidence: 0.95
            }));
        }
    }
    return findings;
  }
}
