import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";
import { TaintSources, TaintSinks, Sanitizers, globalTaintState } from "../TaintTracker";

export class TaintAuditor extends BaseAuditor {
  name = "Precision Taint Engine";
  category = "Flow";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    const findings: BugReport[] = [];
    const lines = code.split('\n');
    
    // Local taint map: variable name -> taint source path
    let taintedVars: Map<string, string[]> = new Map();
    const currentFile = context.filename;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const codeLine = line.trim();
      let isSanitized = Sanitizers.some(s => codeLine.includes(s));

      // 1. Check for Sources
      for (const source of TaintSources) {
        if (codeLine.includes(source)) {
          // Find assignment
          const assignIdx = codeLine.indexOf("=");
          if (assignIdx > 0 && !isSanitized) {
            const lhs = codeLine.substring(0, assignIdx).trim();
            // simple var extraction
            const varName = lhs.split(/[ letconstvar:]+/).pop()?.trim();
            if (varName && varName.length > 0) {
              taintedVars.set(varName, [source]);
            }
          }
        }
      }

      // 2. Propagate through assignments
      if (codeLine.includes("=") && !isSanitized) {
        const parts = codeLine.split("=");
        const lhs = parts[0];
        const rhs = parts.slice(1).join("=");
        let rhsTaintedPath: string[] | null = null;

        for (const [tVar, path] of taintedVars.entries()) {
          // If RHS uses a tainted variable, or an object property of it
          const reg = new RegExp(`\\b${tVar}\\b`);
          if (reg.test(rhs)) {
            rhsTaintedPath = [...path, `assignment to ${lhs.trim()}`];
            break;
          }
        }

        if (rhsTaintedPath) {
           const varName = lhs.split(/[ letconstvar:]+/).pop()?.trim();
           if (varName) taintedVars.set(varName, rhsTaintedPath);
        } else {
           // If reassigned to safe value, remove taint
           const varName = lhs.split(/[ letconstvar:]+/).pop()?.trim();
           if (varName && !rhs.includes("req.") && !rhs.includes("(")) {
              taintedVars.delete(varName);
           }
        }
      }

      // 3. Propagate through function calls (Cross-file / Interprocedural)
      if (codeLine.includes("(") && !isSanitized) {
        // Try to find if tainted var is passed to a function
        for (const [tVar, path] of taintedVars.entries()) {
           const reg = new RegExp(`\\b${tVar}\\b`);
           if (reg.test(codeLine)) {
             // Find function name (rough heuristic)
             const match = codeLine.match(/([a-zA-Z0-9_\.]+)\s*\(/);
             if (match) {
               const funcName = match[1];
               // Check if funcName is a known sink
               const isSink = TaintSinks.some(s => funcName.includes(s.replace("(", "")));
               if (isSink) {
                 const fullPath = [...path, `Sink: ${funcName}`];
                 findings.push(this.createFinding({
                    title: `Taint Sink Reached without Sanitizer: ${funcName}`,
                    severity: "High",
                    reasoning: `Tainted data originated at [\`${path[0]}\`] and reached [\`${funcName}\`] without encountering a valid sanitizer. \n\n**Full Taint Path:** \n${fullPath.join(" → ")}`,
                    solution: "Apply strict input validation, contextual output encoding, or parameterize queries.",
                    confidence: 0.95,
                    lineStart: i + 1
                 }));
                 // Attach path
                 (findings[findings.length - 1] as any).taintPath = fullPath.join(" -> ");
               } else {
                 // Register cross-file taint propagating into imported function
                 const key = `func:${funcName}`;
                 globalTaintState.sinkFunctions.set(key, (globalTaintState.sinkFunctions.get(key) || new Set()).add(1));
               }
             }
           }
        }
      }

      // 4. Function definitions & Arguments as Sources (if globally tainted)
      const funcMatch = codeLine.match(/function\s+([a-zA-Z0-9_]+)\s*\((.*?)\)/) || codeLine.match(/([a-zA-Z0-9_]+)\s*=\s*\((.*?)\)\s*=>/);
      if (funcMatch) {
         const funcName = funcMatch[1];
         const args = funcMatch[2].split(",").map(a => a.trim().split(/[ :]+/)[0]);
         
         const key = `func:${funcName}`;
         if (globalTaintState.sinkFunctions.has(key)) {
            // Function was called with tainted arg elsewhere
            for (const arg of args) {
              if (arg) taintedVars.set(arg, [`cross-file arg ${arg} of ${funcName}`]);
            }
         }
      }

      // 5. Function returns (if returning tainted, mark globally as source)
      if (codeLine.includes("return ") && !isSanitized) {
        for (const [tVar, path] of taintedVars.entries()) {
           const reg = new RegExp(`\\b${tVar}\\b`);
           if (reg.test(codeLine)) {
              // mark current file function as source returning taint
              // we don't have the exact func scope here easily, but we can just note it
              globalTaintState.sourceFunctions.set(currentFile, true);
           }
        }
      }
    }
    
    return findings;
  }
}

