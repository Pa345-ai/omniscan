import { BaseAuditor, BugReport } from "../Auditor";
import { ScanContext } from "../Context";

export class InjectionAuditor extends BaseAuditor {
  name = "Injection Scanner";
  category = "Security";

  async audit(code: string, context: ScanContext): Promise<BugReport[]> {
    // Basic pattern matching for common injections
    const findings: BugReport[] = [];
    if (code.includes("eval(") || code.includes("exec(")) {
      findings.push(this.createFinding({
        title: "Dynamic Evaluation Vulnerability",
        severity: "High",
        reasoning: "Use of eval() or exec() detected. This can lead to arbitrary code execution if inputs are untrusted.",
        solution: "Use template literals or safer parsing methods like JSON.parse().",
        confidence: 0.9
      }));
    }
    return findings;
  }
}
