import { ASTNode, SecurityGraph } from "./Types";
import { UnifiedIR } from "./ir/IRTypes";
import { CFGBuilder } from "./flow/CFGBuilder";
import { DataFlowAnalyzer } from "./flow/DataFlowAnalyzer";
import { TaintEngine, TaintVulnerability } from "./flow/TaintEngine";
import { ControlFlowGraph } from "./flow/FlowTypes";

export class FlowAnalyzer {
  private cfgBuilder = new CFGBuilder();
  private dfa = new DataFlowAnalyzer();
  private taintEngine = new TaintEngine();

  async buildExecutionGraph(ast: ASTNode): Promise<SecurityGraph> {
    // Legacy support for basic graph structure
    const nodes = new Map<number, ASTNode>();
    const edges: any[] = [];
    return { nodes, edges, symbols: [] };
  }

  async analyzeFullFlow(ir: UnifiedIR): Promise<{
    cfgs: Map<string, ControlFlowGraph>;
    vulnerabilities: TaintVulnerability[];
  }> {
    const cfgs = new Map<string, ControlFlowGraph>();
    
    ir.functions.forEach((func, name) => {
      const cfg = this.cfgBuilder.build(func);
      cfgs.set(name, cfg);
    });

    const vulnerabilities = this.taintEngine.analyze(ir);

    return { cfgs, vulnerabilities };
  }
}
