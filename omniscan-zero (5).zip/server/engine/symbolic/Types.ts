
export type SymbolicValue = any; // In a real system, this would be an AST-like structure of Z3 expressions

export interface PathConstraint {
  expression: any;
  outcome: boolean;
  solutionCandidate?: SolutionCandidate;
}

export interface SolutionCandidate {
  variable: string;
  value: string | number;
  type: string;
  constraint: string;
}

export interface SymbolicState {
  memory: Map<string, SymbolicValue>;
  storage: Map<string, SymbolicValue>;
  stack: SymbolicValue[];
  constraints: PathConstraint[];
  pc: number;
  trace: string[];
  // Special variables
  caller: SymbolicValue;
  origin: SymbolicValue;
  value: SymbolicValue;
  balance: SymbolicValue;
  gas: SymbolicValue;
  blockNumber: SymbolicValue;
  timestamp: SymbolicValue;
}

export interface BranchInfo {
  condition: any;
  trueBranch: number;
  falseBranch: number;
}

export interface SymbolicFinding {
  title: string;
  severity: "Critical" | "High" | "Medium" | "Low";
  reasoning: string;
  path: PathConstraint[];
  exploit?: string;
}
