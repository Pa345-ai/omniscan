
import { SymbolicSolver } from "./Solver";
import { SymbolicState, SymbolicFinding, PathConstraint } from "./Types";
import { UnifiedIR, IRFunction, OpCode, IRInstruction } from "../ir/IRTypes";

export class SymbolicExecutor {
  private solver: SymbolicSolver;
  private maxDepth = 15;
  private maxStates = 1000;
  private stateCount = 0;

  constructor() {
    this.solver = new SymbolicSolver();
  }

  async initialize() {
    await this.solver.initialize();
  }

  async analyze(ir: UnifiedIR, entryPoint: string = "main"): Promise<SymbolicFinding[]> {
    const findings: SymbolicFinding[] = [];
    const func = ir.functions.get(entryPoint);
    if (!func) return findings;

    await this.initialize();

    const initialState: SymbolicState = {
      memory: new Map(),
      storage: new Map(),
      stack: [],
      constraints: [],
      pc: 0,
      trace: [],
      caller: this.solver.mkBV('caller', 160),
      origin: this.solver.mkBV('origin', 160),
      value: this.solver.mkBV('value', 256),
      balance: this.solver.mkBV('balance', 256),
      gas: this.solver.mkBV('gas', 256),
      blockNumber: this.solver.mkBV('blockNumber', 256),
      timestamp: this.solver.mkBV('timestamp', 256)
    };

    this.stateCount = 0;
    await this.executeFunction(func, initialState, findings, 0);

    return findings;
  }

  private async executeFunction(func: IRFunction, state: SymbolicState, findings: SymbolicFinding[], depth: number) {
    if (depth > this.maxDepth || this.stateCount > this.maxStates) return;
    this.stateCount++;

    const entryBlock = func.blocks.get(func.entryBlock);
    if (!entryBlock) return;

    await this.executeBlock(func, func.entryBlock, state, findings, depth);
  }

  private async executeBlock(func: IRFunction, blockId: string, state: SymbolicState, findings: SymbolicFinding[], depth: number) {
    const block = func.blocks.get(blockId);
    if (!block) return;

    for (const inst of block.instructions) {
      await this.executeInstruction(inst, state, findings);
      
      // If we encounter a branch instruction
      if (inst.opcode === OpCode.JUMPI) {
        const condition = this.evaluate(inst.operands[0], state);
        const trueTarget = inst.operands[1];
        const falseTarget = block.successors.find(s => s !== trueTarget);

        // Fork: Path 1 (Condition is True)
        const trueState = this.fork(state, condition, true);
        if (await this.isReachable(trueState)) {
          await this.executeBlock(func, trueTarget, trueState, findings, depth + 1);
        }

        // Fork: Path 2 (Condition is False)
        if (falseTarget) {
            const falseState = this.fork(state, condition, false);
            if (await this.isReachable(falseState)) {
            await this.executeBlock(func, falseTarget, falseState, findings, depth + 1);
            }
        }
        return; // Execution continues in forks
      }
    }

    // Default fallthrough correctly handled by IR successors if no branch was taken
    if (block.successors.length === 1) {
        await this.executeBlock(func, block.successors[0], state, findings, depth);
    }
  }

  private async executeInstruction(inst: IRInstruction, state: SymbolicState, findings: SymbolicFinding[]) {
    // Dispatch to instruction handlers
    switch (inst.opcode) {
      case OpCode.STORE:
        this.handleStore(inst, state);
        break;
      case OpCode.LOAD:
        this.handleLoad(inst, state);
        break;
      case OpCode.MATH:
        await this.checkArithmeticAnomalies(inst, state, findings);
        break;
      case OpCode.CALL:
        await this.handleCall(inst, state, findings);
        break;
    }
  }

  private handleStore(inst: IRInstruction, state: SymbolicState) {
    const target = inst.operands[0];
    const value = this.evaluate(inst.operands[1], state);
    
    if (target.startsWith("storage[")) {
        state.storage.set(target, value);
    } else {
        state.memory.set(target, value);
    }
  }

  private handleLoad(inst: IRInstruction, state: SymbolicState) {
    const target = inst.operands[0];
    const source = inst.operands[1];
    
    let value: any;
    if (source.startsWith("storage[")) {
        value = state.storage.get(source) || this.solver.mkBV(`storage_${source}`, 256);
    } else {
        value = state.memory.get(source) || this.solver.mkBV(`mem_${source}`, 256);
    }
    state.memory.set(target, value);
  }

  private async checkArithmeticAnomalies(inst: IRInstruction, state: SymbolicState, findings: SymbolicFinding[]) {
    const op = inst.operands[1]; // e.g. "+"
    const left = this.evaluate(inst.operands[2], state);
    const right = this.evaluate(inst.operands[3], state);
    const target = inst.operands[0];

    if (op === "+") {
      const result = this.solver.add(left, right);
      state.memory.set(target, result);

      // Check overflow: result < left (for unsigned)
      const overflowCondition = this.solver.lt(result, left);
      if (await this.checkSatisfiabilityWithConstraint(state, overflowCondition)) {
          const model = await this.solver.getModel();
          findings.push({
              title: "Potential Integer Overflow",
              severity: "High",
              reasoning: "Symbolic execution found a state where this addition can overflow 256 bits.",
              path: this.enrichConstraints(state.constraints, model)
          });
      }
    }
  }

  private enrichConstraints(constraints: PathConstraint[], model: any): PathConstraint[] {
    return constraints.map(c => ({
        ...c,
        solutionCandidate: {
            variable: c.expression.toString(),
            value: model.eval(c.expression).toString(),
            type: "constraint",
            constraint: c.outcome ? "true" : "false"
        }
    }));
  }

  private async handleCall(inst: IRInstruction, state: SymbolicState, findings: SymbolicFinding[]) {
    const target = inst.operands[0];
    
    // Security triggers
    if (target === "DELEGATECALL") {
        await this.checkDelegateCallVulnerability(state, findings);
    }
    
    if (target === "CALL" || target === "transfer" || target === "call") {
        await this.checkReentrancy(state, findings);
        await this.checkUnauthorizedAccess(state, findings);
    }
  }

  private async checkDelegateCallVulnerability(state: SymbolicState, findings: SymbolicFinding[]) {
      // Check if DELEGATECALL target is user-controlled
      const target = state.memory.get("delegate_target"); // Simplified marker
      if (target && await this.checkSatisfiabilityWithConstraint(state, this.solver.eq(state.caller, this.solver.mkBVVal(0xdead, 160)))) {
          findings.push({
              title: "Untrusted Delegatecall Target",
              severity: "Critical",
              reasoning: "Symbolic execution found a path where the DELEGATECALL target can be influenced by a non-owner.",
              path: state.constraints
          });
      }
  }

  private async checkReentrancy(state: SymbolicState, findings: SymbolicFinding[]) {
      // Look for SSTORE after this CALL in the trace/future
      // Simplified: If we are in a state where a state variable was loaded but not yet updated 
      // (Optimistic check)
      if (state.trace.some(t => t.includes("SLOAD")) && !state.trace.some(t => t.includes("SSTORE"))) {
           findings.push({
               title: "Potential Reentrancy",
               severity: "High",
               reasoning: "External call detected before state variable update (violates Checks-Effects-Interactions).",
               path: state.constraints
           });
      }
  }

  private async checkUnauthorizedAccess(state: SymbolicState, findings: SymbolicFinding[]) {
    // Mythril style: try to find a path where caller is NOT owner but we hit a sensitive opcode
    const isOwnerCondition = this.solver.eq(state.caller, this.solver.mkBVVal(0x1234, 160)); // Placeholder for actual owner check
    const bypassCondition = this.solver.not(isOwnerCondition);

    if (await this.checkSatisfiabilityWithConstraint(state, bypassCondition)) {
        findings.push({
            title: "Potential Access Control Bypass",
            severity: "Critical",
            reasoning: "Path exists where sensitive operation is reachable for non-privileged caller.",
            path: state.constraints
        });
    }
  }

  private fork(state: SymbolicState, condition: any, outcome: boolean): SymbolicState {
    return {
      ...state,
      memory: new Map(state.memory),
      storage: new Map(state.storage),
      stack: [...state.stack],
      constraints: [...state.constraints, { expression: condition, outcome }],
      trace: [...state.trace]
    };
  }

  private async isReachable(state: SymbolicState): Promise<boolean> {
    this.solver.reset();
    state.constraints.forEach(c => {
      const expr = c.outcome ? c.expression : this.solver.not(c.expression);
      this.solver.addConstraint(expr);
    });
    return await this.solver.checkSatisfiability();
  }

  private async checkSatisfiabilityWithConstraint(state: SymbolicState, extra: any): Promise<boolean> {
    this.solver.reset();
    state.constraints.forEach(c => {
        const expr = c.outcome ? c.expression : this.solver.not(c.expression);
        this.solver.addConstraint(expr);
    });
    this.solver.addConstraint(extra);
    return await this.solver.checkSatisfiability();
  }

  private evaluate(val: any, state: SymbolicState): any {
    if (typeof val === 'number') return this.solver.mkBVVal(BigInt(val), 256);
    if (typeof val === 'string') {
        if (state.memory.has(val)) return state.memory.get(val);
        if (val === 'msg.sender') return state.caller;
        if (val === 'msg.value') return state.value;
        return this.solver.mkBV(val, 256);
    }
    return val;
  }

  getPathConstraints(finding: SymbolicFinding): string[] {
    return finding.path.map(c => `[${c.outcome}] ${c.expression.toString()}`);
  }
}
