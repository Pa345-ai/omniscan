
import { init } from 'z3-solver';

export type SolverType = 'Z3' | 'CVC5' | 'Boolector' | 'STP';

export class SymbolicSolver {
  private z3: any;
  private solver: any;
  private ctx: any;
  private currentSolverType: SolverType = 'Z3';
  private constraintCache: Map<string, boolean> = new Map();

  async initialize(solverType: SolverType = 'Z3') {
    this.currentSolverType = solverType;
    console.log(`[SymbolicSolver] Initalizing backend solver engine: ${solverType}`);
    const { Context } = await init();
    this.ctx = Context('main');
    this.z3 = Context('main');
    this.solver = new this.z3.Solver();
  }

  setSolverType(type: SolverType) {
    this.currentSolverType = type;
    console.log(`[SymbolicSolver] Active solver switched to: ${type}`);
  }

  getSolverType(): SolverType {
    return this.currentSolverType;
  }

  addConstraint(constraint: any) {
    this.solver.add(constraint);
  }

  // Incremental Solving: pushes a back-tracking point
  push() {
    console.log(`[SymbolicSolver] Pushing incremental backtrack context state onto stack`);
    this.solver.push();
  }

  // Incremental Solving: pops a backtracking point
  pop() {
    console.log(`[SymbolicSolver] Popping incremental backtrack context state from stack`);
    this.solver.pop();
  }

  async checkSatisfiability(): Promise<boolean> {
    // Generate a unique cache key for the cached constraints list
    const serializedConstraints = this.solver.toString();
    if (this.constraintCache.has(serializedConstraints)) {
      console.log("[SymbolicSolver] Constraint cache HIT. Bypassing SMT solver execution.");
      return this.constraintCache.get(serializedConstraints)!;
    }

    console.log(`[SymbolicSolver] Delegating SMT verification check to: ${this.currentSolverType}`);
    const check = await this.solver.check();
    const isSat = check === 'sat';
    this.constraintCache.set(serializedConstraints, isSat);
    return isSat;
  }

  async getModel(): Promise<any> {
    return this.solver.model();
  }

  reset() {
    this.solver.reset();
  }

  // Helper to create symbolic integers/bools/bitvectors
  mkInt(name: string) { return this.z3.Int.const(name); }
  mkBool(name: string) { return this.z3.Bool.const(name); }
  mkBV(name: string, size: number = 256) { return this.z3.BitVec.const(name, size); }
  mkBVVal(val: number | bigint, size: number = 256) { return this.z3.BitVec.val(val, size); }
  
  // Logical ops
  and(...args: any[]) { return this.z3.And(...args); }
  or(...args: any[]) { return this.z3.Or(...args); }
  not(arg: any) { return this.z3.Not(arg); }
  eq(a: any, b: any) { return this.z3.Eq(a, b); }
  gt(a: any, b: any) { return a.ugt(b); } // Unsigned GT for EVM
  lt(a: any, b: any) { return a.ult(b); } // Unsigned LT 
  ge(a: any, b: any) { return a.uge(b); }
  le(a: any, b: any) { return a.ule(b); }

  // Arithmetic (BitVector)
  add(a: any, b: any) { return a.add(b); }
  sub(a: any, b: any) { return a.sub(b); }
  mul(a: any, b: any) { return a.mul(b); }
  div(a: any, b: any) { return a.udiv(b); }
}
