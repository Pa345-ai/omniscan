
import { SymbolicSolver } from "./Solver";

export class EVMStorageModel {
  private storage: Map<string, any> = new Map();

  constructor(private solver: SymbolicSolver) {}

  write(slot: any, value: any) {
    this.storage.set(slot.toString(), value);
  }

  read(slot: any) {
    const key = slot.toString();
    if (!this.storage.has(key)) {
      // Lazy initialize as a symbolic variable
      this.storage.set(key, this.solver.mkInt(`storage_${key}`));
    }
    return this.storage.get(key);
  }

  getHash(mappingName: string, key: any) {
    // Symbolic representation of keccak256 mapping layout
    return this.solver.mkInt(`hash(${mappingName},${key})`);
  }
}
