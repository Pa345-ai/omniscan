import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { rateLimit } from 'express-rate-limit';
import { ScannerEngine } from "./server/engine/Engine";
import { convertToSarif } from "./server/engine/SarifConverter";
import { ScanDB } from "./server/db/Database";
import { ScanQueue } from "./server/engine/ScanQueue";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' })); // Increased limit for large repos

  const scanLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 10, // Limit each IP to 10 scans per hour
    message: { error: "Too many scans from this IP, please try again after an hour." },
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req) => {
      // Skip rate limit if a valid global API key is provided
      const apiKey = req.headers['x-omniscan-key'];
      return apiKey === process.env.OMNISCAN_API_KEY && !!process.env.OMNISCAN_API_KEY;
    }
  });

  const authMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const apiKey = req.headers['x-omniscan-key'];
    const requiredKey = process.env.OMNISCAN_API_KEY;
    
    // Only enforce if an API key is configured in the environment
    if (requiredKey && apiKey !== requiredKey) {
      return res.status(401).json({ error: "Invalid or missing X-OmniScan-Key header." });
    }
    next();
  };

  const engine = new ScannerEngine(process.env.GEMINI_API_KEY!);

  // API Routes
  app.post("/api/report", authMiddleware, async (req, res) => {
    try {
      const { findings, reportType, branding } = req.body;
      
      if (!findings || !Array.isArray(findings)) {
        return res.status(400).json({ error: "Missing or invalid findings data." });
      }

      const { generatePdfReport } = await import("./server/engine/PdfReport");
      const pdfBuffer = await generatePdfReport({
        findings,
        reportType: reportType || 'technical',
        branding: branding || {}
      });

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=OmniScan_${reportType || 'report'}.pdf`);
      res.send(pdfBuffer);
    } catch (error: any) {
      console.error("PDF generation error:", error);
      res.status(500).json({ error: "Failed to generate PDF report" });
    }
  });

  app.post("/api/scan", [authMiddleware, scanLimiter], async (req, res) => {
    try {
      const { code, filename, type, url, branch, address, network, mode, stream } = req.body;

      // Size limit for raw code scans (100KB)
      if (code && code.length > 100 * 1024) {
        return res.status(413).json({ error: "Code snippet too large. Maximum size is 100KB for raw scans. For larger codebases, use repository scanning." });
      }

      const clientIdentity = (req.headers['x-omniscan-key'] as string) || req.ip || 'anonymous';

      if (type === 'repo' && url) {
        return ScanQueue.enqueue(clientIdentity, async () => {
          if ((stream || req.headers.accept === 'text/event-stream') && req.query.format !== 'sarif') {
            res.setHeader('Content-Type', 'text/event-stream');
            res.setHeader('Cache-Control', 'no-cache');
            res.setHeader('Connection', 'keep-alive');
            
            const sendEvent = (event: string, data: any) => {
              res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
            };

            const abortSignal = { aborted: false };
            req.on('close', () => {
              abortSignal.aborted = true;
            });

            sendEvent('start', { message: 'Repository scan started...' });
            
            try {
              const result = await engine.scanRepo(url, mode, branch, (data) => {
                if (!abortSignal.aborted) {
                  sendEvent(data.type, data);
                }
              }, abortSignal);
              if (!abortSignal.aborted) {
                res.end();
              }
            } catch (e: any) {
              if (!abortSignal.aborted) {
                sendEvent('error', { message: e.message || 'Scan failed' });
                res.end();
              }
            }
          } else {
            const result = await engine.scanRepo(url, mode, branch);
            if (req.query.format === 'sarif') {
              return res.json(convertToSarif(result.findings));
            }
            return res.json({ bugs: result.findings, metadata: result.metadata });
          }
        });
      }

      if (type === 'contract' && address) {
        return ScanQueue.enqueue(clientIdentity, async () => {
          const result = await engine.scanContract(address, network || 'eth', mode);
          if (req.query.format === 'sarif') {
            return res.json(convertToSarif(result.findings));
          }
          return res.json({ bugs: result.findings, metadata: result.metadata });
        });
      }

      if (!code) {
        return res.status(400).json({ error: "No input stream detected." });
      }

      return ScanQueue.enqueue(clientIdentity, async () => {
        const bugs = await engine.scan(code, filename || "neural_input.ts", mode);
        if (req.query.format === 'sarif') {
          return res.json(convertToSarif(bugs));
        }
        res.json({ bugs });
      });
    } catch (error: any) {
      console.error("Matrix scan error:", error);
      res.status(500).json({ error: error.message || "Neural link failure." });
    }
  });

  app.get("/api/auditors", authMiddleware, (req, res) => {
    res.json({ status: "all systems optimal", count: 31 });
  });

  app.get("/api/stats/repos", authMiddleware, (req, res) => {
    try {
      const stats = ScanDB.getRepoStats();
      const mttr = ScanDB.getMTTR();
      res.json({ repos: stats, mttr });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/stats/trends", authMiddleware, (req, res) => {
    try {
      const trends = ScanDB.getGlobalTrends();
      res.json(trends);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/history", authMiddleware, (req, res) => {
    try {
      const { url } = req.query;
      if (!url) return res.status(400).json({ error: "URL is required" });
      const history = ScanDB.getHistory(url as string);
      res.json(history);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/compliance/", authMiddleware, async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) return res.status(400).json({ error: "URL is required" });
      const findings = ScanDB.getLatestScanFindings(url as string);
      const { ComplianceService } = await import("./server/engine/ComplianceService");
      const report = ComplianceService.generateReport(findings as any);
      res.json(report);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/findings/mitigate", authMiddleware, async (req, res) => {
    try {
      const { findingId, status, reason } = req.body;
      if (!findingId || !status) return res.status(400).json({ error: "Missing required fields" });
      ScanDB.mitigateFinding(findingId, status, reason);
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[OmniScan] Matrix active on port ${PORT}`);
  });
}

startServer();
