import { useState, useEffect } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, Legend, Cell
} from 'recharts';
import { 
  Trophy, TrendingDown, TrendingUp, History, Shield, 
  ArrowUpRight, ArrowDownRight, Activity, AlertCircle
} from 'lucide-react';
import { cn } from '../lib/utils';

export default function Dashboard() {
  const [repos, setRepos] = useState<any[]>([]);
  const [trends, setTrends] = useState<any[]>([]);
  const [mttr, setMttr] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const [reposRes, trendsRes] = await Promise.all([
          fetch('/api/stats/repos').then(r => r.json()),
          fetch('/api/stats/trends').then(r => r.json())
        ]);
        setRepos(reposRes.repos);
        setMttr(reposRes.mttr);
        setTrends(trendsRes.map((t: any) => ({ ...t, score: Math.round(t.avg_score) })));
      } catch (e) {
        console.error("Failed to load dashboard data", e);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-brand">
        <Activity className="w-8 h-8 animate-spin" />
        <span className="ml-3 font-mono text-sm uppercase tracking-widest">Loading Neural Dashboard...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Risk Score Trend */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight">Global Risk Architecture Trend</h3>
            <p className="text-xs text-white/40 font-mono tracking-widest uppercase">30-Day Aggregate Security Posture</p>
          </div>
          <div className="flex gap-4">
             <div className="text-right">
                <p className="text-[10px] text-white/30 uppercase font-mono">AVG Score</p>
                <p className="text-xl font-bold text-brand">{trends.length > 0 ? trends[trends.length-1].score : '--'}</p>
             </div>
             <div className="text-right border-l border-white/10 pl-4">
                <p className="text-[10px] text-white/30 uppercase font-mono">MTTR</p>
                <p className="text-xl font-bold text-blue-400">{mttr > 0 ? `${mttr.toFixed(1)}h` : '--'}</p>
             </div>
          </div>
        </div>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trends}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
              <XAxis dataKey="day" stroke="#444" fontSize={10} tickFormatter={(str) => str.split('-').slice(1).join('/')} />
              <YAxis stroke="#444" fontSize={10} domain={[0, 100]} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '8px' }}
                itemStyle={{ color: '#00ff00' }}
              />
              <Line type="monotone" dataKey="score" stroke="#00ff00" strokeWidth={3} dot={false} animationDuration={2000} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Leaderboard */}
        <div className="glass-card p-6">
          <div className="flex items-center gap-3 mb-6">
            <Trophy className="w-5 h-5 text-brand" />
            <h3 className="text-lg font-bold text-white tracking-tight">Security Leaderboard</h3>
          </div>
          <div className="space-y-3">
            {repos.map((repo, i) => (
              <div key={repo.url} className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-lg group hover:border-brand/30 transition-all">
                <div className="flex items-center gap-4">
                  <span className="text-xs font-mono text-white/20">#{(i+1).toString().padStart(2, '0')}</span>
                  <div>
                    <p className="text-sm font-bold text-white truncate max-w-[200px]">{repo.name}</p>
                    <p className="text-[10px] text-white/30 truncate max-w-[200px] font-mono">{repo.url}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-[10px] text-white/30 uppercase font-mono">Last Scan</p>
                    <p className="text-[10px] text-white/60 font-mono italic">{new Date(repo.last_scan_at).toLocaleDateString()}</p>
                  </div>
                  <div className={cn(
                    "w-12 h-12 rounded-full border-2 flex items-center justify-center font-bold text-sm",
                    repo.risk_score >= 80 ? "border-brand/40 text-brand" : "border-orange-500/40 text-orange-500"
                  )}>
                    {Math.round(repo.risk_score)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Global Distribution */}
        <div className="glass-card p-6">
          <div className="flex items-center gap-3 mb-6">
            <Activity className="w-5 h-5 text-brand" />
            <h3 className="text-lg font-bold text-white tracking-tight">System Distribution</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-white/5 rounded-lg border border-white/5 flex flex-col items-center justify-center text-center">
              <Shield className="w-10 h-10 text-brand mb-2 opacity-40" />
              <p className="text-2xl font-bold text-white">{repos.length}</p>
              <p className="text-[10px] text-white/40 uppercase font-mono tracking-widest">Active Links</p>
            </div>
            <div className="p-4 bg-white/5 rounded-lg border border-white/5 flex flex-col items-center justify-center text-center">
              <TrendingDown className="w-10 h-10 text-brand mb-2 opacity-40" />
              <p className="text-2xl font-bold text-white">
                {trends.length > 1 ? (trends[trends.length-1].score - trends[trends.length-2].score).toFixed(1) : '0'}
              </p>
              <p className="text-[10px] text-white/40 uppercase font-mono tracking-widest">Neural Drift</p>
            </div>
          </div>
          
          <div className="mt-8 space-y-4">
             <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <AlertCircle className="w-5 h-5 text-orange-500" />
                    <div>
                        <p className="text-sm font-bold text-orange-100">Critical Regression Check</p>
                        <p className="text-[10px] text-orange-200/50 uppercase font-mono tracking-tighter">Automated MTTR Monitoring</p>
                    </div>
                </div>
                <ArrowUpRight className="w-5 h-5 text-orange-500" />
             </div>
             
             <div className="bg-brand/10 border border-brand/20 rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <TrendingUp className="w-5 h-5 text-brand" />
                    <div>
                        <p className="text-sm font-bold text-white">Leaderboard Mode</p>
                        <p className="text-[10px] text-brand/50 uppercase font-mono tracking-tighter">Gamified Security Velocity</p>
                    </div>
                </div>
                <button className="text-[10px] font-bold text-brand border border-brand/30 px-2 py-1 rounded bg-brand/10">VIEW ALL</button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
