
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  FileText, 
  ShieldCheck, 
  ShieldAlert, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  Clock,
  ArrowRight,
  FileCheck
} from 'lucide-react';
import { cn } from '../lib/utils';

export default function ComplianceReport({ repoUrl }: { repoUrl: string }) {
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [activeStandard, setActiveStandard] = useState('SOC2');

  useEffect(() => {
    if (repoUrl) fetchCompliance();
  }, [repoUrl]);

  const fetchCompliance = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/compliance/?url=${encodeURIComponent(repoUrl)}`);
      const data = await res.json();
      setReport(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const mitigationStatus = async (findingId: number, status: string, reason: string) => {
    try {
      await fetch('/api/findings/mitigate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ findingId, status, reason })
      });
      fetchCompliance();
    } catch (e) {
      console.error(e);
    }
  };

  if (!repoUrl) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-white/40">
        <FileText className="w-12 h-12 mb-4 opacity-20" />
        <p>No repository selected for compliance report.</p>
        <p className="text-xs">Start a scan to generate a report.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-brand" />
      </div>
    );
  }

  if (!report) return null;

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {Object.keys(report.frameworks).map(std => (
          <button
            key={std}
            onClick={() => setActiveStandard(std)}
            className={cn(
              "p-4 rounded-xl border text-left transition-all",
              activeStandard === std 
                ? "bg-brand/10 border-brand/50 shadow-[0_0_20px_rgba(0,255,0,0.1)]" 
                : "bg-white/5 border-white/5 hover:border-white/20"
            )}
            title={report.standards?.[std]?.description}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold tracking-widest uppercase">{std}</span>
              {report.frameworks[std].passed ? (
                <ShieldCheck className="w-4 h-4 text-brand" />
              ) : (
                <ShieldAlert className="w-4 h-4 text-red-500" />
              )}
            </div>
            <div className="text-sm font-bold">
              {report.frameworks[std].passed ? "Compliant" : `${report.frameworks[std].gaps.length} Gaps Found`}
            </div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <section className="glass-card p-6">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <ArrowRight className="w-5 h-5 text-brand" />
              {activeStandard} Control Gaps
            </h3>
            
            <div className="space-y-4">
              {report.frameworks[activeStandard]?.gaps.length > 0 ? (
                report.frameworks[activeStandard].gaps.map((gap: any, idx: number) => (
                  <div key={idx} className="bg-black/40 border border-white/5 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-brand bg-brand/10 px-2 py-0.5 rounded border border-brand/20">
                          {gap.control}
                        </span>
                        <h4 className="text-sm font-bold">{gap.requirement}</h4>
                      </div>
                      <span className={cn(
                        "text-[10px] font-bold uppercase",
                        gap.severity === 'High' ? 'text-red-500' : 'text-orange-500'
                      )}>
                        {gap.severity} RISK
                      </span>
                    </div>
                    <p className="text-xs text-white/50 mb-4 italic">Finding: {gap.findingTitle}</p>
                    <div className="flex items-center gap-3">
                       {gap.status === 'Mitigated' ? (
                         <div className="flex items-center gap-2 text-brand text-[10px] font-bold uppercase">
                           <CheckCircle2 className="w-3 h-3" /> Mitigated
                         </div>
                       ) : (
                         <div className="flex gap-2">
                           <button 
                             onClick={() => mitigationStatus(gap.id, 'Mitigated', 'False positive verified by expert.')}
                             className="text-[10px] bg-white/5 hover:bg-white/10 px-3 py-1 rounded border border-white/10 transition-all font-bold uppercase tracking-wider"
                           >
                             Mitigate
                           </button>
                           <button className="text-[10px] bg-red-500/10 text-red-400 px-3 py-1 rounded border border-red-500/20 font-bold uppercase tracking-wider">
                             Fix Required
                           </button>
                         </div>
                       )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-10 text-white/30 italic">
                  No gaps identified for this framework.
                </div>
              )}
            </div>
          </section>

          <section className="glass-card p-6">
            <h3 className="text-md font-bold mb-4 flex items-center gap-2 text-white/80">
              <FileCheck className="w-4 h-4 text-brand" />
              Audit Evidence Trail
            </h3>
            <div className="space-y-3">
              {report.evidence.map((ev: any, idx: number) => (
                <div key={idx} className="flex items-start gap-4 p-3 bg-white/5 rounded border border-white/5 text-[10px]">
                  <Clock className="w-3 h-3 mt-0.5 text-white/30" />
                  <div className="flex-1">
                    <p className="font-bold text-white/80 mb-1">{ev.finding}</p>
                    <p className="text-white/40 mb-1">{ev.file} • {ev.location}</p>
                    <div className="bg-black/20 p-2 rounded border border-white/5 font-mono text-brand/60">
                      {ev.reasoning.substring(0, 100)}...
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <div className="glass-card p-6 bg-brand/5 border-brand/20">
            <h4 className="text-xs font-bold uppercase tracking-widest text-brand mb-4">Compliance Score</h4>
            <div className="text-5xl font-bold tracking-tighter mb-2">
              {Math.max(0, 100 - (report.frameworks[activeStandard]?.gaps.filter((g: any) => g.status !== 'Mitigated').length * 15)) }
              <span className="text-xl text-brand/50">%</span>
            </div>
            <p className="text-[10px] text-white/40 leading-relaxed">
              Based on automated scan of {report.summary.totalFindings || 'repo'} assets. High risk gaps subtract 15% each from base score.
            </p>
          </div>

          <div className="glass-card p-6">
             <h4 className="text-xs font-bold uppercase tracking-widest mb-4">Executive Summary</h4>
             <div className="space-y-4">
                <div className="flex justify-between items-center text-xs">
                   <span className="text-white/40">Total Critical Ops</span>
                   <span className="font-bold underline text-red-500">{report.summary.critical}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                   <span className="text-white/40">Mitigated Risks</span>
                   <span className="font-bold text-brand">{report.summary.mitigated}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                   <span className="text-white/40">GDPR Compliance</span>
                   <span className={cn("font-bold", report.frameworks.GDPR.passed ? "text-brand" : "text-red-500")}>
                      {report.frameworks.GDPR.passed ? "ACTIVE" : "GAP"}
                   </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                   <span className="text-white/40">PCI-DSS Status</span>
                   <span className={cn("font-bold", report.frameworks["PCI-DSS"].passed ? "text-brand" : "text-red-500")}>
                      {report.frameworks["PCI-DSS"].passed ? "VALID" : "FAIL"}
                   </span>
                </div>
             </div>
          </div>

          <button className="w-full bg-brand text-black font-bold py-3 rounded-lg text-sm shadow-[0_0_20px_rgba(0,255,0,0.2)] hover:scale-[1.02] active:scale-95 transition-all">
             EXPORT AUDITOR PACKAGE (ZIP)
          </button>
        </div>
      </div>
    </div>
  );
}
