import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShieldCheck, 
  Terminal, 
  Search, 
  Bug, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronRight, 
  Zap, 
  Lock,
  Loader2,
  Copy,
  ExternalLink,
  ShieldAlert,
  Download
} from "lucide-react";
import Markdown from "react-markdown";
import { cn } from "./lib/utils";
import Dashboard from "./components/Dashboard";
import ComplianceReport from "./components/ComplianceReport";

interface BugReport {
  title: string;
  severity: 'High' | 'Medium' | 'Low';
  category: string;
  reasoning: string;
  solution: string;
  lineStart?: number;
  isExploitable?: boolean;
  poc?: string;
  aiExplanation?: string;
  file?: string;
  cwe?: string;
  cvssScore?: number;
  cves?: string[];
  exploitDB?: boolean;
}

export default function App() {
  const [code, setCode] = useState("");
  const [repoUrl, setRepoUrl] = useState("");
  const [repoBranch, setRepoBranch] = useState("main");
  const [contractAddr, setContractAddr] = useState("");
  const [network, setNetwork] = useState("eth");
  
  const [isScanning, setIsScanning] = useState(false);
  const [results, setResults] = useState<BugReport[] | null>(null);
  const [metadata, setMetadata] = useState<any>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [currentAction, setCurrentAction] = useState("Awaiting Input...");
  const [completedActions, setCompletedActions] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [scanMode, setScanMode] = useState<'quick' | 'deep' | 'ai_research'>('deep');
  const [inputSource, setInputSource] = useState<'raw' | 'repo' | 'contract'>('raw');
  
  const [fileStats, setFileStats] = useState({ processed: 0, total: 0 });
  const abortControllerRef = useRef<AbortController | null>(null);
  const scanInterval = useRef<number | null>(null);

  const [activeTab, setActiveTab] = useState<'scan' | 'dashboard' | 'compliance' | 'integrations'>('scan');
  const [auditors] = useState([
    "Injection Engine", "Auth Sentry", "Crypto Core", "Logic Matrix", "Secret Hunter",
    "Perf Monitor", "Dep Scanner", "Race Detector", "Leak Finder", "Error Prober",
    "IAM Vault", "Privacy Shield", "Net Guardian", "Infra Auditor", "Store Watcher",
    "Math Logic", "Input Val", "Session Sentry", "Log Auditor", "XSS Blade",
    "CSRF Lock", "SQLi Wall", "CMD Probe", "Serial Guard", "Biz Logic", "Sandbox",
    "Proto Auditor", "GraphQL V", "Compliance B", "AI Security"
  ]);

  const startScan = async () => {
    if (!code.trim() && inputSource === 'raw') return;
    if (!repoUrl.trim() && inputSource === 'repo') return;
    
    setError(null);
    setIsScanning(true);
    setResults(null);
    setScanProgress(0);
    setCompletedActions([]);
    setFileStats({ processed: 0, total: 0 });

    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    const actions = [
      "Parsing Semantic AST Index...", "Building Global Call Graph...", "Analyzing Interprocedural Flows...",
      "Detecting Framework-Aware Models...", "Resolving Path-Sensitive Contradictions...", "Executing 31 Specialized Auditors...",
      "Matrix-Level Neural Proof (ZFP)...", "Generating Autonomous PoCs...", "Verifying Patch Integrity..."
    ];

    if (inputSource !== 'repo') {
      const steps = 100;
      let currentStep = 0;
      scanInterval.current = window.setInterval(() => {
        currentStep++;
        if (currentStep <= 100) {
          setScanProgress(currentStep);
          const actionIdx = Math.min(Math.floor((currentStep / 100) * actions.length), actions.length - 1);
          setCurrentAction(actions[actionIdx]);
          if (currentStep % Math.floor(100 / actions.length) === 0) {
            const completedCount = Math.floor((currentStep / 100) * actions.length);
            setCompletedActions(actions.slice(0, completedCount));
          }
        }
      }, 45);
    }

    try {
      const payload: any = { mode: scanMode };
      if (inputSource === 'raw') { payload.code = code; payload.type = 'raw'; }
      else if (inputSource === 'repo') { payload.url = repoUrl; payload.branch = repoBranch; payload.type = 'repo'; payload.stream = true; }
      else if (inputSource === 'contract') { payload.address = contractAddr; payload.network = network; payload.type = 'contract'; }

      const response = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "text/event-stream" },
        body: JSON.stringify(payload),
        signal: abortController.signal
      });

      if (!response.ok) throw new Error("Matrix scan failed.");
      
      if (payload.stream) {
        setResults([]);
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const chunks = buffer.split('\n\n');
            buffer = chunks.pop() || '';
            for (const chunk of chunks) {
              const eventMatch = chunk.match(/event: (.*)/);
              const dataMatch = chunk.match(/data: (.*)/);
              if (eventMatch && dataMatch) {
                const event = eventMatch[1];
                const data = JSON.parse(dataMatch[1]);
                if (event === 'scan_start') setFileStats(prev => ({ ...prev, total: data.totalFiles }));
                else if (event === 'file_start') { setCurrentAction(`Analyzing ${data.file}...`); setFileStats({ processed: data.processedFiles, total: data.totalFiles }); setScanProgress(Math.floor((data.processedFiles / data.totalFiles) * 100)); }
                else if (event === 'finding') setResults(prev => [...(prev || []), data.finding]);
                else if (event === 'scan_complete') { setResults(data.findings); setMetadata(data.metadata || null); setScanProgress(100); if (scanInterval.current) clearInterval(scanInterval.current); }
              }
            }
          }
        }
      } else {
        const data = await response.json();
        setResults(data.bugs);
        setMetadata(data.metadata || null);
        setScanProgress(100);
      }
    } catch (err: any) {
      setError(err.name === 'AbortError' ? 'Scan cancelled.' : err.message);
    } finally {
      setIsScanning(false);
      if (scanInterval.current) clearInterval(scanInterval.current);
    }
  };

  const cancelScan = () => abortControllerRef.current?.abort();

  const downloadPdf = async (reportType: 'executive' | 'technical') => {
    if (!results || results.length === 0) return;
    try {
      const response = await fetch('/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ findings: results, reportType, branding: { companyName: "OmniScan Global" } })
      });
      if (!response.ok) throw new Error("Failed to generate PDF");
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `OmniScan_${reportType}.pdf`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) { alert("Error downloading PDF"); }
  };

  const severityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high': return 'text-red-500 border-red-500/20 bg-red-500/10';
      case 'medium': return 'text-orange-500 border-orange-500/20 bg-orange-500/10';
      case 'low': return 'text-blue-500 border-blue-500/20 bg-blue-500/10';
      default: return 'text-gray-500 border-gray-500/20 bg-gray-500/10';
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden scanner-grid bg-black text-white selection:bg-brand selection:text-black">
      <AnimatePresence>
        {isScanning && (
          <motion.div 
            initial={{ top: "-200px" }} animate={{ top: "100%" }} exit={{ opacity: 0 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="scan-line z-10"
          />
        )}
      </AnimatePresence>

      <nav className="border-b border-white/5 bg-black/40 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-brand/10 border border-brand/20 rounded-lg flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-brand" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tighter flex items-center gap-2">
                OMNISCAN <span className="text-brand font-mono text-[10px] tracking-widest border border-brand/30 px-1 rounded">PLATINUM v2.0</span>
              </h1>
              <p className="text-[10px] text-white/40 uppercase tracking-[0.2em] font-medium font-mono">Hybrid Semantic & AI Security Orchestrator</p>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="flex items-center bg-white/5 rounded-lg p-1 border border-white/5">
              {(['scan', 'dashboard', 'compliance', 'integrations'] as const).map(tab => (
                <button 
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={cn(
                    "px-4 py-1.5 rounded-md text-xs font-bold tracking-tighter transition-all uppercase",
                    activeTab === tab ? "bg-brand text-black shadow-[0_0_15px_rgba(0,255,0,0.2)]" : "text-white/40 hover:text-white/60"
                  )}
                >
                  {tab === 'integrations' ? 'CI/CD' : tab}
                </button>
              ))}
            </div>
            <div className="hidden md:flex items-center gap-2 text-xs font-mono">
              <div className="w-2 h-2 rounded-full bg-brand animate-pulse" />
              <span className="text-white/60 lowercase">System: Online</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-12 relative z-20">
        {activeTab === 'scan' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-12 xl:col-span-7 space-y-6">
              <div className="flex flex-wrap gap-4 mb-4">
                <div className="flex bg-white/5 rounded-lg p-1 border border-white/10">
                  {(['raw', 'repo', 'contract'] as const).map(s => (
                    <button key={s} onClick={() => setInputSource(s)} className={cn("px-4 py-1.5 rounded-md text-[10px] font-bold tracking-widest uppercase", inputSource === s ? "bg-white/10 text-brand" : "text-white/30")}>
                      {s}
                    </button>
                  ))}
                </div>
                <div className="flex bg-white/5 rounded-lg p-1 border border-white/10">
                  {(['quick', 'deep', 'ai_research'] as const).map(m => (
                    <button key={m} onClick={() => setScanMode(m)} className={cn("px-4 py-1.5 rounded-md text-[10px] font-bold tracking-widest uppercase", scanMode === m ? "bg-white/10 text-brand" : "text-white/30")}>
                      {m.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              <section className="glass-card">
                <div className="bg-white/5 border-b border-white/5 px-4 py-3 flex items-center justify-between text-xs font-mono text-white/50">
                  <div className="flex items-center gap-2"><Terminal className="w-4 h-4" /><span>neural_input.ts</span></div>
                </div>
                <div className="p-0">
                  {inputSource === 'raw' && <textarea value={code} onChange={e => setCode(e.target.value)} placeholder="Paste code..." className="w-full h-[500px] bg-transparent p-6 font-mono text-sm resize-none focus:outline-none text-brand/90" />}
                  {inputSource === 'repo' && (
                    <div className="p-8 space-y-4">
                       <div className="grid grid-cols-3 gap-4">
                          <div className="col-span-2">
                             <p className="text-xs font-mono text-white/40 mb-2">REPO URL</p>
                             <input value={repoUrl} onChange={e => setRepoUrl(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-lg p-4 font-mono text-brand focus:border-brand/40 outline-none" placeholder="https://github.com..." />
                          </div>
                          <div>
                             <p className="text-xs font-mono text-white/40 mb-2">BRANCH</p>
                             <input value={repoBranch} onChange={e => setRepoBranch(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-lg p-4 font-mono text-brand focus:border-brand/40 outline-none" placeholder="main" />
                          </div>
                       </div>
                    </div>
                  )}
                  {inputSource === 'contract' && (
                    <div className="p-8 space-y-4">
                       <div className="grid grid-cols-3 gap-4">
                          <div className="col-span-2">
                             <p className="text-xs font-mono text-white/40 mb-2">CONTRACT ADDRESS</p>
                             <input value={contractAddr} onChange={e => setContractAddr(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-lg p-4 font-mono text-brand focus:border-brand/40 outline-none" placeholder="0x..." />
                          </div>
                          <div>
                             <p className="text-xs font-mono text-white/40 mb-2">NETWORK</p>
                             <select value={network} onChange={e => setNetwork(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-lg p-4 font-mono text-brand focus:border-brand/40 outline-none">
                                <option value="eth">Ethereum</option><option value="base">Base</option><option value="arbitrum">Arbitrum</option><option value="polygon">Polygon</option>
                             </select>
                          </div>
                       </div>
                    </div>
                  )}
                </div>
                <div className="p-4 border-t border-white/5 flex gap-4">
                  <button onClick={startScan} disabled={isScanning} className={cn("flex-1 py-3 px-6 rounded-lg font-bold text-sm flex items-center justify-center gap-3 transition-all", isScanning ? "bg-white/5 text-brand" : "bg-brand text-black shadow-[0_0_20px_rgba(0,255,0,0.2)]")}>
                    {isScanning ? <><Loader2 className="w-5 h-5 animate-spin" />{currentAction} [{scanProgress}%]</> : <><Search className="w-5 h-5" />INITIALIZE SCAN</>}
                  </button>
                  {isScanning && <button onClick={cancelScan} className="px-6 py-3 rounded-lg border border-red-500/20 text-red-500 font-bold text-sm">CANCEL</button>}
                </div>
              </section>
            </div>

            <div className="lg:col-span-12 xl:col-span-5 space-y-6">
              <div className="glass-card p-6 min-h-[400px]">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-xl font-bold flex items-center gap-2"><Bug className="w-5 h-5 text-brand" />Findings</h2>
                  {results && (
                     <div className="flex gap-2">
                        <button onClick={() => downloadPdf('executive')} className="text-[10px] font-mono bg-blue-500/10 text-blue-400 px-2 py-1 rounded border border-blue-500/30">EXEC PDF</button>
                        <button onClick={() => downloadPdf('technical')} className="text-[10px] font-mono bg-purple-500/10 text-purple-400 px-2 py-1 rounded border border-purple-500/30">TECH PDF</button>
                     </div>
                  )}
                </div>

                <AnimatePresence>
                  {results ? (
                    <div className="space-y-4">
                      {results.map((bug, idx) => (
                        <motion.div key={idx} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: idx * 0.05 }} className="bg-white/5 border border-white/5 rounded-lg p-4 hover:border-brand/30 transition-all">
                          <div className="flex items-center gap-2 mb-2">
                            <span className={cn("text-[10px] font-bold uppercase px-1.5 py-0.5 rounded border", severityColor(bug.severity))}>{bug.severity}</span>
                            <span className="text-[10px] font-mono text-white/30 uppercase tracking-widest">{bug.category}</span>
                            {bug.file && <span className="text-[8px] font-mono text-white/50">{bug.file}:{bug.lineStart}</span>}
                          </div>
                          <h3 className="text-sm font-bold mb-2">{bug.title}</h3>
                          <p className="text-xs text-white/60 mb-2 leading-relaxed">{bug.aiExplanation || bug.reasoning}</p>
                        </motion.div>
                      ))}
                    </div>
                  ) : isScanning ? (
                    <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-brand" /></div>
                  ) : <div className="text-center py-20 text-white/20 italic">No artifacts yet. Start a scan.</div>}
                </AnimatePresence>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'dashboard' && <Dashboard />}

        {activeTab === 'compliance' && <ComplianceReport repoUrl={repoUrl} />}

        {activeTab === 'integrations' && (
          <div className="max-w-4xl mx-auto space-y-8 text-center pt-10">
             <h2 className="text-3xl font-bold tracking-tighter">CI/CD PIPELINE INTEGRATION</h2>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                <div className="glass-card p-6 space-y-4">
                   <h3 className="font-bold flex items-center gap-2"><Copy className="w-5 h-5 text-brand" /> GitHub Actions</h3>
                   <div className="bg-black/40 rounded p-4 font-mono text-[10px] text-brand/80 border border-white/5 overflow-x-auto">
                      <pre>{`uses: actions/checkout@v4\n- name: OmniScan API\n  run: curl -X POST $OMNISCAN_URL/api/scan -d '{"url":"..."}'`}</pre>
                   </div>
                </div>
                <div className="glass-card p-6 space-y-4">
                   <h3 className="font-bold flex items-center gap-2"><ExternalLink className="w-5 h-5 text-brand" /> GitLab CI</h3>
                   <div className="bg-black/40 rounded p-4 font-mono text-[10px] text-brand/80 border border-white/5 overflow-x-auto">
                      <pre>{`omniscan:\n  stage: test\n  script:\n    - curl -X POST $OMNISCAN_URL/api/scan`}</pre>
                   </div>
                </div>
             </div>
          </div>
        )}
      </main>

      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-white/5 text-center text-white/20 font-mono text-[10px] uppercase tracking-[0.3em] relative z-20">
        © 2026 OMNISCAN AI LABS • Neural Bug Matrix Hub • Active Nodes: 42
      </footer>
    </div>
  );
}
